<?php
require_once 'authentication/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'pending_count' => 0, 'message' => ''];

$email = $_GET['email'] ?? null;

try {
    if (!$email) {
        throw new Exception("Missing employee email.");
    }

    // 1️⃣ Get the employee's branch
    $stmt = $conn->prepare("SELECT branch, id FROM employees WHERE work_email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$row = $result->fetch_assoc()) {
        throw new Exception("Employee not found.");
    }
    $branch = $row['branch'];
    $employeeId = $row['id'];
    $stmt->close();

    // 2️⃣ Determine current quarter
    $currentMonth = (int)date('n');
    $currentYear = (int)date('Y');
    if ($currentMonth <= 3) $currentQuarter = "Q4-" . ($currentYear - 1);
    elseif ($currentMonth <= 6) $currentQuarter = "Q1-{$currentYear}";
    elseif ($currentMonth <= 9) $currentQuarter = "Q2-{$currentYear}";
    else $currentQuarter = "Q3-{$currentYear}";

    // 3️⃣ Count pending evaluations of same-branch peers (excluding own)
    // 3️⃣ Count pending evaluations of same-branch peers (excluding own and already responded)
$stmt = $conn->prepare("
    SELECT COUNT(*) 
    FROM evaluations e
    INNER JOIN employees emp ON e.employee_id = emp.id
    WHERE e.quarter_name = ? 
      AND e.status = 'analysis_needed' 
      AND emp.branch = ? 
      AND e.employee_id != ?
      AND NOT EXISTS (
          SELECT 1 
          FROM evaluation_responses er
          WHERE er.evaluation_id = e.evaluation_id
            AND er.employee_id = ?
      )
");
$stmt->bind_param("ssss", $currentQuarter, $branch, $employeeId, $employeeId);
$stmt->execute();
$count = $stmt->get_result()->fetch_row()[0];
$stmt->close();


    $response['success'] = true;
    $response['pending_count'] = (int)$count;
    $response['current_quarter'] = $currentQuarter;

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("get_evaluations_count.php error: " . $e->getMessage());
} finally {
    if ($conn) $conn->close();
}

echo json_encode($response);
