<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'quarters' => [], 'message' => ''];

try {
    $employee_id = $_GET['employee_id'] ?? null;
    $filter_year = $_GET['year'] ?? null; // Optional year filter

    if (!$employee_id) {
        throw new Exception('Employee ID is required.');
    }

    $sql = "SELECT DISTINCT quarter_name FROM evaluations WHERE employee_id = ?";
    $params = "s";
    $bind_values = [$employee_id];

    if ($filter_year) {
        $sql .= " AND quarter_name LIKE ?";
        $params .= "s";
        $bind_values[] = "%-{$filter_year}";
    }

    $sql .= " ORDER BY quarter_start_date DESC"; // Order by date to get latest first

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Prepare statement failed: ' . $conn->error);
    }

    // Dynamically bind parameters
    $stmt->bind_param($params, ...$bind_values);

    if (!$stmt->execute()) {
        throw new Exception('Execute statement failed: ' . $stmt->error);
    }

    $result = $stmt->get_result();
    $quarters = [];
    while ($row = $result->fetch_assoc()) {
        $quarters[] = $row;
    }
    $stmt->close();

    $response['success'] = true;
    $response['quarters'] = $quarters;

} catch (Exception $e) {
    $response['message'] = 'Error fetching employee quarters: ' . $e->getMessage();
    error_log("get_existing_quarters.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>
