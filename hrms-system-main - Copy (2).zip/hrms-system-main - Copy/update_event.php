<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $title = $_POST['title'] ?? '';
    $details = $_POST['details'] ?? '';
    $event_date = $_POST['event_date'] ?? ''; // New field for event date

    if (empty($id) || empty($title) || empty($details) || empty($event_date)) {
        $response['message'] = 'Missing required fields: ID, Title, Details, or Event Date.';
    } else {
        // First, verify the event exists and is within the editable timeframe (1 week from post_date)
        $checkStmt = $conn->prepare("SELECT post_date FROM events WHERE id = ?");
        if ($checkStmt) {
            $checkStmt->bind_param("i", $id);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            if ($result->num_rows > 0) {
                $event = $result->fetch_assoc();
                $postDate = new DateTime($event['post_date']);
                $oneWeekAgo = new DateTime();
                $oneWeekAgo->modify('-7 days'); // Set to 1 week ago

                if ($postDate >= $oneWeekAgo) {
                    // Event is editable, proceed with update
                    $updateStmt = $conn->prepare("UPDATE events SET title = ?, details = ?, event_date = ? WHERE id = ?");
                    if ($updateStmt) {
                        $updateStmt->bind_param("sssi", $title, $details, $event_date, $id); // 'sssi' for string, string, string, integer
                        if ($updateStmt->execute()) {
                            $response['success'] = true;
                            $response['message'] = 'Event updated successfully.';
                            // Fetch the updated event to return its data (optional, but good for consistency)
                            $fetchStmt = $conn->prepare("SELECT id, title, details, post_date, event_date FROM events WHERE id = ?");
                            if ($fetchStmt) {
                                $fetchStmt->bind_param("i", $id);
                                $fetchStmt->execute();
                                $result = $fetchStmt->get_result();
                                if ($result->num_rows > 0) {
                                    $response['event'] = $result->fetch_assoc();
                                }
                                $fetchStmt->close();
                            }
                        } else {
                            $response['message'] = 'Failed to update event: ' . $updateStmt->error;
                        }
                        $updateStmt->close();
                    } else {
                        $response['message'] = 'Database update prepare error: ' . $conn->error;
                    }
                } else {
                    $response['message'] = 'Event is too old to be edited (only editable within 1 week of posting).';
                }
            } else {
                $response['message'] = 'Event not found.';
            }
            $checkStmt->close();
        } else {
            $response['message'] = 'Database check prepare error: ' . $conn->error;
        }
    }
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>
