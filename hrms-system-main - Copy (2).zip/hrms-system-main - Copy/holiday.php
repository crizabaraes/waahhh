<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $holidayType = $_POST['holidayType'] ?? '';
    $holidayName = $_POST['holidayName'] ?? '';
    $holidayDate = $_POST['holidayDate'] ?? '';

    // Validate required fields
    if (empty($holidayType) || empty($holidayName) || empty($holidayDate)) {
        $response['message'] = 'Missing required fields: Type, Name, or Date.';
    } else {
        // Map holidayType to ENUM values ('REGULAR' or 'SPECIAL')
        $mappedType = '';
        switch ($holidayType) {
            case 'Regular Holiday':
                $mappedType = 'REGULAR';
                break;
            case 'Special Non-working Holiday':
                $mappedType = 'SPECIAL';
                break;  
                
            default:
                $response['message'] = 'Invalid holiday type.';
                echo json_encode($response);
                exit;
        }

        // Prepare an insert statement (only for columns in the table)
        $stmt = $conn->prepare("INSERT INTO holidays (holiday_type, holiday_name, holiday_date) VALUES (?, ?, ?)");

        if ($stmt) {
            $stmt->bind_param("sss", $mappedType, $holidayName, $holidayDate);

            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Holiday marked successfully.';
            } else {
                $response['message'] = 'Failed to mark holiday: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $response['message'] = 'Database prepare error: ' . $conn->error;
        }
    }
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>