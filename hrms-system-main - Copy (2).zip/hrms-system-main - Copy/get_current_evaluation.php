<?php
require_once 'authentication/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'employees' => [], 'message' => ''];

$filterEmployeeId = $_GET['employee_id'] ?? null;
$filterQuarterName = $_GET['quarter_name'] ?? null;

try {
    if ($filterEmployeeId && $filterQuarterName) {
        // Fetch a single employee's evaluation for the selected quarter
        $stmt = $conn->prepare("SELECT evaluation_id, form_file_path, analysis_data, status 
                                FROM evaluations 
                                WHERE employee_id = ? AND quarter_name = ? LIMIT 1");
        $stmt->bind_param("ss", $filterEmployeeId, $filterQuarterName);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $response = array_merge(['success' => true], $row);
        } else {
            $response = ['success' => false, 'message' => 'Evaluation not found'];
        }
        $stmt->close();
    } else {
        // Original behavior: return all employees and their current-quarter evaluation status
        $currentMonth = (int)date('n');
        $currentYear = (int)date('Y');

        if ($currentMonth <= 3) $currentQuarterName = "Q4-". ($currentYear - 1);
        elseif ($currentMonth <= 6) $currentQuarterName = "Q1-{$currentYear}";
        elseif ($currentMonth <= 9) $currentQuarterName = "Q2-{$currentYear}";
        else $currentQuarterName = "Q3-{$currentYear}";

        $sql = "SELECT
                    e.id,
                    e.full_name,
                    e.branch,
                    e.position,
                    e.account_status,
                    COALESCE(eval.status, 'form_needed') AS evaluation_status,
                    COALESCE(eval.evaluation_id, NULL) AS evaluation_id,
                    COALESCE(eval.form_file_path, NULL) AS form_file_path,
                    COALESCE(eval.analysis_data, NULL) AS analysis_data
                FROM employees e
                LEFT JOIN evaluations eval 
                    ON e.id = eval.employee_id AND eval.quarter_name = ?
                WHERE LOWER(e.account_status) != 'deactivated'
                ORDER BY e.full_name ASC";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $currentQuarterName);
        $stmt->execute();
        $result = $stmt->get_result();

        $employees_data = [];
        while ($row = $result->fetch_assoc()) {
            $employees_data[] = $row;
        }
        $stmt->close();

        // Compute responses and warnings for each employee
        $branch_total_counts = [];
        foreach ($employees_data as $employee) {
            if (
                strtolower($employee['position'] ?? '') === 'human resources' ||
                strtolower($employee['account_status'] ?? '') === 'deactivated'
            ) {
                continue;
            }
            $branch = $employee['branch'];
            $branch_total_counts[$branch] = ($branch_total_counts[$branch] ?? 0) + 1;
        }

        $final_employees = [];
        foreach ($employees_data as $employee) {
            $warning_message = '';
            $responses_count = 0;

            if ($employee['evaluation_id']) {
                $stmt_responses_count = $conn->prepare("SELECT COUNT(*) FROM evaluation_responses WHERE evaluation_id = ?");
                $stmt_responses_count->bind_param("i", $employee['evaluation_id']);
                $stmt_responses_count->execute();
                $res_count = $stmt_responses_count->get_result()->fetch_row();
                $responses_count = $res_count[0];
                $stmt_responses_count->close();
            }

            if (empty($employee['form_file_path'])) {
                $warning_message = 'Form Needed';
                $responses_count = 0;
            } else {
                $totalPeers = $branch_total_counts[$employee['branch']] ?? 0;
                if ($responses_count < $totalPeers) {
                    $warning_message = "{$responses_count}/{$totalPeers} Responses";
                } elseif (empty($employee['analysis_data'])) {
                    $warning_message = 'Analysis Needed';
                } else {
                    $warning_message = 'Completed';
                }
            }

            $employee['warning_message'] = $warning_message;
            $employee['branch_total_count'] = $branch_total_counts[$employee['branch']] ?? 0;
            $employee['branch_evaluated_count'] = $branch_completed_counts[$employee['branch']] ?? 0;
            $employee['responses_count'] = $responses_count;

            $final_employees[] = $employee;
        }

        // 🔹 Fetch deactivated employees with their latest evaluation (history)
        $sql_deactivated = "
            SELECT 
                e.id,
                e.full_name,
                e.branch,
                e.position,
                e.account_status,
                eval.evaluation_id,
                eval.quarter_name,
                eval.form_file_path,
                eval.analysis_data,
                eval.status
            FROM employees e
            INNER JOIN evaluations eval 
                ON e.id = eval.employee_id
            WHERE LOWER(e.account_status) = 'deactivated'
            AND quarter_start_date = (
            SELECT MAX(e2.quarter_start_date)
                FROM evaluations e2
                WHERE e2.employee_id = e.id
            )
            ORDER BY e.full_name ASC
        ";
        $result_deactivated = $conn->query($sql_deactivated);
        $deactivated_employees = [];
        while ($row = $result_deactivated->fetch_assoc()) {
            $row['from_latest'] = true; // for frontend to show “History”
            $deactivated_employees[] = $row;
        }
        $all_employees = array_merge($final_employees, $deactivated_employees);


                $response['success'] = true;
                $response['current_quarter'] = $currentQuarterName;
                $response['employees'] = $all_employees;
            }
        } catch (Exception $e) {
            $response['message'] = 'Error fetching evaluations: ' . $e->getMessage();
            error_log("get_current_evaluation.php error: " . $e->getMessage());
        } finally {
            if ($conn) $conn->close();
        }
echo json_encode($response);
?>
