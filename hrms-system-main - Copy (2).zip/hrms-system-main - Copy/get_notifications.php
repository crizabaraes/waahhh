<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'notifications' => [], 'message' => ''];

try {
    // Optional: filter by employee_id if provided
    $employeeId = isset($_GET['employee_id']) ? (int)$_GET['employee_id'] : null;

    if ($employeeId) {
        $stmt = $conn->prepare("SELECT title, content, date_sent FROM notifications WHERE employee_id = ? ORDER BY date_sent DESC");
        $stmt->bind_param("s", $employeeId);
    } else {
        // If no employee_id, get all notifications
        $stmt = $conn->prepare("SELECT title, content, date_sent FROM notifications ORDER BY date_sent DESC");
    }

    $stmt->execute();
    $res = $stmt->get_result();

    while ($row = $res->fetch_assoc()) {
        $response['notifications'][] = [
            'title' => $row['title'],
            'content' => $row['content'],
            'date_sent' => $row['date_sent']
        ];
    }

    $response['success'] = true;

    $stmt->close();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("get_notifications.php error: " . $e->getMessage());
} finally {
    if ($conn) $conn->close();
}

echo json_encode($response);
?>
