document.addEventListener('DOMContentLoaded', function() {
    function getFileIconClass(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        if (ext === 'pdf') return 'fa-file-pdf';
        if (['doc', 'docx'].includes(ext)) return 'fa-file-word';
        if (['xls', 'xlsx'].includes(ext)) return 'fa-file-excel';
        if (['ppt', 'pptx'].includes(ext)) return 'fa-file-powerpoint';
        if (['txt', 'rtf', 'exe', 'bat', 'sh'].includes(ext)) return 'fa-file-alt';
        if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'svg'].includes(ext)) return 'fa-file-image';
        if (['mp4', 'avi', 'mov', 'flv', 'wmv', 'mkv'].includes(ext)) return 'fa-file-video';
        if (['mp3', 'wav', 'aac', 'flac', 'm4a'].includes(ext)) return 'fa-file-audio';
        if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) return 'fa-file-archive';
        return 'fa-file';
    }

    function getUniqueFileName(name, container) {
        const base = name.replace(/(\.\w+)$/, '');      // Remove extension
        const ext = name.match(/(\.\w+)$/)?.[0] || '';  // Extract extension
        let counter = 1;
        let uniqueName = name;

        // Search for both <p> and <h5> elements
        const existingNames = Array.from(container.querySelectorAll('p, h5'))
            .map(el => el.textContent);

        while (existingNames.includes(uniqueName)) {
            uniqueName = `${base} (${counter})${ext}`;
            counter++;
        }

        return uniqueName;
    }

    // Training Materials
    const addFileBtn = document.getElementById('addFileBtn');
    const addFileInput = document.getElementById('addFileInput');
    const trainingFileList = document.getElementById('trainingFileList');

    if (addFileBtn && addFileInput && trainingFileList) {
        addFileBtn.addEventListener('click', () => addFileInput.click());

        addFileInput.addEventListener('change', () => {
            const formData = new FormData();
            if (addFileInput.files.length > 0) {
                const originalFile = addFileInput.files[0];
                const uniqueFileName = getUniqueFileName(originalFile.name, trainingFileList);
                const uniqueFile = new File([originalFile], uniqueFileName, { type: originalFile.type });
                formData.append('trainingFile', uniqueFile);

                fetch('add_training.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        loadTrainings();
                        addFileInput.value = ''; // Clear the input field
                    } else {
                        console.error(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error adding training:', error);
                    showAlertModal('Error', 'An error occurred. Please try again.');
                });
            }

            addFileInput.value = ''; // Clear input
        });
    }

    // This function handles deleting a training file.
    function deleteTraining(id) {
        const formData = new FormData();
        formData.append('id', id);

        fetch('delete_training.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadTrainings();
            } else {
                console.error(data.message);
            }
        })
        .catch(error => {
            console.error('Error deleting training:', error);
            showAlertModal('Error', 'An error occurred. Please try again.');
        });
    }

    // This helper function creates the appropriate preview element based on file type.
    function createPreviewElement(filepath, filename) {
        const previewContainer = document.createElement('div');
        previewContainer.className = 'file-preview-container mb-3 text-center';

        const extension = filename.split('.').pop().toLowerCase();
        const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'svg'];
        const videoExtensions = ['mp4', 'avi', 'mov', 'flv', 'wmv', 'mkv'];
        const audioExtensions = ['mp3', 'wav', 'aac', 'flac', 'm4a'];
        const pdfExtensions = ['pdf'];

        let mediaElement;

        if (imageExtensions.includes(extension)) {
            mediaElement = document.createElement('img');
            mediaElement.className = 'file-preview-img rounded-3';
            mediaElement.src = filepath;
            mediaElement.alt = `Preview of ${filename}`;
        } else if (videoExtensions.includes(extension)) {
            mediaElement = document.createElement('video');
            mediaElement.className = 'file-preview-video rounded-3';
            mediaElement.src = filepath;
            mediaElement.controls = true; // Add controls for play/pause
        } else if (audioExtensions.includes(extension)) {
            mediaElement = document.createElement('audio');
            mediaElement.className = 'file-preview-audio rounded-3';
            mediaElement.src = filepath;
            mediaElement.controls = true; // Add controls for play/pause
        } else if (pdfExtensions.includes(extension)) {
            mediaElement = document.createElement('embed');
            mediaElement.className = 'file-preview-embed rounded-3';
            mediaElement.src = filepath;
            mediaElement.type = 'application/pdf';
        } else {
            // Fallback for all other file types
            const iconWrapper = document.createElement('div');
            iconWrapper.className = 'icon-wrapper';
            const icon = document.createElement('i');
            icon.className = `fas ${getFileIconClass(filename)} text-primary-soft-blue fs-1`;
            iconWrapper.appendChild(icon);
            previewContainer.appendChild(iconWrapper);
            return previewContainer; // Return here as no other element needs to be appended
        }

        previewContainer.appendChild(mediaElement);
        return previewContainer;
    }

    let deleteBtn;
    // This function loads the trainings from the database and displays them.
    function loadTrainings() {
        return fetch('fetch_trainings.php')
            .then(response => response.json())
            .then(data => {
                const trainingFileList = document.getElementById('trainingFileList');
                if (!trainingFileList) {
                    console.error("Training list container not found. Check your HTML for id='trainingFileList'.");
                    return;
                }
                
                trainingFileList.innerHTML = '';

                if (data.success && data.trainings.length > 0) {
                    data.trainings.forEach(training => {
                        const col = document.createElement('div');
                        col.className = 'col-12 col-md-6 d-flex';
                        col.setAttribute('data-id', training.id);

                        const card = document.createElement('div');
                        card.className = 'card training-card p-3 d-flex flex-column justify-content-between bg-secondary-light-beige';
                        
                        // Create and append the file preview at the top of the card
                        const previewElement = createPreviewElement(training.filepath, training.filename);
                        card.appendChild(previewElement);

                        // Re-create your original header and footer below the preview
                        const header = document.createElement('div');
                        header.className = 'd-flex align-items-center justify-content-between mb-3';

                        const left = document.createElement('div');
                        left.className = 'd-flex align-items-center';

                        const title = document.createElement('h5');
                        title.className = 'fs-6 text-text-dark-grey fw-semibold mb-0';
                        title.textContent = training.filename;

                        left.appendChild(title);

                        const right = document.createElement('div');
                        right.className = 'd-flex align-items-center gap-2';

                        deleteBtn = document.createElement('button');
                        deleteBtn.className = 'btn btn-sm btn-outline-danger delete-training-btn';
                        deleteBtn.setAttribute('data-id', training.id);
                        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';

                        right.appendChild(deleteBtn);
                        header.appendChild(left);
                        header.appendChild(right);
                        
                        const footer = document.createElement('div');
                        footer.className = 'd-flex justify-content-between align-items-center';

                        const downloadBtn = document.createElement('a');
                        downloadBtn.className = 'text-primary-soft-blue text-decoration-none';
                        downloadBtn.href = training.filepath;
                        downloadBtn.download = training.filename;
                        downloadBtn.innerHTML = '<i class="fas fa-download"></i>';

                        const viewLink = document.createElement('a');
                        viewLink.className = 'text-primary-soft-blue text-decoration-none fw-medium small';
                        viewLink.href = training.filepath;
                        viewLink.target = '_blank';
                        viewLink.innerHTML = 'View File <i class="fas fa-arrow-right ms-1"></i>';

                        footer.appendChild(downloadBtn);
                        footer.appendChild(viewLink);

                        card.appendChild(header);
                        card.appendChild(footer);
                        col.appendChild(card);
                        trainingFileList.appendChild(col);
                    });
                    
                    document.querySelectorAll('.delete-training-btn').forEach(button => {
                        button.addEventListener('click', function() {
                            const id = this.getAttribute('data-id');
                            showDeleteModal(id);
                        });
                    });
                } else {
                    trainingFileList.innerHTML = '<p class="text-center text-muted-grey mt-4">No training materials found.</p>';
                }
            })
            .catch(error => {
                console.error('Error fetching trainings:', error);
                const trainingFileList = document.getElementById('trainingFileList');
                if(trainingFileList) trainingFileList.innerHTML = '<p class="text-center text-danger mt-4">Failed to load trainings. Please try again.</p>';
            });
    }

    // Event listener for the "Yes" button in the delete modal
    const confirmDeleteYes = document.getElementById('confirmDeleteYes');
    if (confirmDeleteYes) {
        confirmDeleteYes.addEventListener('click', function() {
            if (trainingIdToDelete) {
                deleteTraining(trainingIdToDelete); // Call the deletion function
                hideDeleteModal(); // Hide the modal
            }
        });
    }

    // Event listener for the "No" button in the delete modal
    const confirmDeleteNo = document.getElementById('confirmDeleteNo');
    if (confirmDeleteNo) {
        confirmDeleteNo.addEventListener('click', hideDeleteModal);
    }

    const deleteTrainingModal = document.getElementById('deleteTrainingModal');
    if (deleteTrainingModal) {
        deleteTrainingModal.addEventListener('click', (event) => {
            if (event.target === deleteTrainingModal) {
                deleteTrainingModal.classList.add('d-none');
            }
        });
    }

    // Function to show the delete confirmation modal
    let trainingIdToDelete = null; // To hold the ID of the training to be deleted
    function showDeleteModal(id) {
        trainingIdToDelete = id; // Store the ID for later
        const deleteModal = document.getElementById('deleteTrainingModal');
        if (deleteModal) {
            deleteModal.classList.remove('d-none');
        }
    }

    // Function to hide the delete confirmation modal
    function hideDeleteModal() {
        const deleteModal = document.getElementById('deleteTrainingModal');
        if (deleteModal) {
            deleteModal.classList.add('d-none');
            trainingIdToDelete = null; // Clear the stored ID
        }
    }

    loadTrainings().then(() => {
        const email = localStorage.getItem('userEmail');

        if (email) {
            fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.owner.length > 0) {
                        const emp = data.owner[0];
                        const position = emp.position.trim();

                        if (position && (position.toLowerCase() === 'owner' || position.toLowerCase() === 'employee')) {
                            addFileBtn.style.visibility = 'hidden';

                            document.querySelectorAll('.delete-training-btn').forEach(btn => {
                                btn.style.visibility = 'hidden';
                            });
                        }
                    }
                })
                .catch(err => console.error(err));
        }
    });
});