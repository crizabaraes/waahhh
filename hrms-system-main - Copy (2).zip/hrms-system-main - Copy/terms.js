document.addEventListener('DOMContentLoaded', function() {
    const type = 'Terms';
    const content = document.getElementById('termsContent').innerHTML.trim();
    const versionHeader = document.getElementById('versionHeader');
    let versionDate = '';
    let versionNumber = '';

    if (versionHeader) {
        // Extract date
        versionDate = versionHeader.querySelector('strong')?.textContent || '';

        // Convert to YYYY-MM-DD
        if (versionDate) {
            const parsedDate = new Date(versionDate);
            if (!isNaN(parsedDate)) {
                const yyyy = parsedDate.getFullYear();
                const mm = String(parsedDate.getMonth() + 1).padStart(2, '0');
                const dd = String(parsedDate.getDate()).padStart(2, '0');
                versionDate = `${yyyy}-${mm}-${dd}`;
            }
        }

        // Extract version
        const versionText = versionHeader.querySelector('p')?.textContent || '';
        const match = versionText.match(/Version\s+([\d.]+)/);
        if (match) {
            versionNumber = match[1]; // now it will be "1.0.0"
        }
    }

    // Send to PHP
    fetch('terms_privacy.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            action: 'add_compliance',
            type,
            version: versionNumber,
            content,
            date: versionDate
        })
    })
    .then(res => res.json())
    .then(data => {
        loadTermsArchive();
    })
    .catch(console.error);

    // --- Add this inside DOMContentLoaded ---
    function loadTermsArchive() {
        fetch('terms_privacy.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'get_compliance',
                type: 'Terms' // match exactly what's in your DB
            })
        })
        .then(res => res.json())
        .then(versions => {
            const archiveList = document.getElementById('termsArchiveList');
            archiveList.innerHTML = ''; // clear previous items

            if (!versions || versions.length === 0) {
                archiveList.innerHTML = '<li class="text-text-muted-grey">No archived versions yet.</li>';
                return;
            }

            versions.forEach(v => {
                const li = document.createElement('li');
                li.className = 'mb-2';

                const versionDisplay = v.version;
                const publishedDate = new Date(v.date);
                const formattedDate = publishedDate.toLocaleDateString('en-US', {
                    year: 'numeric', month: 'long', day: 'numeric'
                });

                // Create clickable link
                const link = document.createElement('a');
                link.href = '#';
                link.className = 'text-accent-peach text-decoration-none';
                link.textContent = `Version ${versionDisplay} (Published: ${formattedDate})`;

                link.addEventListener('click', (e) => {
                    e.preventDefault();

                    // Update versionHeader
                    const versionHeader = document.getElementById('versionHeader');
                    if (versionHeader) {
                        versionHeader.innerHTML = `
                            <h5 class="fw-semibold text-text-dark-grey mb-1">Last Updated</h5>
                            <p class="mb-0 text-text-muted-grey">
                                <strong class="text-accent-peach">${formattedDate}</strong> — Version <strong>${versionDisplay}</strong>
                            </p>
                        `;
                    }

                    // Update termsContent
                    const termsContent = document.getElementById('termsContent');
                    if (termsContent) {
                        termsContent.innerHTML = v.content;
                        window.scrollTo(0, 0);
                    }
                });
                li.appendChild(link);
                archiveList.appendChild(li);
            });
        })
        .catch(err => console.error(err));
    }

loadTermsArchive();
});