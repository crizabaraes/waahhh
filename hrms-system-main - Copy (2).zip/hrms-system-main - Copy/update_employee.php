<?php
require_once 'authentication/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'new_picture_path' => ''];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method.';
    echo json_encode($response);
    exit;
}

// Determine action: 'upload_picture' or 'update_info'
$action = $_POST['action'] ?? '';

try {
    if ($action === 'upload_picture') {
        // --- Profile picture upload ---
        $id = trim($_POST['id'] ?? '');
        if (!$id) throw new Exception('Employee ID is required.');

        if (!isset($_FILES['profile_picture']) || $_FILES['profile_picture']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('No picture uploaded or upload error.');
        }

        $fileTmpPath   = $_FILES['profile_picture']['tmp_name'];
        $fileName      = $_FILES['profile_picture']['name'];
        $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
        $newFileName   = uniqid('profilepic_', true) . '.' . $fileExtension;

        $uploadDir = 'uploads/profile_pictures/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

        $destPath = $uploadDir . $newFileName;
        if (!move_uploaded_file($fileTmpPath, $destPath)) {
            throw new Exception('Failed to move uploaded file.');
        }

        $stmt = $conn->prepare("UPDATE employees SET picture_file_path = ? WHERE id = ?");
        $stmt->bind_param("ss", $destPath, $id);
        if (!$stmt->execute()) throw new Exception('Database update failed: ' . $stmt->error);
        $stmt->close();

        $response['success'] = true;
        $response['message'] = 'Profile picture updated.';
        $response['new_picture_path'] = $destPath;

    } elseif ($action === 'update_info') {
        // --- Update employee info ONLY ---
        $id = trim($_POST['id'] ?? '');
        if (!$id) throw new Exception('Employee ID is required for update.');

        // Collect fields
        $full_name         = trim($_POST['full_name'] ?? '');
        $contact_number    = trim($_POST['contact_number'] ?? '');
        $address           = trim($_POST['address'] ?? '');
        $birthday          = $_POST['birthday'] ?? '';
        $age               = (int)($_POST['age'] ?? 0);
        $sex               = $_POST['sex'] ?? '';
        $civil_status      = $_POST['civil_status'] ?? '';
        $branch            = trim($_POST['branch'] ?? '');
        $position          = trim($_POST['position'] ?? '');
        $date_joined       = $_POST['date_joined'] ?? '';
        $monthly_salary    = (float)($_POST['monthly_salary'] ?? 0.0);
        $sss_contribution  = (int)($_POST['sss_contribution'] ?? 0);
        $hdmf_contribution = (int)($_POST['hdmf_contribution'] ?? 0);
        $phic_contribution = (int)($_POST['phic_contribution'] ?? 0);
        $work_shift_start  = $_POST['work_shift_start'] ?? '';
        $work_shift_end    = $_POST['work_shift_end'] ?? '';
        $rest_day          = $_POST['rest_day'] ?? '';
        // --- Optional password change ---
        $old_password      = trim($_POST['old_password'] ?? '');
        $new_password      = trim($_POST['new_password'] ?? '');

        $conn->begin_transaction();

        // Handle password change only if old password was entered
        if (!empty($old_password)) {
            // Fetch current password and work_email of this employee
            $passCheckStmt = $conn->prepare("SELECT password, work_email FROM employees WHERE id = ?");
            $passCheckStmt->bind_param("s", $id);
            $passCheckStmt->execute();
            $passRes = $passCheckStmt->get_result();

            if ($passRes->num_rows === 0) {
                throw new Exception("Employee record not found.");
            }

            $row = $passRes->fetch_assoc();
            $current_password = $row['password'];
            $work_email = $row['work_email'];
            $passCheckStmt->close();

            // Verify old password against hash
            if (!password_verify($old_password, $current_password)) {
                throw new Exception("Old Password is incorrect.");
            }
            
            // Hash the new password
            $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

            // Update in both tables
            $updateEmpPass = $conn->prepare("UPDATE employees SET password = ? WHERE id = ?");
            $updateEmpPass->bind_param("ss", $hashedPassword, $id);
            if (!$updateEmpPass->execute()) throw new Exception("Failed to update employee password.");
            $updateEmpPass->close();

            $updateLoginPass = $conn->prepare("UPDATE login_credentials SET password = ? WHERE email = ?");
            $updateLoginPass->bind_param("ss", $hashedPassword, $work_email);
            if (!$updateLoginPass->execute()) throw new Exception("Failed to update login password.");
            $updateLoginPass->close();
        }

        if (strtolower($position) === 'human resources') {
            // Check if any employee already has this position
            $stmt_hr = $conn->prepare("SELECT COUNT(*) as hr_count FROM employees WHERE LOWER(position) = 'human resources'");
            if (!$stmt_hr) {
                throw new Exception('Prepare statement failed (HR check): ' . $conn->error);
            }
            $stmt_hr->execute();
            $result_hr = $stmt_hr->get_result()->fetch_assoc();
            $stmt_hr->close();

            if ($result_hr['hr_count'] > 0) {
                // Already exists → throw error
                $response['success'] = false;
                $response['message'] = 'There is already an employee with the position "Human Resources".';
                echo json_encode($response);
                exit; // stop execution
            }
        }

        // Update employees table (without touching picture_file_path)
        $sql = "UPDATE employees SET 
                    full_name = ?, contact_number = ?, address = ?, 
                    birthday = ?, age = ?, sex = ?, civil_status = ?, 
                    branch = ?, position = ?, date_joined = ?, monthly_salary = ?, 
                    sss_contribution = ?, hdmf_contribution = ?, phic_contribution = ?, 
                    work_shift_start = ?, work_shift_end = ?, rest_day = ?
                WHERE id = ?";

        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);

        $stmt->bind_param( 
            "ssssisssssdiiissss", 
            $full_name, $contact_number, $address, $birthday, $age, $sex, $civil_status,
            $branch, $position, $date_joined, $monthly_salary, $sss_contribution, $hdmf_contribution, $phic_contribution, 
            $work_shift_start, $work_shift_end, $rest_day, $id
        );

        if (!$stmt->execute()) throw new Exception('Execute failed (employees): ' . $stmt->error);
        $stmt->close();

        $relatedTables = [
            'employee_education' => ['education_data', ['id','school','academic_year','course_strand','special_notes'], 'id'],
            'employee_work_experience' => ['work_experience_data', ['id','company','length_of_service','position','duties_achievements'], 'id'],
            'employee_trainings' => ['training_data', ['id','training_name','date_attended','notes'], 'id'],
            'employee_certificates' => ['certificates_data', ['id','certificate_name','issuing_body','date_issued'], 'id'],
            'employee_skills' => ['skills_data', ['id','skill_name'], 'id']
        ];

        foreach ($relatedTables as $table => [$postKey, $columns, $keyColumn]) {
            if (!empty($_POST[$postKey])) {
                $data = json_decode($_POST[$postKey], true);
                if (json_last_error() !== JSON_ERROR_NONE) throw new Exception("Invalid JSON for $postKey");

                foreach ($data as $row) {
                    if (isset($row[$keyColumn]) && !empty($row[$keyColumn])) {
                        // Row exists: UPDATE
                        $updateCols = array_filter($columns, fn($c) => $c !== $keyColumn);
                        $setStr = implode(", ", array_map(fn($c) => "$c = ?", $updateCols));
                        $stmt = $conn->prepare("UPDATE $table SET $setStr WHERE id = ?");
                        $types = str_repeat("s", count($updateCols)) . "s";
                        $values = array_map(fn($c) => $row[$c] ?? null, $updateCols);
                        $values[] = $row[$keyColumn];
                        $stmt->bind_param($types, ...$values);
                        if (!$stmt->execute()) throw new Exception("Update failed ($table): " . $stmt->error);
                        $stmt->close();
                    } else {
                        // Row does not exist: INSERT
                        $insertCols = array_merge(['employee_id'], array_filter($columns, fn($c) => $c !== $keyColumn));
                        $placeholders = implode(", ", array_fill(0, count($insertCols), "?"));
                        $stmt = $conn->prepare("INSERT INTO $table (" . implode(", ", $insertCols) . ") VALUES ($placeholders)");
                        $types = str_repeat("s", count($insertCols));
                        $values = [$id];
                        foreach ($insertCols as $col) {
                            if ($col !== 'employee_id') $values[] = $row[$col] ?? null;
                        }
                        $stmt->bind_param($types, ...$values);
                        if (!$stmt->execute()) throw new Exception("Insert failed ($table): " . $stmt->error);
                        $stmt->close();
                    }
                }
            }
        }

        if (!empty($_POST['deleted_ids'])) {
            $idsToDelete = explode(',', $_POST['deleted_ids']);

            // Tables that use simple "id" primary key deletions
            $tablesToDeleteFrom = [
                'employee_education',
                'employee_work_experience',
                'employee_trainings',
                'employee_certificates',
                'employee_skills'
            ];

            foreach ($idsToDelete as $deleteId) {
                $deleteId = intval($deleteId);
                foreach ($tablesToDeleteFrom as $table) {
                    $conn->query("DELETE FROM $table WHERE id = $deleteId");
                }
            }
        }

        $conn->commit();
        $response['success'] = true;
        $response['message'] = "Employee $id updated successfully.";

    } else {
        throw new Exception('Invalid action.');
    }

} catch (Exception $e) {
    if ($conn->in_transaction) $conn->rollback();
    $response['message'] = 'Error: ' . $e->getMessage();
    error_log("update_employee.php error: " . $e->getMessage());
}

$conn->close();
echo json_encode($response);
?>
