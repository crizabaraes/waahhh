<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['employee_id'], $data['fingerprint_id'])) {
        throw new Exception('employee_id and fingerprint_id are required.');
    }

    $employee_id = $data['employee_id'];
    $fingerprint_id = $data['fingerprint_id'];

    error_log("Received employee_id: $employee_id, fingerprint_id: $fingerprint_id");

    $stmt = $conn->prepare("UPDATE employees SET fingerprint_id = ? WHERE id = ?");
    $stmt->bind_param("is", $fingerprint_id, $employee_id);
    
    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Fingerprint ID updated successfully.';
    } else {
        throw new Exception($stmt->error);
    }

    $stmt->close();
} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
}

$conn->close();
echo json_encode($response);
?>
