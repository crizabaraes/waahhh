<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    // Determine the CURRENT CUSTOM QUARTER and its start date
    $today = new DateTime();
    $currentMonth = (int)$today->format('n');
    $currentDay = (int)$today->format('j');
    $currentYear = (int)$today->format('Y');

    if (!in_array($currentMonth, [1, 4, 7, 10]) || $currentDay !== 1) {
        exit;
    }

    $quarterName = '';
    $quarterStartDate = '';

    if ($currentMonth <= 3) { // covers work period of October, November, December
        $quarterName = "Q4-". ($currentYear - 1);
        $quarterStartDate = "{$currentYear}-01-01";
    } elseif ($currentMonth <= 6) { // January, February, March
        $quarterName = "Q1-{$currentYear}";
        $quarterStartDate = "{$currentYear}-04-01";
    } elseif ($currentMonth <= 9) { // April, May, June 
        $quarterName = "Q2-{$currentYear}";
        $quarterStartDate = "{$currentYear}-07-01";
    } else { // July, August, September
        $quarterName = "Q3-{$currentYear}";
        $quarterStartDate = "{$currentYear}-10-01";
    }

    // Start a transaction for atomicity
    $conn->begin_transaction();

    // Get all active employee_ids
    $stmt_employees = $conn->prepare("SELECT id FROM employees WHERE LOWER(position) != 'human resources' AND LOWER(account_status) != 'deactivated'");
    if (!$stmt_employees) {
        throw new Exception('Prepare statement failed (get employees): ' . $conn->error);
    }
    if (!$stmt_employees->execute()) {
        throw new Exception('Execute statement failed (get employees): ' . $stmt_employees->error);
    }
    $result_employees = $stmt_employees->get_result();
    $employee_ids = [];
    while ($row = $result_employees->fetch_assoc()) {
        $employee_ids[] = $row['id'];
    }
    $stmt_employees->close();

    foreach ($employee_ids as $employee_id) {
        // Check if this employee already has an evaluation for this quarter
        $stmt_check = $conn->prepare("SELECT evaluation_id FROM evaluations WHERE employee_id = ? AND quarter_name = ?");
        $stmt_check->bind_param("ss", $employee_id, $quarterName);
        $stmt_check->execute();
        $exists = $stmt_check->get_result()->num_rows > 0;
        $stmt_check->close();

        // Only insert if it doesn't exist yet
        if ($exists) {
            continue;
        }
        $stmt_date = $conn->prepare("SELECT date_joined FROM employees WHERE id = ?");
        $stmt_date->bind_param("s", $employee_id);
        $stmt_date->execute();
        $result_date = $stmt_date->get_result();
        $row_date = $result_date->fetch_assoc();
        $stmt_date->close();

        if (!$row_date) {
            continue; // safety check
        }
        $currentDate = new DateTime();
        $currentDate->setDate($currentYear, $currentMonth, 1);
        $currentDate->setTime(0, 0, 0);

        // Calculate two months ago
        $twoMonthsAgo = (clone $currentDate)->modify('-2 months');
        $date_joined = new DateTime($row_date['date_joined']);

        if ($date_joined > $twoMonthsAgo) {
            // Employee joined less than 2 months ago, skip generating evaluation
            continue;
        }

        $stmt_insert = $conn->prepare("INSERT INTO evaluations (employee_id, quarter_name, quarter_start_date, status) VALUES (?, ?, ?, 'form_needed')");
        if (!$stmt_insert) {
            throw new Exception('Prepare statement failed (insert evaluation): ' . $conn->error);
        }
        $stmt_insert->bind_param("sss", $employee_id, $quarterName, $quarterStartDate);
        if (!$stmt_insert->execute()) {
            throw new Exception('Execute statement failed (insert evaluation for employee ' . $employee_id . '): ' . $stmt_insert->error);
        }
        $stmt_insert->close();
    }
    $conn->commit();
    $response['success'] = true;
    $response['message'] = "Evaluations for {$quarterName} ensured for all active employees.";
} catch (Exception $e) {
    $conn->rollback();
    $response['message'] = 'Error generating quarter evaluations: ' . $e->getMessage();
    error_log("generate_evaluation_quarter.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>
