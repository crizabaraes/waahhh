<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $evaluation_id = $_POST['evaluation_id'] ?? null;
    $email = trim($_POST['email'] ?? '');

    if (!$evaluation_id || empty($email)) {
        throw new Exception('Evaluation ID and email are required.');
    }

    $stmt = $conn->prepare("SELECT id FROM employees WHERE work_email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$row = $result->fetch_assoc()) {
        throw new Exception("Employee not found for the provided email.");
    }
    $employee_id = $row['id'];
    $stmt->close();


    if (!isset($_FILES['response_file']) || $_FILES['response_file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error.');
    }

    $file = $_FILES['response_file'];
    $fileName = basename($file['name']);
    $fileTmpName = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileError = $file['error'];
    $fileType = $file['type'];

    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowed = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

    if (!in_array($fileExt, $allowed)) {
        throw new Exception('Invalid file type. Only PDF, DOC, DOCX, JPG, JPEG, PNG are allowed.');
    }
    if ($fileSize > 10000000) { // 10MB max file size
        throw new Exception('File is too large (max 10MB).');
    }
    if ($fileError !== 0) {
        throw new Exception('There was an error uploading your file.');
    }

    // Create uploads directory if it doesn't exist
    $uploadDir = 'uploads/evaluation_responses/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Create recursively with full permissions
    }

    // Generate a unique file name
    $fileNewName = uniqid('resp_', true) . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '', str_replace(' ', '_', $employee_id)) . '.' . $fileExt;
    $filePath = $uploadDir . $fileNewName;

    if (!move_uploaded_file($fileTmpName, $filePath)) {
        throw new Exception('Failed to move uploaded file.');
    }

    // Start a transaction
    $conn->begin_transaction();

    // Insert new response record
    $stmt = $conn->prepare("INSERT INTO evaluation_responses (evaluation_id, employee_id, response_file_path) VALUES (?, ?, ?)");
    if (!$stmt) {
        throw new Exception('Prepare statement failed (response): ' . $conn->error);
    }
    $stmt->bind_param("iss", $evaluation_id, $employee_id, $filePath);

    if (!$stmt->execute()) {
        throw new Exception('Execute statement failed (response): ' . $stmt->error);
    }
    $stmt->close();

    $conn->commit();
    $response['success'] = true;
    $response['message'] = 'Response file uploaded successfully.';

} catch (Exception $e) {
    $conn->rollback();
    // If file was moved but DB update failed, try to delete the file
    if (isset($filePath) && file_exists($filePath)) {
        unlink($filePath);
    }
    $response['message'] = 'Error uploading response: ' . $e->getMessage();
    error_log("submit_evaluation_response.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>
