document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const evaluationPageHeaderTitle = document.getElementById('evaluationPageHeaderTitle');
    const evaluationResponsesArea = document.getElementById('evaluationResponsesArea');
    const noResponsesMessage = document.getElementById('noResponsesMessage');
    const hrAnalysisTextarea = document.getElementById('hrAnalysisTextarea');
    const sendAnalysisBtn = document.getElementById('sendAnalysisBtn');
    const uploadEvaluationInput = document.getElementById('uploadEvaluationInput');
    const employeeResponseInput = document.getElementById('employeeResponseInput');
    const evaluationForm = document.getElementById('uploadHrForm');
    const formContainer = document.getElementById('formContainer');
    const clearUploadedFileBtn = document.getElementById('clearUploadedFileBtn');
    const clearUploadedFileBtn2 = document.getElementById('clearUploadedFileBtn2');

    const evaluationPeriodQuarterFilter = document.getElementById('evaluationPeriodQuarterFilter');
    const evaluationPeriodYearFilter = document.getElementById('evaluationPeriodYearFilter');
    const confirmUploadModal = document.getElementById('confirmUploadModal');
    const confirmUploadYes = document.getElementById('confirmUploadYes');
    const confirmUploadNo = document.getElementById('confirmUploadNo');
    const customAlertModal = document.getElementById('customAlertModal');
    const customAlertTitle = document.getElementById('customAlertTitle');
    const customAlertMessage = document.getElementById('customAlertMessage');

    let currentEvaluationId = null;
    let currentEmployeeName = null;
    let currentQuarterName = null;
    let currentQuarterYear = null;
    let currentEmployeeId = null;
    let currentHrFormFilePath = null;

    function showModal(modalId, title = null, message = null) {
        if (!modalId) return;

        // If title/message are provided, assume it’s an alert-style modal
        if (title !== null) {
            customAlertTitle.textContent = title;
            customAlertMessage.textContent = message;
            customAlertModal.classList.remove('d-none');
        }

        modalId.classList.remove('d-none');
    }

    function hideModal(modalId) {
        if (!modalId) return;
        modalId.classList.add('d-none');
    }
    
    // Close modal if backdrop clicked
    if (confirmUploadModal) {
        confirmUploadModal.addEventListener('click', (event) => {
            if (event.target === confirmUploadModal) {
                confirmUploadModal.classList.add('d-none');
            }
        });
    }

    function adjustAnalysisTextareaHeight() {
        if (!hrAnalysisTextarea) return;
        hrAnalysisTextarea.style.height = currentHrFormFilePath ? '358.2px' : '218px';
    }

    // Function to render response cards
    function renderResponses(responses) {
        evaluationResponsesArea.innerHTML = ''; 

        if (responses.length === 0) {
            noResponsesMessage.classList.remove('d-none');
            evaluationResponsesArea.appendChild(noResponsesMessage);
            return;
        }

        noResponsesMessage.classList.add('d-none');

        responses.forEach(response => {
            const fileName = response.response_file_path.split('/').pop();
            const ext = fileName.split('.').pop().toLowerCase();

            let iconClass;
            switch (ext) {
                case 'pdf': iconClass = 'fas fa-file-pdf'; break;
                case 'doc':
                case 'docx': iconClass = 'fas fa-file-word'; break;
                case 'jpg':
                case 'jpeg':
                case 'png': iconClass = 'fas fa-file-image'; break;
                default: iconClass = 'fas fa-file'; break;
            }

            const col = document.createElement('div');
            col.className = 'col-12 col-md-6 mb-3';

            const card = document.createElement('div');
            card.className = 'p-3 rounded-4 bg-white border shadow d-flex flex-column';
            card.style.height = '260px';
            card.style.transition = '0.2s ease';

            card.addEventListener('mouseenter', () => {
                card.style.boxShadow = '0 8px 20px rgba(0,0,0,0.18)';
                card.style.transform = 'translateY(-2px)';
            });
            card.addEventListener('mouseleave', () => {
                card.style.boxShadow = '';
                card.style.transform = '';
            });

            const iconWrapper = document.createElement('div');
            iconWrapper.className = 'mb-2';

            const icon = document.createElement('i');
            icon.className = `${iconClass} text-primary-soft-blue fs-3`;

            iconWrapper.appendChild(icon);

            const fullNameElem = document.createElement('h5');
            fullNameElem.className = 'text-text-dark-grey fw-semibold mb-1';
            fullNameElem.textContent = response.full_name;

            const fileNameElem = document.createElement('div');
            fileNameElem.className = 'text-text-muted-grey small mb-3';
            fileNameElem.textContent = fileName;

            const footer = document.createElement('div');
            footer.className = 'd-flex justify-content-between mt-auto w-100';

            const downloadBtn = document.createElement('a');
            downloadBtn.className = 'text-primary-soft-blue text-decoration-none';
            downloadBtn.href = response.response_file_path;
            downloadBtn.download = fileName;
            downloadBtn.innerHTML = '<i class="fas fa-download"></i>';

            const viewLink = document.createElement('a');
            viewLink.className = 'text-primary-soft-blue text-decoration-none fw-medium small';
            viewLink.href = response.response_file_path;
            viewLink.target = '_blank';
            viewLink.innerHTML = 'View File <i class="fas fa-arrow-right ms-1"></i>';

            footer.appendChild(downloadBtn);
            footer.appendChild(viewLink);

            card.appendChild(iconWrapper);
            card.appendChild(fullNameElem);
            card.appendChild(fileNameElem);
            card.appendChild(footer);

            col.appendChild(card);
            evaluationResponsesArea.appendChild(col);
        });
    }

    function getFileIconClass(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        if (ext === 'pdf') return 'fa-file-pdf';
        if (['doc', 'docx'].includes(ext)) return 'fa-file-word';
        if (['xls', 'xlsx'].includes(ext)) return 'fa-file-excel';
        if (['txt', 'rtf', 'exe', 'bat', 'sh'].includes(ext)) return 'fa-file-alt';
        if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'svg'].includes(ext)) return 'fa-file-image';
        if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) return 'fa-file-archive';
        return 'fa-file';
    }

    function renderUploadedFileCard(filename, filepath) {
        if (!formContainer) return;

        // Clear existing content in the formContainer
        formContainer.innerHTML = '';
        
        // Create the main card container
        const card = document.createElement('div');
        card.className = 'uploaded-form card training-card p-3 d-flex flex-column justify-content-between bg-secondary-light-beige w-100';

        // Create the header section
        const header = document.createElement('div');
        header.className = 'd-flex align-items-center justify-content-between mb-3';

        // Create the left side of the header (icon and title)
        const left = document.createElement('div');
        left.className = 'd-flex align-items-center';
        
        const iconWrapper = document.createElement('div');
        iconWrapper.className = 'icon-wrapper me-3';
        
        const icon = document.createElement('i');
        icon.className = `fas ${getFileIconClass(filename)} text-primary-soft-blue fs-4`;
        
        const title = document.createElement('h5');
        title.className = 'fs-6 text-text-dark-grey fw-semibold mb-0';
        title.textContent = filename;
        
        iconWrapper.appendChild(icon);
        left.appendChild(iconWrapper);
        left.appendChild(title);

        // Append left and right to the header
        header.appendChild(left);

        // Create the footer section
        const footer = document.createElement('div');
        footer.className = 'd-flex justify-content-between align-items-center';

        // Download Button
        const downloadBtn = document.createElement('a');
        downloadBtn.className = 'text-primary-soft-blue text-decoration-none';
        downloadBtn.href = filepath;
        downloadBtn.download = filename;
        downloadBtn.innerHTML = '<i class="fas fa-download"></i>';

        // View File Link
        const viewLink = document.createElement('a');
        viewLink.className = 'text-primary-soft-blue text-decoration-none fw-medium small';
        viewLink.href = filepath;
        viewLink.target = '_blank';
        viewLink.innerHTML = 'View File <i class="fas fa-arrow-right ms-1"></i>';

        // Append elements to the footer
        footer.appendChild(downloadBtn);
        footer.appendChild(viewLink);
        
        // Append the header and footer to the main card container
        card.appendChild(header);
        card.appendChild(footer);
        
        // Finally, append the complete card to the display area
        formContainer.appendChild(card);
    }

    function updateHrFormFileDisplay() {
    const hrFormFileDisplay = document.getElementById('hrFormFileDisplay');
    if (hrFormFileDisplay && formContainer) {
        hrFormFileDisplay.innerHTML = formContainer.innerHTML;
    }
}


    async function loadEvaluationDetails(evalId, quarterName, quarterYear) {
        try {
            const url = `get_evaluation_details.php?evaluation_id=${evalId}&quarter_name=${quarterName}&employee_id=${currentEmployeeId}`;
            const response = await fetch(url);
            const result = await response.json();

            if (result.success) {
                const evalData = result.evaluation;
                if (evalData) {
                    // Render Responses
                    renderResponses(result.responses);

                    // HR Form File
                    if (evalData.form_file_path) {
                        renderUploadedFileCard(evalData.form_file_path.split('/').pop(), evalData.form_file_path);
                        evaluationForm.style.display = 'none';
                        currentHrFormFilePath = evalData.form_file_path;
                        updateHrFormFileDisplay();
                    } else {
                        formContainer.innerHTML = '<span class="d-block"><i class="fas fa-file-upload fs-2 mb-2"></i><br>No file uploaded</span>';
                        evaluationForm.style.display = 'block';
                        currentHrFormFilePath = null;
                    }
                    adjustAnalysisTextareaHeight();

                    // HR Analysis
                    hrAnalysisTextarea.value = evalData.analysis_data || '';
                    const formUploaded = !!evalData.form_file_path;
                    const receivedResponses = result.responses.length;
                    let expectedResponses = 0;

                    try {
                        const countRes = await fetch(`get_peers_count.php?employee_id=${currentEmployeeId}`);
                        const countData = await countRes.json();
                        if (countData.success) {
                            expectedResponses = countData.count;
                        }
                    } catch (err) {
                        console.error('Error fetching peer count:', err);
                    }

                    if (formUploaded && receivedResponses == expectedResponses && expectedResponses > 0) {
                        hrAnalysisTextarea.disabled = evalData.status === 'completed';
                        hrAnalysisTextarea.style.height = '430px';
                        sendAnalysisBtn.style.display = 'none';
                    } else {
                        hrAnalysisTextarea.disabled = true;
                        sendAnalysisBtn.disabled = true;
                    }
                } else {
                    renderResponses([]);
                    formContainer.style.display = 'block';
                    evaluationForm.style.display = 'block';
                    hrAnalysisTextarea.value = '';
                    hrAnalysisTextarea.disabled = false;
                    sendAnalysisBtn.innerHTML = '<i class="fas fa-comment me-2"></i> Send Analysis';
                    sendAnalysisBtn.disabled = false;
                }
            } else {
                console.error('Failed to load evaluation details:', result.message);
                renderResponses([]);
                showHrFormFile(null);
                hrAnalysisTextarea.value = '';
            }
        } catch (error) {
            console.error('Error fetching evaluation details:', error);
            renderResponses([]);
            showHrFormFile(null);
            hrAnalysisTextarea.value = '';
        }
    }

    // Function to populate the year filter combo box
    async function populateYearFilter(employeeId) {
        try {
            // The get_existing_years.php script fetches all distinct years.
            const response = await fetch(`get_existing_years.php?employee_id=${employeeId}`);
            const data = await response.json();
            const evaluationPeriodYearFilter = document.getElementById('evaluationPeriodYearFilter');
            if (data.success) {
                // Clear existing options
                evaluationPeriodYearFilter.innerHTML = '';
                // Add a placeholder option
                const placeholder = document.createElement('option');
                placeholder.textContent = 'Select Year';
                placeholder.value = '';
                evaluationPeriodYearFilter.appendChild(placeholder);

                data.years.forEach(yearObj => {
                    const year = yearObj.quarter_year; // THIS IS THE FIX
                    const option = document.createElement('option');
                    option.value = year;
                    option.textContent = year;
                    evaluationPeriodYearFilter.appendChild(option);
                });
            }
        } catch (error) {
            console.error('Error populating year filter:', error);
        }
    }

    // Function to populate the quarter filter combo box
    async function populateQuarterFilter(employeeId, year) {
        try {
            const response = await fetch(`get_existing_quarters.php?employee_id=${employeeId}&year=${year}`);
            const data = await response.json();
            const evaluationPeriodQuarterFilter = document.getElementById('evaluationPeriodQuarterFilter');
            if (data.success) {
                // Clear existing options before populating
                evaluationPeriodQuarterFilter.innerHTML = '';
                // Add a placeholder option
                const placeholder = document.createElement('option');
                placeholder.textContent = 'Select Quarter';
                placeholder.value = '';
                evaluationPeriodQuarterFilter.appendChild(placeholder);

                data.quarters.forEach(quarterObj => {
                    const quarterName = quarterObj.quarter_name;
                    const quarterAbbr = quarterName.split('-')[0]; // THIS IS THE FIX
                    const option = document.createElement('option');
                    option.value = quarterName;
                    option.textContent = quarterAbbr;
                    evaluationPeriodQuarterFilter.appendChild(option);
                });
            }
        } catch (error) {
            console.error('Error populating quarter filter:', error);
        }
    }

    // Event listener for year filter change
    evaluationPeriodYearFilter.addEventListener('change', function() {
        const selectedYear = this.value;
        evaluationPeriodQuarterFilter.disabled = !selectedYear;
        if (selectedYear) {
            populateQuarterFilter(currentEmployeeId, selectedYear);
        } else {
            evaluationPeriodQuarterFilter.innerHTML = '<option value="">Quarter</option>';
        }
    });

    evaluationPeriodQuarterFilter.addEventListener('change', function() {
        const selectedQuarterFull = this.value; // e.g., "Q1-2024"
        if (!selectedQuarterFull) return;

        // Split into quarter abbreviation and year
        const [quarterAbbr, year] = selectedQuarterFull.split('-');

        // Update global variables
        currentQuarterName = selectedQuarterFull; // e.g., "Q1-2024"
        currentQuarterYear = year;

        // Fetch evaluation ID for this combination
        fetch(`get_current_evaluation.php?employee_id=${currentEmployeeId}&quarter_name=${currentQuarterName}`)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.evaluation_id) {
                    currentEvaluationId = data.evaluation_id;

                    // Update header properly
                    evaluationPageHeaderTitle.textContent = `${currentQuarterYear} ${quarterAbbr} Evaluation for ${currentEmployeeName}`;

                    // Load the evaluation details
                    loadEvaluationDetails(currentEvaluationId, currentQuarterName, currentQuarterYear);
                } else {
                    console.error('Evaluation not found for selected period.');

                    // Reset UI if no evaluation exists
                    evaluationPageHeaderTitle.textContent = `${currentQuarterYear} ${quarterAbbr} Evaluation for ${currentEmployeeName} (No Evaluation Found)`;
                    renderResponses([]);
                    showHrFormFile(null); // Or reset file UI
                    hrAnalysisTextarea.value = '';
                    hrAnalysisTextarea.disabled = false;
                    sendAnalysisBtn.innerHTML = '<i class="fas fa-comment me-2"></i> Send Analysis';
                    sendAnalysisBtn.disabled = false;
                }
            })
            .catch(error => console.error('Error fetching evaluation ID:', error));
    });

    // Function to show/hide the clear button based on file input state
    function toggleClearButton() {
        if (uploadEvaluationInput.files.length > 0) {
            clearUploadedFileBtn.classList.remove('d-none');
        } else {
            clearUploadedFileBtn.classList.add('d-none');
        }

        if (employeeResponseInput.files.length > 0) {
            clearUploadedFileBtn2.classList.remove('d-none');
        } else {
            clearUploadedFileBtn2.classList.add('d-none');
        }
    }

    // Event listener for when a file is chosen
    uploadEvaluationInput.addEventListener('change', function() {
        toggleClearButton();
    });

    employeeResponseInput.addEventListener('change', function() {
        toggleClearButton();
    });

    // Event listener for the clear button
    clearUploadedFileBtn.addEventListener('click', function() {
        uploadEvaluationInput.value = '';
        clearUploadedFileBtn.classList.add('d-none');
        showHrFormFile('');
    });

    clearUploadedFileBtn2.addEventListener('click', function() {
        employeeResponseInput.value = '';
        clearUploadedFileBtn2.classList.add('d-none');
        showHrFormFile('');
    });
    
    // HR Form Upload
    if (evaluationForm) {
        evaluationForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            const selectedYear = evaluationPeriodYearFilter ? evaluationPeriodYearFilter.value : '';
            const selectedQuarter = evaluationPeriodQuarterFilter ? evaluationPeriodQuarterFilter.value : '';

            if (!selectedYear || !selectedQuarter) {
                showModal(customAlertModal, 'Missing Information', 'Please select both Year and Quarter before uploading a form.');
                return; // Stop form submission
            }

            const file = uploadEvaluationInput.files[0];
            if (!file) {
                showModal(customAlertModal, 'No File Selected', 'Please select a file to upload.');
                return;
            }

            showModal(confirmUploadModal);
            
            // Populate hidden inputs with data from URL params
            const formData = new FormData();
            formData.append('evaluation_file', file);
            formData.append('employee_id', currentEmployeeId);
            formData.append('quarter_name', currentQuarterName);
            formData.append('evaluation_id', currentEvaluationId);

            if (confirmUploadYes) {
                confirmUploadYes.addEventListener('click', async function() {
                    hideModal(confirmUploadModal);
                    try {
                        const response = await fetch('upload_evaluation_form.php', {
                            method: 'POST',
                            body: formData
                        });
                        const result = await response.json();

                        if (result.success) {
                            renderUploadedFileCard(file.name, result.filePath);
                            // Hide the form since the file has been uploaded
                            evaluationForm.style.display = 'none';
                            currentHrFormFilePath = result.filePath; 
                            uploadEvaluationInput.value = ''; 
                            clearUploadedFileBtn.classList.add('d-none');
                            updateHrFormFileDisplay();
                            loadEvaluationDetails(currentEvaluationId, currentQuarterName, currentQuarterYear);
                        } else {
                            showModal(customAlertModal, 'Upload Error', 'Error uploading file: ' + result.message);
                        }
                    } catch (error) {
                        console.error('Error submitting form:', error);
                        showModal(customAlertModal, 'Upload Error', 'An unexpected error occurred during file upload. Please try again.');
                    }
                });
            }
        });
    }

    const employeeResponse = document.getElementById('employeeResponseCard');
    if (employeeResponse) {
        employeeResponse.addEventListener('submit', async function(event) {
            event.preventDefault();

            const file = employeeResponseInput.files[0];
            if (!file) {
                showModal(customAlertModal, 'No File Selected', 'Please select a file to upload.');
                return;
            }

            showModal(confirmUploadModal);
            
            // Populate hidden inputs with data from URL params
            const formData = new FormData();
            formData.append('response_file', file);
            formData.append('email', email);
            formData.append('evaluation_id', currentEvaluationId);

            if (confirmUploadYes) {
                confirmUploadYes.addEventListener('click', async function() {
                    hideModal(confirmUploadModal);
                    try {
                        const response = await fetch('submit_evaluation_response.php', {
                            method: 'POST',
                            body: formData
                        });
                        const result = await response.json();

                        if (result.success) {
                            window.location.href = 'evaluation_list.html';
                        } else {
                            showModal(customAlertModal, 'Upload Error', 'Error uploading file: ' + result.message);
                        }
                    } catch (error) {
                        console.error('Error submitting form:', error);
                        showModal(customAlertModal, 'Upload Error', 'An unexpected error occurred during file upload. Please try again.');
                    }
                });
            }
        });
    }

    // HR Analysis Post
    const sendAnalysisForm = document.getElementById('postAnalysisForm');
    if (sendAnalysisForm) {
        sendAnalysisForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            const analysisData = hrAnalysisTextarea.value;
            if (!analysisData.trim()) {
                return;
            }

            const formData = new FormData();
            formData.append('employee_id', currentEmployeeId);
            formData.append('quarter_name', currentQuarterName);
            formData.append('evaluation_id', currentEvaluationId);
            formData.append('analysis_data', analysisData);

            try {
                const response = await fetch('post_evaluation_analysis.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    hrAnalysisTextarea.disabled = true;
                    sendAnalysisBtn.textContent = 'Analysis Completed';
                    sendAnalysisBtn.disabled = true;
                } else {
                    showModal(customAlertModal, 'Error', 'Failed to post analysis. Please try again.');
                }
            } catch (error) {
                console.error('Error posting analysis:', error);
                showModal(customAlertModal, 'Error', 'An unexpected error occurred while posting analysis.');
            }
        });
    }

    if (confirmUploadNo) {
        confirmUploadNo.addEventListener('click', function() {
            hideModal(confirmUploadModal);
        });
    }

    const filterEvalContainer = document.getElementById('filterEvalContainer');
    const hrSideEvalContainer = document.getElementById('hrSideEvalContainer');
    const empSideEvalContainer = document.getElementById('empSideEvalContainer');
    const chooseFile = document.getElementById('chooseFileInput');
    const postHrFormBtn = document.getElementById('postHrFormBtn');
    const email = localStorage.getItem('userEmail');
    if (email) {
        fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.owner.length > 0) {
                    const emp = data.owner[0];
                    const position = emp.position.trim();

                    if (position && position.toLowerCase() === 'owner') {
                        chooseFile.style.display = 'none';
                        postHrFormBtn.style.display = 'none';
                        sendAnalysisBtn.style.display = 'none';
                    }
                    if (position && position.toLowerCase() === 'employee') {
                        filterEvalContainer.classList.add('d-none');
                        hrSideEvalContainer.classList.add('d-none');
                        empSideEvalContainer.classList.remove('d-none');
                    }
                }
            })
            .catch(err => console.error(err));
    }

    async function initializePage() {
        currentEmployeeId = params.get('employeeId');
        currentEvaluationId = params.get('evaluationId');
        currentEmployeeName = params.get('employeeName');
        currentQuarterName = params.get('quarterName');

        if (currentEvaluationId && currentEmployeeName && currentQuarterName) {
            // Get the year from the quarter name (e.g., 'Q1-2025' -> '2025')
            const quarterParts = currentQuarterName.split('-');
            currentQuarterYear = quarterParts[1];

            evaluationPageHeaderTitle.textContent = `${currentQuarterYear} ${quarterParts[0]} Evaluation for ${currentEmployeeName}`;
            await populateYearFilter(currentEmployeeId);
            if (currentQuarterYear) {
                evaluationPeriodYearFilter.value = currentQuarterYear;
                await populateQuarterFilter(currentEmployeeId, currentQuarterYear);
                evaluationPeriodQuarterFilter.value = currentQuarterName; // Set value to the full quarter name, e.g., 'Q1-2025'
            }
            loadEvaluationDetails(currentEvaluationId, currentQuarterName, currentQuarterYear);
        } else {
            evaluationPageHeaderTitle.textContent = 'Error: Evaluation Not Found';
        }
    }

    initializePage();
});