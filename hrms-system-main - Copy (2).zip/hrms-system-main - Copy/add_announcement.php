<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $details = $_POST['details'] ?? '';

    if (empty($title) || empty($details)) {
        $response['message'] = 'Title and details cannot be empty.';
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO announcements (title, details) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param("ss", $title, $details);
            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Announcement posted successfully.';
                // Fetch the newly added announcement to return its data
                $newId = $stmt->insert_id;
                $fetchStmt = $conn->prepare("SELECT id, title, details, post_date FROM announcements WHERE id = ?");
                if ($fetchStmt) {
                    $fetchStmt->bind_param("i", $newId);
                    $fetchStmt->execute();
                    $result = $fetchStmt->get_result();
                    if ($result->num_rows > 0) {
                        $response['announcement'] = $result->fetch_assoc();
                    }
                    $fetchStmt->close();
                }
            } else {
                $response['message'] = 'Failed to post announcement: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $response['message'] = 'Database prepare error: ' . $conn->error;
        }
    }
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>
