<?php
header('Content-Type: application/json');
require 'send_email.php'; // includes sendToEmail()

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$to = $input['to'] ?? '';
$subject = $input['subject'] ?? '';
$body = $input['body'] ?? '';

if (!$to || !$subject || !$body) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

// Send email using PHPMailer function
if (sendToEmail($to, $subject, $body)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to send email']);
}
?>
