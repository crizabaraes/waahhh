document.addEventListener('DOMContentLoaded', function() {
    const employeeRecordsList = document.getElementById('employeeRecordsList');

    // Helper to get month name
    function getMonthName(monthIndex) {
        return [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ][monthIndex];
    }

    window.loadEmployees = function() {
        fetch('get_employee_details.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const employees = data.employees;
                    const employeeRecordsList = document.getElementById('employeeRecordsList');
                    
                    if (employeeRecordsList) employeeRecordsList.innerHTML = '';

                    // Get current month (0-based)
                    const now = new Date();
                    const currentMonth = now.getMonth();
                    const todayDate = now.getDate();

                    // Filter employees with birthday in current month and not yet passed
                    const birthdayCelebrants = employees
                        .filter(employee => {
                            if (!employee.birthday) return false;
                            const bday = new Date(employee.birthday);
                            // Only include if birthday is this month and today or later
                            return (
                                bday.getMonth() === currentMonth &&
                                bday.getDate() >= todayDate
                            );
                        })
                        .sort((a, b) => {
                            // Sort by day of month
                            const dayA = new Date(a.birthday).getDate();
                            const dayB = new Date(b.birthday).getDate();
                            return dayA - dayB;
                        });

                    // Set the section title
                    const parentSection = document.getElementById('employee-records');
                    if (parentSection) {
                        const title = parentSection.querySelector('h3');
                        if (title) {
                            title.textContent = `Birthday Celebrants in ${getMonthName(currentMonth)}`;
                        }
                    }

                    if (birthdayCelebrants.length === 0) {
                        if (employeeRecordsList) employeeRecordsList.innerHTML = `<div class="text-center text-text-muted-grey py-3">No birthday celebrants this month.</div>`;
                        return;
                    }

                    birthdayCelebrants.forEach(employee => {
                        // Determine what to show: picture or default icon
                        let iconHtml = '';
                        if (employee.picture_file_path) {
                            // Profile picture exists
                            iconHtml = `<img src="${employee.picture_file_path}" alt="Profile" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">`;
                        } else {
                            // No picture, show default icon
                            const names = employee.full_name.trim().split(" ");
                            let initials = names.length > 1
                                ? names[0][0] + names[names.length - 1][0]
                                : names[0][0];
                            initials = initials.toUpperCase();

                            iconHtml = `<img src="https://placehold.co/40x40/5C7D8A/ffffff?text=${initials}" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">`;
                        }

                        // Format birthday as "Month Day" (e.g., "April 23") or "Happy Birthday!" if today
                        let birthdayLabel = "";
                        if (employee.birthday) {
                            const bday = new Date(employee.birthday);
                            if (bday.getDate() === todayDate) {
                                birthdayLabel = `<span style="color: var(--accent-peach); font-weight: bold;">Happy Birthday!</span>`;
                            } else {
                                birthdayLabel = `${getMonthName(bday.getMonth())} ${bday.getDate()}`;
                            }
                        }

                        const employeeCard = `
                            <div class="list-group-item employee-card d-flex align-items-center justify-content-start p-3">
                                <div class="d-flex align-items-start">
                                    <div class="icon-wrapper2 me-3" style="background-color: var(--primary-soft-blue); display:flex; align-items:center; justify-content:center; width: 40px; height: 40px; border-radius: 50%;">
                                        ${iconHtml}
                                    </div>
                                    <div class="content-area">
                                        <h5 class="fw-semibold text-text-dark-grey d-flex align-items-center mb-1">
                                            ${employee.full_name}
                                        </h5>
                                        <p class="small text-text-muted-grey mb-0">${birthdayLabel}</p>
                                    </div>
                                </div>
                            </div>
                        `;
                        employeeRecordsList.innerHTML += employeeCard;
                    });
                } else {
                    if (employeeRecordsList) employeeRecordsList.innerHTML = `<div class="text-center text-danger py-3">Error loading employees.</div>`;
                    console.error('API Error:', data.message);
                }
            })
            .catch(error => {
                if (employeeRecordsList) employeeRecordsList.innerHTML = `<div class="text-center text-danger py-3">Network error.</div>`;
                console.error('Fetch Error:', error);
            });
    }
    

    const email = localStorage.getItem('userEmail');
    // Function to update the total employee count from the database
    window.updateEmployeeCount = function() {
        fetch('get_employee_count.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const employeeCountElement = document.getElementById('totalEmployeesCount');
                    if (employeeCountElement) {
                        employeeCountElement.textContent = data.total_employees;
                    }
                } else {
                    console.error('Failed to fetch employee count:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching employee count:', error);
            });
    }

    window.updatePendingRequestsCount = function() {
        if (!email) return;

        const formData = new FormData();
        formData.append('email', email);

        fetch('requests.php?action=get_requests_count', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                const pendingCountEl = document.getElementById('pendingRequestsCount');
                if (pendingCountEl) {
                    pendingCountEl.textContent = data.pending_requests;
                }
            } else {
                console.error('Failed to fetch pending requests:', data.message);
            }
        })
        .catch(err => console.error('Error fetching pending requests:', err));
    }

    const pendingEvalsRole = document.getElementById('pendingEvalsRole');
    const totalEmpsRole = document.getElementById('totalEmpsRole');
    const addAnnouncementBtn = document.getElementById('addAnnouncementBtn');
    const addEventBtn = document.getElementById('addEventBtn');
    if (email) {
        fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.owner.length > 0) {
                    const emp = data.owner[0];
                    const position = emp.position.trim();

                    if (position && position.toLowerCase() === 'owner') {
                        addAnnouncementBtn.style.visibility = 'hidden';
                        addEventBtn.style.visibility = 'hidden';
                    }
                    else if (position && position.toLowerCase() === 'employee') {
                        addAnnouncementBtn.style.visibility = 'hidden';
                        addEventBtn.style.visibility = 'hidden';
                        totalEmpsRole.classList.add('d-none');
                        pendingEvalsRole.classList.remove('d-none');
                    }
                }
            })
            .catch(err => console.error(err));
    }

    window.updatePendingEvalsCount = function() {
        if (!email) return;

        fetch(`get_evaluations_count.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const pendingEvalsEl = document.getElementById('pendingEvalsCount');
                    if (pendingEvalsEl) {
                        pendingEvalsEl.textContent = data.pending_count;
                    }
                } else {
                    console.error('Failed to fetch pending evaluations:', data.message);
                }
            })
            .catch(err => console.error('Error fetching pending evaluations:', err));
    };

    // Call updateEmployeeCount initially on load
    updateEmployeeCount();
    updatePendingRequestsCount();
    updatePendingEvalsCount();
    loadEmployees();
});