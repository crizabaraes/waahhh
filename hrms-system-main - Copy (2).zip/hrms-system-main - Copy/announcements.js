document.addEventListener('DOMContentLoaded', function() {
    // -------- Announcement Modals and Functionality --------
    const addAnnouncementBtn = document.getElementById('addAnnouncementBtn');
    const addAnnouncementModal = document.getElementById('addAnnouncementModal');
    const addAnnouncementForm = document.getElementById('addAnnouncementForm');
    const cancelAnnouncementBtn = document.getElementById('cancelAnnouncementBtn');
    const announcementsList = document.getElementById('announcementsList');

    const viewAnnouncementModal = document.getElementById('viewAnnouncementModal');
    const viewAnnouncementTitle = document.getElementById('viewAnnouncementTitle');
    const viewAnnouncementDate = document.getElementById('viewAnnouncementDate');
    const viewAnnouncementDetails = document.getElementById('viewAnnouncementDetails');
    const closeAnnouncementBtn = document.getElementById('closeAnnouncementBtn');

    let currentEditAnnouncementId = null; // To track if we're in edit mode
    const announcementModalTitle = document.getElementById('announcementModalTitle'); // The modal's H5 title
    const announcementIdInput = document.getElementById('announcementId'); // Hidden input for ID
    const postUpdateAnnouncementBtn = document.getElementById('postUpdateAnnouncementBtn'); // The submit button

    // Show Add Announcement Modal (for new announcement)
    if (addAnnouncementBtn) {
        addAnnouncementBtn.addEventListener('click', () => {
            currentEditAnnouncementId = null; // Ensure we're in 'add' mode
            announcementIdInput.value = ''; // Clear hidden ID
            addAnnouncementForm.reset(); // Clear form fields
            announcementModalTitle.textContent = 'Add New Announcement'; // Set modal title
            postUpdateAnnouncementBtn.textContent = 'Post'; // Set button text
            addAnnouncementModal.classList.remove('d-none');
        });
    }

    // Hide Add Announcement Modal
    if (cancelAnnouncementBtn) {
        cancelAnnouncementBtn.addEventListener('click', () => {
            addAnnouncementModal.classList.add('d-none');
            currentEditAnnouncementId = null; // Reset edit state
            announcementIdInput.value = ''; // Clear hidden ID
            announcementModalTitle.textContent = 'Add New Announcement'; // Reset modal title
            postUpdateAnnouncementBtn.textContent = 'Post'; // Reset button text
        });
    }
    // Hide View Announcement Modal
    if (closeAnnouncementBtn) {
        closeAnnouncementBtn.addEventListener('click', () => {
            viewAnnouncementModal.classList.add('d-none');
        });
    }
    if (viewAnnouncementModal) {
        viewAnnouncementModal.addEventListener('click', (event) => {
            if (event.target === viewAnnouncementModal) {
                viewAnnouncementModal.classList.add('d-none');
            }
        });
    }

    // Function to format date for display (existing)
    function formatDate(dateString) {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('en-US', options);
    }

    // NEW: Function to dynamically update the edit button state
    function updateEditButtonState(announcement, cardElement) {
        const postDate = new Date(announcement.post_date);
        const now = new Date();
        const editableUntil = new Date(postDate);
        editableUntil.setDate(postDate.getDate() + 7); // 7 days from postDate

        const isEditable = now < editableUntil; // Check if current time is BEFORE editableUntil
        const editBtn = cardElement.querySelector('.edit-announcement-icon');
        if (editBtn) {
            if (isEditable) {
                editBtn.disabled = false;
                editBtn.classList.remove('disabled-edit-icon');
                editBtn.title = 'Edit Announcement';
            } else {
                editBtn.disabled = true;
                editBtn.classList.add('disabled-edit-icon');
                editBtn.title = 'Cannot edit (older than 1 week)'; // Changed text// Or 'older than 1 hour' for testing
            }
        }
    }

    // Helper function to fetch and update the 'New Announcements' dashboard count
    async function updateNewAnnouncementsCount() {
        try {
            const response = await fetch('new_announcements_count.php');
            const result = await response.json();
            if (result.success) {
                document.getElementById('newAnnouncementsCount').textContent = result.count;
            } else {
                console.error('Failed to fetch new announcements count:', result.message);
                document.getElementById('newAnnouncementsCount').textContent = 'Error'; // Indicate error
            }
        } catch (error) {
            console.error('Network error fetching new announcements count:', error);
            document.getElementById('newAnnouncementsCount').textContent = 'N/A'; // Indicate network error
        }
    }

    // NEW: Function to manage the periodic updates of announcement edit buttons
    function startAnnouncementTimerUpdates() {
        // Clear any existing interval to prevent multiple timers running
        if (window.announcementUpdateInterval) {
            clearInterval(window.announcementUpdateInterval);
        }

        // Set up a new interval
        window.announcementUpdateInterval = setInterval(() => {
            // Update the dashboard metric by calling the dedicated function
        updateNewAnnouncementsCount();

        // Also update edit button states for currently displayed cards (this was already there)
        const announcementCards = announcementsList.querySelectorAll('.announcement-item'); // Re-query for current cards
        announcementCards.forEach(cardElement => {
            const announcementData = cardElement.announcementData;
            if (announcementData) {
                updateEditButtonState(announcementData, cardElement);
            }
        });
        }, 6 * 1000); // Run every 10 seconds (adjust as needed, 60 seconds is also fine)
    }

    // Function to create an announcement card
    function createAnnouncementCard(announcement) {
        const cardLink = document.createElement('a'); // This 'a' tag will no longer be the primary click for view details
        cardLink.href = "#";
        cardLink.className = 'list-group-item list-group-item-action announcement-item';
        cardLink.setAttribute('data-id', announcement.id);
        cardLink.announcementData = announcement; // Store the full announcement object

        // Truncate details for preview (adjust length as desired)
        const previewDetails = announcement.details.length > 100
            ? announcement.details.substring(0, 100) + '...'
            : announcement.details;

        const postDate = new Date(announcement.post_date);
        const now = new Date();
        const editableUntil = new Date(postDate);
        editableUntil.setDate(postDate.getDate() + 7);
        const isEditable = now < editableUntil;

        cardLink.innerHTML = `
            <div class="d-flex align-items-start">
                <div class="icon-wrapper me-3">
                    <i class="fas fa-bullhorn text-primary-soft-blue fs-5"></i>
                </div>
                <div class="flex-grow-1 content-area">
                    <div class="title-date">
                        <h5 class="mb-1 fs-6 text-text-dark-grey fw-semibold anRes">${announcement.title}</h5>
                        <small class="text-text-muted-grey">${formatDate(announcement.post_date)}</small>
                    </div>
                    <p class="small text-text-dark-grey mb-0">${previewDetails}</p>
                </div>
            </div>
            <div class="text-end d-flex align-items-center justify-content-end w-100">
                <button class="btn btn-sm btn-outline-custom edit-announcement-icon me-2 ${isEditable ? '' : 'disabled-edit-icon'}"
                        data-id="${announcement.id}"
                        title="${isEditable ? 'Edit Announcement' : 'Cannot edit (older than week)'}"
                        ${isEditable ? '' : 'disabled'}>
                    <i class="fas fa-edit"></i>
                </button>
                <small class="text-primary-soft-blue text-decoration-none fw-medium view-details-link" data-id="${announcement.id}">View Details <i class="fas fa-arrow-right ms-1"></i></small>
            </div>
        `;

        // Add event listener for View Details (using the specific link)
        cardLink.querySelector('.view-details-link').addEventListener('click', (event) => {
            event.preventDefault();
            viewAnnouncementTitle.textContent = announcement.title;
            viewAnnouncementDate.textContent = formatDate(announcement.post_date);
            viewAnnouncementDetails.textContent = announcement.details;
            viewAnnouncementModal.classList.remove('d-none');
        });

        // Add event listener for Edit button (icon) if it exists
        const editBtn = cardLink.querySelector('.edit-announcement-icon');
        if (editBtn) {
            editBtn.addEventListener('click', (event) => {
                event.preventDefault();
                event.stopPropagation();

                if (editBtn.disabled) {
                    return; // Do nothing if the button is disabled
                }

                currentEditAnnouncementId = announcement.id;
                announcementIdInput.value = announcement.id;
                document.getElementById('announcementTitle').value = announcement.title;
                document.getElementById('announcementDetails').value = announcement.details;

                announcementModalTitle.textContent = 'Edit Announcement';
                postUpdateAnnouncementBtn.textContent = 'Update';
                addAnnouncementModal.classList.remove('d-none');
            });
        }
        updateEditButtonState(announcement, cardLink);
        return cardLink;
    }

    // Function to load announcements from the database
    async function loadAnnouncements() {
        try {
            const response = await fetch('fetch_announcements.php');
            const result = await response.json();

            if (result.success && result.announcements.length > 0) {
                announcementsList.innerHTML = ''; // Clear existing placeholders
                result.announcements.forEach(announcement => {
                    const card = createAnnouncementCard(announcement);
                    announcementsList.appendChild(card);
                });
                updateNewAnnouncementsCount();
                startAnnouncementTimerUpdates(); // <--- ADD IT HERE
            } else if (result.success && result.announcements.length === 0) {
                announcementsList.innerHTML = '<p class="text-text-muted-grey text-center py-4">No announcements yet. Click "Add Announcement" to post one!</p>';
                if (window.announcementUpdateInterval) { // Clear interval if no announcements
                    clearInterval(window.announcementUpdateInterval);
                }
            } else {
                console.error('Failed to load announcements:', result.message);
                announcementsList.innerHTML = '<p class="text-danger text-center py-4">Error loading announcements.</p>';
                if (window.announcementUpdateInterval) { // Clear interval on error
                    clearInterval(window.announcementUpdateInterval);
                }
            }
        } catch (error) {
            console.error('Error fetching announcements:', error);
            announcementsList.innerHTML = '<p class="text-danger text-center py-4">Network error loading announcements.</p>';
            if (window.announcementUpdateInterval) { // Clear interval on network error
                clearInterval(window.announcementUpdateInterval);
            }
        }
    }

    // Handle Add/Update Announcement Form Submission
    if (addAnnouncementForm) {
        addAnnouncementForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const formData = new FormData(addAnnouncementForm);

            const url = currentEditAnnouncementId ? 'update_announcement.php' : 'add_announcement.php';

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    addAnnouncementModal.classList.add('d-none'); // Hide modal
                    // Reload all announcements to reflect changes
                    loadAnnouncements();
                    currentEditAnnouncementId = null; // Reset edit state
                    announcementIdInput.value = ''; // Clear hidden ID
                    announcementModalTitle.textContent = 'Add New Announcement'; // Reset modal title
                    postUpdateAnnouncementBtn.textContent = 'Post'; // Reset button text
                } else {
                    showAlertModal('Error', 'An error occurred. Please try again.');
                }
            } catch (error) {
                console.error('Error submitting announcement:', error);
                showAlertModal('Error', 'An error occurred. Please try again.');
            }
        });
    }

    // Initial load of announcements when the page loads (existing)
    loadAnnouncements();
});