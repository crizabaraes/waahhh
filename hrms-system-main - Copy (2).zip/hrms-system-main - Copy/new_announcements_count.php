<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'count' => 0, 'message' => ''];

// CURDATE() gets only the current date (no time). DATE_SUB(CURDATE(), INTERVAL 14 DAY) gets 14 days ago at midnight.
$sql = "SELECT COUNT(id) AS new_count FROM announcements WHERE DATE(post_date) > DATE_SUB(CURDATE(), INTERVAL 14 DAY)";
$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response['count'] = (int)$row['new_count']; // Cast to integer
        $response['success'] = true;
    } else {
        $response['message'] = 'No new announcements found.';
        $response['success'] = true; // Still success, just count is 0
    }
} else {
    $response['message'] = 'Database query failed: ' . $conn->error;
}

$conn->close();
echo json_encode($response);
?>