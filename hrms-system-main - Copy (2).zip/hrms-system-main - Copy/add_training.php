<?php
require 'authentication/db_connect.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['trainingFile'])) {
    $file = $_FILES['trainingFile'];
    $fileName = basename($file['name']);
    $uploadDir = 'uploads/training_materials/';
    $uploadPath = $uploadDir . $fileName;

    // Create the uploads directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        $stmt = $conn->prepare("INSERT INTO training_materials (filename, filepath) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param("ss", $fileName, $uploadPath);
            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'File uploaded and saved successfully!';
            } else {
                $response['message'] = 'Database error: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $response['message'] = 'Failed to prepare statement: ' . $conn->error;
        }
    } else {
        $response['message'] = 'Failed to upload file.';
    }
} else {
    $response['message'] = 'Invalid request.';
}

$conn->close();
header('Content-Type: application/json');
echo json_encode($response);
?>