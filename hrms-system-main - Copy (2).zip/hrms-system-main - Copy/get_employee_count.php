<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = [
    'success' => false,
    'total_employees' => 0,
    'message' => ''
];

try {
    $stmt = $conn->prepare("SELECT COUNT(id) AS total_employees FROM employees WHERE LOWER(account_status) != 'deactivated'");
    if (!$stmt) throw new Exception($conn->error);

    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $response['total_employees'] = (int)$row['total_employees'];

    $stmt->close();
    $response['success'] = true;

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("get_total_employee_count.php error: " . $e->getMessage());
} finally {
    if ($conn) $conn->close();
}

echo json_encode($response);
?>
