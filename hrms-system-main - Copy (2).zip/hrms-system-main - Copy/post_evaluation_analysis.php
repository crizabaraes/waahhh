<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $employee_id = $_POST['employee_id'] ?? null;
    $quarter_name = $_POST['quarter_name'] ?? null;
    $evaluation_id = $_POST['evaluation_id'] ?? null;
    $analysis_data = trim($_POST['analysis_data'] ?? '');

    if (!$employee_id || !$quarter_name || !$evaluation_id || $analysis_data === '') {
        throw new Exception('Missing required parameters (Employee ID, Quarter, Evaluation ID, or Analysis Data).');
    }

    // Start a transaction
    $conn->begin_transaction();

    // Update the analysis data and set status to 'completed'
    $stmt = $conn->prepare("UPDATE evaluations SET analysis_data = ?, status = 'completed' WHERE evaluation_id = ? AND employee_id = ? AND quarter_name = ?");
    if (!$stmt) {
        throw new Exception('Prepare statement failed (analysis): ' . $conn->error);
    }
    $stmt->bind_param("siss", $analysis_data, $evaluation_id, $employee_id, $quarter_name);

    if (!$stmt->execute()) {
        throw new Exception('Execute statement failed (analysis): ' . $stmt->error);
    }
    $stmt->close();

    $title = "Evaluation Analysis for $quarter_name";
    $stmtN = $conn->prepare("
        INSERT INTO notifications (employee_id, title, content, date_sent)
        VALUES (?, ?, ?, NOW())
    ");
    if (!$stmtN) {
        throw new Exception('Prepare statement failed (notification): ' . $conn->error);
    }
    $stmtN->bind_param("sss", $employee_id, $title, $analysis_data);

    if (!$stmtN->execute()) {
        throw new Exception('Execute statement failed (notification): ' . $stmtN->error);
    }
    $stmtN->close();


    $conn->commit();
    $response['success'] = true;
    $response['message'] = 'Analysis submitted successfully.';

} catch (Exception $e) {
    $conn->rollback();
    $response['message'] = 'Error submitting analysis: ' . $e->getMessage();
    error_log("post_evaluation_analysis.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>
