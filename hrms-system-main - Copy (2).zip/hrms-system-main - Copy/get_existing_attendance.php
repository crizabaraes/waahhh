<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');
$response = ['success' => false, 'months' => [], 'message' => ''];

try {
    $employee_id = $_GET['employee_id'] ?? null;

    if (!$employee_id) {
        throw new Exception('Employee ID is required.');
    }

    // Fetch distinct months & years from attendance
    $stmt = $conn->prepare("
        SELECT DISTINCT YEAR(attendance_date) AS year, MONTH(attendance_date) AS month
        FROM attendance
        WHERE employee_id = ?
        ORDER BY year DESC, month DESC
    ");
    if (!$stmt) {
        throw new Exception('Prepare statement failed: ' . $conn->error);
    }

    $stmt->bind_param("s", $employee_id);

    if (!$stmt->execute()) {
        throw new Exception('Execute statement failed: ' . $stmt->error);
    }

    $result = $stmt->get_result();
    $months = [];
    while ($row = $result->fetch_assoc()) {
        $months[] = [
            'year' => $row['year'],
            'month' => $row['month'],
            'label' => date("F Y", strtotime("{$row['year']}-{$row['month']}-01"))
        ];
    }
    $stmt->close();

    $response['success'] = true;
    $response['months'] = $months;

} catch (Exception $e) {
    $response['message'] = 'Error fetching months: ' . $e->getMessage();
    error_log("get_existing_attendance.php error: " . $e->getMessage());
} finally {
    if ($conn) $conn->close();
}

echo json_encode($response);
