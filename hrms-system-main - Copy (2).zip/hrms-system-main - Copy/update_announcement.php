<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $title = $_POST['title'] ?? '';
    $details = $_POST['details'] ?? '';

    if (empty($id) || empty($title) || empty($details)) {
        $response['message'] = 'Missing required fields: ID, Title, or Details.';
    } else {
        // First, verify the announcement exists and is within the editable timeframe (1 week)
        $checkStmt = $conn->prepare("SELECT post_date FROM announcements WHERE id = ?");
        if ($checkStmt) {
            $checkStmt->bind_param("i", $id);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            if ($result->num_rows > 0) {
                $announcement = $result->fetch_assoc();
                $postDate = new DateTime($announcement['post_date']);
                $oneWeekAgo = new DateTime();
                $oneWeekAgo->modify('-7 days');

                if ($postDate >= $oneWeekAgo) {
                    // Announcement is editable, proceed with update
                    $updateStmt = $conn->prepare("UPDATE announcements SET title = ?, details = ? WHERE id = ?");
                    if ($updateStmt) {
                        $updateStmt->bind_param("ssi", $title, $details, $id);
                        if ($updateStmt->execute()) {
                            $response['success'] = true;
                            $response['message'] = 'Announcement updated successfully.';
                            // Fetch the updated announcement to return its data
                            $fetchStmt = $conn->prepare("SELECT id, title, details, post_date FROM announcements WHERE id = ?");
                            if ($fetchStmt) {
                                $fetchStmt->bind_param("i", $id);
                                $fetchStmt->execute();
                                $result = $fetchStmt->get_result();
                                if ($result->num_rows > 0) {
                                    $response['announcement'] = $result->fetch_assoc();
                                }
                                $fetchStmt->close();
                            }
                        } else {
                            $response['message'] = 'Failed to update announcement: ' . $updateStmt->error;
                        }
                        $updateStmt->close();
                    } else {
                        $response['message'] = 'Database update prepare error: ' . $conn->error;
                    }
                } else {
                    $response['message'] = 'Announcement is too old to be edited (only editable within 1 week of posting).';
                }
            } else {
                $response['message'] = 'Announcement not found.';
            }
            $checkStmt->close();
        } else {
            $response['message'] = 'Database check prepare error: ' . $conn->error;
        }
    }
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>