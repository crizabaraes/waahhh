document.addEventListener('DOMContentLoaded', async() => {
    const email = localStorage.getItem('userEmail');
    let employee = null;

    const addRequestBtn = document.getElementById('addRequestBtn');
    const addRequestModal = document.getElementById('addRequestModal');
    const addRequestForm = document.getElementById('addRequestForm');
    const cancelBtn = document.getElementById('cancelAddRequestBtn');

    const requestType = document.getElementById('requestType');
    const leaveType = document.getElementById('leaveType');
    const advanceAmountContainer = document.getElementById('advanceAmountContainer');
    const leaveTypeContainer = document.getElementById('leaveTypeContainer');
    const startDateContainer = document.getElementById('startDateContainer');
    const endDateContainer = document.getElementById('endDateContainer');
    const explanationContainer = document.getElementById('explanationContainer');
    const explanationInput = document.getElementById('explanation');
    const proofContainer = document.getElementById('proofContainer');
    const proofInput = document.getElementById('proof');
    const advanceAmountInput = document.getElementById('advanceAmount');
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');

    const viewRequestModal = document.getElementById('viewRequestModal');
    const decisionForm = document.getElementById('decisionForm');
    const closeViewModalBtn = document.getElementById('closeViewModalBtn');
    const leaveDetails = document.getElementById("leaveDetails");
    const advanceDetails = document.getElementById("advanceDetails");
    const requestorName = document.getElementById('requestorName');
    const requestModalType = document.getElementById('requestModalType');
    const requestDate = document.getElementById('requestDate');
    const advanceAmountDisplay = document.getElementById('advanceAmountDisplay');
    const advanceExplanationDisplay = document.getElementById('advanceExplanationDisplay');
    const leavePeriodDisplay = document.getElementById('leavePeriodDisplay');
    const leaveExplanationDisplay = document.getElementById('leaveExplanationDisplay');
    const leaveProofLink = document.getElementById('leaveProofLink');
    const advExplanationContainer = document.getElementById('advExplanationContainer');
    const lvExplanationContainer = document.getElementById('lvExplanationContainer');

    const leaveOptions = [
        { value: 'vacation', text: 'Vacation Leave' },
        { value: 'sick', text: 'Sick Leave' },
        { value: 'maternity_live', text: 'Maternity Leave (Live Birth)', sex: 'female' },
        { value: 'maternity_special', text: 'Maternity Leave (Special Circumstances)', sex: 'female' },
        { value: 'paternity', text: 'Paternity Leave', sex: 'male' },
        { value: 'emergency', text: 'Emergency Leave' },
        { value: 'solo_parent', text: 'Solo Parent Leave' },
        { value: 'slw', text: 'Special Leave for Women (SLW)', sex: 'female' },
        { value: 'unpaid', text: 'Unpaid Leave' },
        { value: 'first_half', text: 'Half Leave (First Half)' },
        { value: 'second_half', text: 'Half Leave (Second Half)' }
    ];

    try {
        const response = await fetch(`get_employee_details.php?work_email=${encodeURIComponent(email)}`);
        const data = await response.json();

        // If employee exists, assign it; otherwise leave as null (Owner)
        if (data.success && data.employees && data.employees.length > 0) {
            employee = data.employees[0];
        } else {
            console.warn('No employee record found for this email. Assuming Owner.');
            employee = null; // explicitly set null for clarity
        }

        // Now load requests in all cases
        loadRequests();
    } catch (err) {
        console.error('Error fetching employee details:', err);
        // Still try to load requests even if employee fetch fails
        loadRequests();
    }

    let approvedLeaveType;
    async function loadRequests() {
        try {
        const formData = new FormData();
        formData.append('action', 'get_requests');
        formData.append('email', email);          // send current user email
        if (employee && employee.id) {
            formData.append('employee_id', employee.id);
        }

        const response = await fetch('requests.php', {
            method: 'POST',
            body: formData
        });
            const data = await response.json();

            if (!data.success) return;

            const pendingCards = document.getElementById('pendingRequests');
            const approvedCards = document.getElementById('approvedRequests');
            const rejectedCards = document.getElementById('rejectedRequests');

            // Clear previous content
            pendingCards.innerHTML = '';
            approvedCards.innerHTML = '';
            rejectedCards.innerHTML = '';

            data.requests.forEach(req => {
                const isAdvance = req.request_type === 'advance';
                const iconClass = isAdvance ? 'fas fa-dollar-sign' : 'fas fa-calendar-alt';

                // Determine h5 and mainText
                const h5Text = isAdvance ? 'Salary Advance' : req.leave_type;
                const mainText = isAdvance
                    ? `PHP ${parseFloat(req.advance_amount).toLocaleString()}`
                    : formatLeaveDates(req.leave_from, req.leave_to);

                let borderClass = 'border-warning'; // pending
                if (req.status === 'approved') borderClass = 'border-success';
                else if (req.status === 'rejected') borderClass = 'border-danger';

                const cardHTML = `
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="card w-100 h-100 request-card border-start ${borderClass} border-4" data-request-id="${req.request_id}">
                            <div class="card-body p-0 d-flex flex-column">
                                <h5 class="fw-bold text-primary-soft-blue mb-1">${h5Text}</h5>
                                <p class="small text-text-muted-grey mb-3">
                                    <i class="${iconClass} me-1"></i> ${mainText}
                                </p>
                                <div class="mt-auto pt-2 border-top d-flex justify-content-between align-items-center">
                                    <span class="fw-semibold text-text-dark-grey mt-2 reqNameRes">${req.employee_name}</span>
                                    <a class="btn btn-card-action mt-2">Review</a>
                                </div>
                            </div>
                        </div>
                    </div>  
                `;

                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = cardHTML.trim();
                const cardCol = tempDiv.firstElementChild; // now this is the actual <div class="col-xl-4 ...">

                // Attach click listener to **this card only**
                const btn = cardCol.querySelector('.btn-card-action');
                btn.addEventListener('click', () => {
                    leaveDetails.classList.toggle("d-none", isAdvance);
                    advanceDetails.classList.toggle("d-none", !isAdvance);

                    requestorName.textContent = req.employee_name;
                    approvedLeaveType = req.leave_type;
                    requestModalType.textContent = req.request_type === 'advance' ? 'Salary Advance' : req.leave_type;
                    advanceAmountDisplay.textContent = req.advance_amount ? `PHP ${parseFloat(req.advance_amount).toLocaleString()}` : '';
                    advanceExplanationDisplay.textContent = req.explanation || '';
                    leavePeriodDisplay.textContent = req.leave_from ? formatLeaveDates(req.leave_from, req.leave_to) : '';
                    leaveExplanationDisplay.textContent = req.explanation || '';

                    if (!req.explanation) {
                        advExplanationContainer.classList.add('d-none');
                        lvExplanationContainer.classList.add('d-none');
                    } else {
                        advExplanationContainer.classList.remove('d-none');
                        lvExplanationContainer.classList.remove('d-none');
                    }

                    const lvProofContainer = document.getElementById('lvProofContainer');
                    if (!req.proof) {
                        lvProofContainer.classList.add('d-none');
                        leaveProofLink.href = '#';
                        leaveProofLink.textContent = '';
                    } else {
                        lvProofContainer.classList.remove('d-none');
                        leaveProofLink.href = req.proof; // use the path as-is
                        // show only the filename
                        const parts = req.proof.split('/');
                        leaveProofLink.textContent = parts[parts.length - 1];
                    }

                    if (req.request_date) {
                        const dateObj = new Date(req.request_date);
                        requestDate.textContent = dateObj.toLocaleDateString(undefined, { year:'numeric', month:'long', day:'numeric' });
                    } else {
                        requestDate.textContent = '';
                    }

                    viewRequestModal.classList.remove('d-none');
                });
                if (req.status === 'pending') pendingCards.appendChild(cardCol);
                else if (req.status === 'approved') approvedCards.appendChild(cardCol);
                else if (req.status === 'rejected') rejectedCards.appendChild(cardCol);
            });
        } catch (err) {
            console.error('Error loading requests:', err);
        }
    }

    // Close View Request Modal
    if (closeViewModalBtn) {
        closeViewModalBtn.addEventListener('click', () => {
            // Hide modal
            viewRequestModal.classList.add('d-none');

            // Reset fields inside modal to default
            requestorName.textContent = '';
            requestModalType.textContent = '';
            advanceAmountDisplay.textContent = '';
            advanceExplanationDisplay.textContent = '';
            leavePeriodDisplay.textContent = '';
            leaveExplanationDisplay.textContent = '';
            leaveProofLink.textContent = '';
            leaveProofLink.href = '#';
            requestDate.textContent = '';
            decisionForm.reset();

            // Hide explanation/proof containers
            document.getElementById('advExplanationContainer')?.classList.add('d-none');
            document.getElementById('lvExplanationContainer')?.classList.add('d-none');
            document.getElementById('lvProofContainer')?.classList.add('d-none');

            // Hide leave/advance details sections
            document.getElementById('leaveDetails')?.classList.add('d-none');
            document.getElementById('advanceDetails')?.classList.add('d-none');
        });
    }
    
    // Show modal and populate balances
    addRequestBtn.addEventListener('click', async () => {
        if (!email) {
            console.error('No email found in localStorage.');
            return;
        }

        try {
            leaveType.innerHTML = '<option value="">Select Leave Type</option>';

            // Add options conditionally based on employee sex
            leaveOptions.forEach(opt => {
                // Skip leave types that are sex-specific
                if (!opt.sex || opt.sex.toLowerCase() === employee.sex.toLowerCase()) {
                    const option = document.createElement('option');
                    option.value = opt.value;

                    // Add balances for applicable leave types
                    let balanceText = '';
                    if (opt.value === 'vacation') balanceText = ` (${employee.vl_balance ?? 0})`;
                    else if (opt.value === 'sick') balanceText = ` (${employee.sl_balance ?? 0})`;
                    else if (opt.value === 'emergency') balanceText = ` (${employee.el_balance ?? 0})`;
                    else if (opt.value === 'solo_parent') balanceText = ` (${employee.spl_balance ?? 0})`;

                    option.textContent = opt.text + balanceText;
                    leaveType.appendChild(option);
                }
            });
            addRequestModal.classList.remove('d-none');
        } catch (err) {
            console.error('Error fetching employee details:', err);
        }
    });

    // Show/hide fields based on request type
    requestType.addEventListener('change', () => {
        const type = requestType.value;
        advanceAmountContainer.classList.toggle('d-none', type !== 'advance');
        leaveTypeContainer.classList.toggle('d-none', type !== 'leave');
        startDateContainer.classList.toggle('d-none', type !== 'leave');
        endDateContainer.classList.toggle('d-none', type !== 'leave');
        explanationContainer.classList.toggle('d-none', type !== 'leave' && type !== 'advance');
        proofContainer.classList.toggle('d-none', true); // hidden by default
        updateFieldRequirements();
    });

    // Handle leave type selection
    leaveType.addEventListener('change', () => {
        const leave = leaveType.value;
        const proofRequiredLeaves = ['sick', 'maternity_live', 'maternity_special', 'paternity', 'slw'];

        proofContainer.classList.toggle('d-none', !proofRequiredLeaves.includes(leave));

        if (leave === 'maternity_live') {
            endDateInput.value = calculateEndDate(startDateInput.value, 105);
            endDateInput.readOnly = true;
        } else if (leave === 'maternity_special') {
            endDateInput.value = calculateEndDate(startDateInput.value, 60);
            endDateInput.readOnly = true;
        } else if (leave === 'paternity') {
            endDateInput.value = calculateEndDate(startDateInput.value, 7);
            endDateInput.readOnly = true;
        } else if (leave === 'slw') {
            endDateInput.value = calculateEndDate(startDateInput.value, 60);
            endDateInput.readOnly = true;
        } else {
            endDateInput.value = '';
            endDateInput.readOnly = false;
        }
        updateFieldRequirements();
        proofInput.value = '';
        advanceAmountInput.value = '';
    });

    function validateEndDate() {
        if (!employee) return; // <-- fixed variable name
        if (requestType.value !== 'leave') return;

        const leave = leaveType.value;
        const start = new Date(startDateInput.value);
        const end = new Date(endDateInput.value);
        start.setHours(0, 0, 0, 0);
        end.setHours(0, 0, 0, 0);

        if (!startDateInput.value || !endDateInput.value) return;

        // End date earlier than start date
        if (end < start) {
            showAlertModal('Invalid Dates', 'End date cannot be earlier than start date.');
            endDateInput.value = '';
            return;
        }

        // Check against leave balance
        let balance = 0;
        if (leave === 'vacation') balance = employee.vl_balance ?? 0;
        else if (leave === 'sick') balance = employee.sl_balance ?? 0;
        else if (leave === 'emergency') balance = employee.el_balance ?? 0;
        else if (leave === 'solo_parent') balance = employee.spl_balance ?? 0;

        const dayCount = Math.floor((end - start) / (1000 * 60 * 60 * 24)) + 1;

        if (balance && dayCount > balance) {
            showAlertModal('Insufficient Balance', `You only have ${balance} day(s) left for ${leaveType.options[leaveType.selectedIndex].text}.`);
            endDateInput.value = '';
        }
    }

    // Update end date if start date changes for fixed-duration leaves
    startDateInput.addEventListener('change', function(){
        const leave = leaveType.value;
        const selectedDate = new Date(this.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate.getTime() < today.getTime()) {
            showAlertModal('Invalid Date', 'You cannot pick a day in the past.');
            this.value = '';
        }
        if (['maternity_live', 'maternity_special', 'paternity', 'slw'].includes(leave)) {
            endDateInput.value = calculateEndDate(startDateInput.value, {
                maternity_live: 105,
                maternity_special: 60,
                paternity: 7,
                slw: 60
            }[leave]);
            endDateInput.readOnly = true;
        } else {
            endDateInput.readOnly = false;
        }
        validateEndDate();
    });

    endDateInput.addEventListener('change', function() {
        const selectedDate = new Date(this.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate.getTime() < today.getTime()) {
            showAlertModal('Invalid Date', 'You cannot pick a day in the past.');
            this.value = '';
        }
        validateEndDate();
    });

    function updateFieldRequirements() {
        const type = requestType.value;
        const leave = leaveType.value;

        leaveType.required = false;
        startDateInput.required = false;
        endDateInput.required = false;
        proofInput.required = false;
        advanceAmountInput.required = false;

        if (type === 'leave') {
            leaveType.required = true;
            startDateInput.required = true;
            endDateInput.required = true;

            if (['maternity_live', 'maternity_special', 'paternity', 'slw', 'sick'].includes(leave)) {
                proofInput.required = true;
            }
        } else if (type === 'advance') {
            advanceAmountInput.required = true;
        }
    }

    function calculateEndDate(start, days) {
        if (!start) return '';
        const date = new Date(start);
        date.setDate(date.getDate() + days - 1);
        return date.toISOString().split('T')[0];
    }

    cancelBtn.addEventListener('click', () => {
        addRequestModal.classList.add('d-none');
        addRequestForm.reset();

        // Show only requestType
        requestType.classList.remove('d-none');

        // Hide all other fields
        leaveTypeContainer.classList.add('d-none');
        startDateContainer.classList.add('d-none');
        endDateContainer.classList.add('d-none');
        advanceAmountContainer.classList.add('d-none');
        explanationContainer.classList.add('d-none');
        proofContainer.classList.add('d-none');

        // Reset endDate readOnly in case it was set by a fixed-duration leave
        endDateInput.readOnly = false;
    });

    // -------------------------------
    // Submit Add Request Form
    // -------------------------------
    addRequestForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!employee) return;

        const type = requestType.value;

        // --------- Validation ---------
        if (type === 'leave') {
            if (!leaveType.value) {
                showAlertModal('Missing Field', 'Please select a leave type.');
                return;
            }
            if (!startDateInput.value || !endDateInput.value) {
                showAlertModal('Missing Field', 'Please select start and end dates.');
                return;
            }
            // Proof validation
            const proofRequiredLeaves = ['sick', 'maternity_live', 'maternity_special', 'paternity', 'slw'];
            if (proofRequiredLeaves.includes(leaveType.value) && !proof.value) {
                showAlertModal('Missing Field', 'Please attach proof.');
                return;
            }
        }

        // --------- Prepare FormData ---------
        const formData = new FormData();
        formData.append('action', 'add_request');
        formData.append('employee_id', employee.id);
        formData.append('request_type', type);
        if (type === 'leave') {
            formData.append('leave_type', leaveType.selectedOptions[0]?.text.replace(/\s*\(\d+\)$/,'') || '');
        }
        formData.append('leave_from', startDateInput.value || '');
        formData.append('leave_to', endDateInput.value || '');
        formData.append('explanation', explanationInput.value || '');
        formData.append('advance_amount', parseFloat(advanceAmountInput.value || 0.0));
        
        if (proofInput.files.length > 0) {
            formData.append('proof', proofInput.files[0]);
        }

        // --------- Submit to PHP ---------
        try {
            const response = await fetch('requests.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                addRequestForm.reset();
                addRequestModal.classList.add('d-none');
                requestType.classList.remove('d-none');

                // Hide all other fields
                leaveTypeContainer.classList.add('d-none');
                startDateContainer.classList.add('d-none');
                endDateContainer.classList.add('d-none');
                advanceAmountContainer.classList.add('d-none');
                explanationContainer.classList.add('d-none');
                proofContainer.classList.add('d-none');

                // Reset endDate readOnly in case it was set by a fixed-duration leave
                endDateInput.readOnly = false;
                loadRequests();
            } else {
                console.error(data.message);
            }
        } catch (err) {
            console.error('Error submitting request: ', err);
            showAlertModal('Error', 'An unexpected error occurred.');
        }
    });

    function formatLeaveDates(from, to) {
        if (!from) return '';
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        const start = new Date(from);
        const end = to ? new Date(to) : start;

        // If same month and year, show like "October 20 – 22, 2025"
        if (start.getMonth() === end.getMonth() && start.getFullYear() === end.getFullYear()) {
            return `${start.toLocaleDateString(undefined, { month: 'long', day: 'numeric' })} – ${end.getDate()}, ${end.getFullYear()}`;
        } else {
            // Otherwise, show full dates
            return `${start.toLocaleDateString(undefined, options)} – ${end.toLocaleDateString(undefined, options)}`;
        }
    }

    if (email) {
        fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.owner.length > 0) {
                    const emp = data.owner[0];
                    const position = emp.position.trim();

                    if (position && position.toLowerCase() === 'owner') {
                        addRequestBtn.style.visibility = 'hidden';
                    }
                }
            })
            .catch(err => console.error(err));
    }
});
