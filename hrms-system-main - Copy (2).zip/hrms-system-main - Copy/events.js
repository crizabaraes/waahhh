document.addEventListener('DOMContentLoaded', function() {
    // -------- Event Modals and Functionality --------
    const addEventBtn = document.getElementById('addEventBtn');
    const addEventModal = document.getElementById('addEventModal');
    const addEventForm = document.getElementById('addEventForm');
    const cancelEventBtn = document.getElementById('cancelEventBtn');
    const eventsList = document.getElementById('eventsList'); // The container for event items

    const viewEventModal = document.getElementById('viewEventModal');
    const viewEventTitle = document.getElementById('viewEventTitle');
    const viewEventDate = document.getElementById('viewEventDate'); // Specific event date
    const viewEventPostDate = document.getElementById('viewEventPostDate'); // Post date for edit logic
    const viewEventDetails = document.getElementById('viewEventDetails');
    const closeEventBtn = document.getElementById('closeEventBtn');

    let currentEditEventId = null; // To track if we're in edit mode
    const eventModalTitle = document.getElementById('eventModalTitle'); // The modal's H5 title
    const eventIdInput = document.getElementById('eventId'); // Hidden input for ID
    const postUpdateEventBtn = document.getElementById('postUpdateEventBtn');

    // Helper function to format date for display
    function formatDate(dateString) {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('en-US', options);
    }

    // Helper function to format date for input type="date"
    function formatInputDate(dateString) {
        const date = new Date(dateString);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // Function to dynamically update the edit button state for events
    function updateEditButtonState(eventData, cardElement) {
        const postDate = new Date(eventData.post_date);
        const now = new Date();
        const editableUntil = new Date(postDate);
        editableUntil.setDate(postDate.getDate() + 7); // 7 days from postDate

        const isEditable = now < editableUntil; // Check if current time is BEFORE editableUntil

        const editBtn = cardElement.querySelector('.edit-event-icon');
        if (editBtn) {
            if (isEditable) {
                editBtn.disabled = false;
                editBtn.classList.remove('disabled-edit-icon');
                editBtn.title = 'Edit Event';
            } else {
                editBtn.disabled = true;
                editBtn.classList.add('disabled-edit-icon');
                editBtn.title = 'Cannot edit (older than 1 week)';
            }
        }
    }

    // NEW: Function to manage the periodic updates of event edit buttons AND event removal
    function startEventTimerUpdates() {
        // Clear any existing interval to prevent multiple timers running
        if (window.eventUpdateInterval) {
            clearInterval(window.eventUpdateInterval);
        }

        // Set up a new interval
        window.eventUpdateInterval = setInterval(async () => { // ADD 'async' here
            const eventCards = eventsList.querySelectorAll('.event-item');
            let currentUpcomingEventsCount = 0; // Initialize count for this interval tick
            eventCards.forEach(async cardElement => { // ADD 'async' here
                const eventData = cardElement.eventData; // Access the stored data
                if (eventData) {
                    // Update edit button state (existing logic)
                    updateEditButtonState(eventData, cardElement);

                    // NEW: Check if event_date has passed and remove from DB
                    const eventDate = new Date(eventData.event_date);
                    const now = new Date();

                    // Set time of 'now' to midnight for comparison to only compare dates
                    now.setHours(0, 0, 0, 0);
                    eventDate.setHours(0, 0, 0, 0);

                    if (eventDate.getTime() < now.getTime()) { // Use getTime() for robust comparison, If event date is in the past
                        // Attempt to delete from database
                        try {
                            const formData = new FormData();
                            formData.append('id', eventData.id);

                            const response = await fetch('delete_event.php', {
                                method: 'POST',
                                body: formData
                            });
                            const result = await response.json();

                            if (result.success) {
                                cardElement.remove(); // Remove from DOM only after successful DB deletion
                            } else {
                                console.error(`Failed to delete event "${eventData.title}" (ID: ${eventData.id}) from DB:`, result.message);
                                // Optionally, you might still remove it from DOM if DB deletion failed but you want it gone
                                // cardElement.remove();
                            }
                        } catch (error) {
                            console.error(`Network error attempting to delete event "${eventData.title}" (ID: ${eventData.id}):`, error);
                            // Optionally, you might still remove it from DOM if network error
                            // cardElement.remove();
                        }
                    }
                    else {
                        currentUpcomingEventsCount++; // ADD THIS LINE: Increment count for events that are still upcoming
                    }
                }
            });

            // but for simplicity, let's keep the current check.
            document.getElementById('upcomingEventsCount').textContent = currentUpcomingEventsCount; // Update the metric periodically
            const remainingCards = eventsList.querySelectorAll('.event-item');
            if (remainingCards.length === 0) {
                eventsList.innerHTML = '<p class="text-text-muted-grey text-center py-4">No events yet. Click "Add Event" to post one!</p>';
                if (window.eventUpdateInterval) {
                    clearInterval(window.eventUpdateInterval); // Stop interval if no events left
                }
            }
        }, 6 * 1000); // Run every 10 seconds (adjust as needed)
    }

    // Function to create an event card
    function createEventCard(eventData) {
        const cardDiv = document.createElement('div');
        cardDiv.className = 'list-group-item list-group-item-action event-item p-3';
        cardDiv.setAttribute('data-id', eventData.id);
        cardDiv.eventData = eventData; // Store the full event object

        // Truncate details for preview (100 characters)
        const previewDetails = eventData.details.length > 240
            ? eventData.details.substring(0, 240) + '...'
            : eventData.details;

        // Determine initial editable state for rendering
        const postDate = new Date(eventData.post_date);
        const now = new Date();
        const editableUntil = new Date(postDate);
        editableUntil.setDate(postDate.getDate() + 7); // 7 days from postDate
        const isEditable = now < editableUntil;

        cardDiv.innerHTML = `
            <div class="d-flex align-items-start">
                <div class="icon-wrapper me-3">
                    <i class="fas fa-calendar-check text-primary-soft-blue fs-5"></i>
                </div>
                <div class="flex-grow-1 content-area">
                    <div class="title-date">
                        <h5 class="mb-1 fs-6 text-text-dark-grey fw-bold evTitleRes"><u>${eventData.title}</u></h5>
                        <small class="text-text-kinda-grey fw-semibold evDateRes">${formatDate(eventData.event_date)}</small>
                    </div>
                    <p class="small text-text-dark-grey mb-0 deetsRes">${previewDetails}</p>
                </div>
            </div>
            <div class="d-flex justify-content-between align-items-center w-100 mt-1">
                <button class="btn btn-sm btn-outline-custom edit-event-icon me-2 ${isEditable ? '' : 'disabled-edit-icon'}"
                        data-id="${eventData.id}"
                        title="${isEditable ? 'Edit Event' : 'Cannot edit (older than 1 week)'}"
                        ${isEditable ? '' : 'disabled'}>
                    <i class="fas fa-edit"></i>
                </button>
                <small class="text-primary-soft-blue text-decoration-none fw-medium view-details-link" data-id="${eventData.id}">View Details <i class="fas fa-arrow-right ms-1"></i></small>
            </div>
        `;

        // Add event listener for View Details
        cardDiv.querySelector('.view-details-link').addEventListener('click', (event) => {
            event.preventDefault();
            viewEventTitle.textContent = eventData.title;
            viewEventDate.textContent = `Event Date: ${formatDate(eventData.event_date)}`;
            viewEventPostDate.textContent = `Posted: ${formatDate(eventData.post_date)}`;
            viewEventDetails.textContent = eventData.details;
            viewEventModal.classList.remove('d-none');
        });

        // Add event listener for Edit button
        const editBtn = cardDiv.querySelector('.edit-event-icon');
        if (editBtn) {
            editBtn.addEventListener('click', (event) => {
                event.preventDefault();
                event.stopPropagation(); // Prevent view details from opening

                if (editBtn.disabled) {
                    return; // Do nothing if the button is disabled
                }

                currentEditEventId = eventData.id;
                eventIdInput.value = eventData.id;
                document.getElementById('eventTitle').value = eventData.title;
                document.getElementById('eventDetails').value = eventData.details;
                document.getElementById('eventDate').value = formatInputDate(eventData.event_date); // Set event date input

                eventModalTitle.textContent = 'Edit Event';
                postUpdateEventBtn.textContent = 'Update';
                addEventModal.classList.remove('d-none');
            });
        }

        // Set initial state of the edit button (redundant but prevents flicker)
        updateEditButtonState(eventData, cardDiv);

        return cardDiv;
    }

    async function loadEvents() { // Ensure this function is async
        try {
            const response = await fetch('fetch_events.php');
            const result = await response.json();

            if (result.success) {
                eventsList.innerHTML = ''; // Clear existing content

                const now = new Date();
                now.setHours(0, 0, 0, 0); // Set to midnight for date-only comparison

                const eventsToKeep = [];
                const eventsToDelete = [];
                let upcomingEventsCount = 0;

                // First, categorize events: those to keep and those to delete
                result.events.forEach(eventData => {
                    const eventDate = new Date(eventData.event_date);
                    eventDate.setHours(0, 0, 0, 0); // Set to midnight for date-only comparison

                    if (eventDate.getTime() < now.getTime()) { // Use getTime() for robust comparison
                        eventsToDelete.push(eventData);
                    } else {
                        eventsToKeep.push(eventData);
                        upcomingEventsCount++;
                    }
                });

                // Render only the events that are still current
                if (eventsToKeep.length > 0) {
                    eventsToKeep.forEach(eventData => {
                        const card = createEventCard(eventData);
                        eventsList.appendChild(card);
                    });
                    startEventTimerUpdates(); // Start/restart timer for remaining events
                } else {
                    eventsList.innerHTML = '<p class="text-text-muted-grey text-center py-4">No events yet. Click "Add Event" to post one!</p>';
                    if (window.eventUpdateInterval) {
                        clearInterval(window.eventUpdateInterval); // Clear interval if no events to display
                    }
                }
                
                document.getElementById('upcomingEventsCount').textContent = upcomingEventsCount; // Update the metric

                // Immediately delete outdated events from the database (asynchronously)
                // We don't need to await these, as they don't block display
                eventsToDelete.forEach(async eventData => {
                    try {
                        const formData = new FormData();
                        formData.append('id', eventData.id);
                        const deleteResponse = await fetch('delete_event.php', {
                            method: 'POST',
                            body: formData
                        });
                        const deleteResult = await deleteResponse.json();
                        if (!deleteResult.success) {
                            console.error(`Failed to delete old event "${eventData.title}" (ID: ${eventData.id}) from DB on load:`, deleteResult.message);
                        }
                    } catch (error) {
                        console.error(`Network error deleting old event "${eventData.title}" (ID: ${eventData.id}) on load:`, error);
                    }
                });

            } else { // Handle cases where result.success is false (e.g., DB error)
                console.error('Failed to load events:', result.message);
                eventsList.innerHTML = '<p class="text-danger text-center py-4">Error loading events.</p>';
                if (window.eventUpdateInterval) {
                    clearInterval(window.eventUpdateInterval);
                }
            }
        } catch (error) {
            console.error('Error fetching events:', error);
            eventsList.innerHTML = '<p class="text-danger text-center py-4">Network error loading events.</p>';
            if (window.eventUpdateInterval) {
                clearInterval(window.eventUpdateInterval);
            }
        }
    }

    // Show Add Event Modal (for new event)
    if (addEventBtn) {
        addEventBtn.addEventListener('click', () => {
            currentEditEventId = null; // Ensure we're in 'add' mode
            eventIdInput.value = ''; // Clear hidden ID
            addEventForm.reset(); // Clear form fields
            eventModalTitle.textContent = 'Add New Event'; // Set modal title
            postUpdateEventBtn.textContent = 'Post'; // Set button text
            addEventModal.classList.remove('d-none');
        });
    }

    // Hide Add Event Modal
    if (cancelEventBtn) {
        cancelEventBtn.addEventListener('click', () => {
            addEventModal.classList.add('d-none');
            currentEditEventId = null; // Reset edit state
            eventIdInput.value = ''; // Clear hidden ID
            eventModalTitle.textContent = 'Add New Event'; // Reset modal title
            postUpdateEventBtn.textContent = 'Post'; // Reset button text
        });
    }

    // Hide View Event Modal
    if (closeEventBtn) {
        closeEventBtn.addEventListener('click', () => {
            viewEventModal.classList.add('d-none');
        });
    }
    if (viewEventModal) {
        viewEventModal.addEventListener('click', (event) => {
            if (event.target === viewEventModal) {
                viewEventModal.classList.add('d-none');
            }
        });
    }

    // Date input validation on change
    const eventDateInputField = document.getElementById('eventDate'); 
    if (eventDateInputField) {
        eventDateInputField.addEventListener('change', function () {
            const selectedDate = new Date(this.value);
            const today = new Date();
            today.setHours(0, 0, 0, 0); // compare only dates

            if (selectedDate.getTime() < today.getTime()) {
                showAlertModal('Invalid Date', 'You cannot schedule an event in the past.');
                this.value = ''; // clear invalid date
            }
        });
    }

    // Handle Add/Update Event Form Submission
    if (addEventForm) {
        addEventForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const formData = new FormData(addEventForm);

            const url = currentEditEventId ? 'update_event.php' : 'add_event.php';

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    addEventModal.classList.add('d-none'); // Hide modal
                    loadEvents(); // Reload all events to reflect changes
                    currentEditEventId = null; // Reset edit state
                    eventIdInput.value = ''; // Clear hidden ID
                    eventModalTitle.textContent = 'Add New Event'; // Reset modal title
                    postUpdateEventBtn.textContent = 'Post'; // Reset button text
                } else {
                    showAlertModal('Error', 'An error occurred. Please try again.');
                }
            } catch (error) {
                console.error('Error submitting event:', error);
                showAlertModal('Error', 'An error occurred. Please try again.');
            }
        });
    }

    // Initial load of events when the page loads
    loadEvents();
});
