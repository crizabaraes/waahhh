document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const searchToggleIcon = document.getElementById("searchToggleIcon");
    const searchGroup = document.querySelector(".input-group.rounded-pill");
    const dashboardTitle = document.querySelector("h2.fw-bold.mb-0");
    const notificationBtn = document.querySelector(".fa-bell").closest("button");
    const profileDropdown = document.querySelector("#userDropdown").closest(".dropdown");

    function setSidebarState() {
        if (window.innerWidth <= 900) {
            if (sidebar) sidebar.classList.add('collapsed');
        } else {
            if (sidebar) sidebar.classList.remove('collapsed');
        }
    }

     function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
        }

    // Event listener for desktop sidebar toggle
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }

    setSidebarState();
    window.addEventListener('resize', setSidebarState);

    const backButton = document.createElement("button");
    backButton.innerHTML = '<i class="fas fa-arrow-left fs-6"></i>';
    backButton.className = "btn btn-link text-text-dark-grey me-1 d-none";
    searchGroup.parentNode.insertBefore(backButton, searchGroup);

    function showSearch() {
        const headerParent = searchGroup.parentElement;
        headerParent.style.width = '100%';
        searchGroup.style.display = 'flex';
        searchGroup.style.flex = '1 1 auto';
        backButton.classList.remove('d-none');
        searchToggleIcon.classList.add('d-none');
        dashboardTitle.classList.add('d-none');
        notificationBtn.classList.add('d-none');
        profileDropdown.classList.add('d-none');
        }

    function hideSearch() {
        searchGroup.style.display = 'none';
        backButton.classList.add('d-none');
        searchToggleIcon.classList.remove('d-none');
        dashboardTitle.classList.remove('d-none');
        notificationBtn.classList.remove('d-none');
        profileDropdown.classList.remove('d-none');
        searchGroup.style.width = '380px';
        const headerParent = searchGroup.parentElement;
        headerParent.style.width = '';
    }

    searchToggleIcon.addEventListener("click", showSearch);
    backButton.addEventListener("click", hideSearch);

    // Handle resize
    window.addEventListener("resize", () => {
    if (window.innerWidth > 960) {
        searchGroup.style.display = "flex";
        searchToggleIcon.classList.add("d-none");
        backButton.classList.add("d-none");
        dashboardTitle.classList.remove("d-none");
        notificationBtn.classList.remove("d-none");
        profileDropdown.classList.remove("d-none");
    } else {
        hideSearch();
    }
    });

    const notificationList = document.getElementById('notificationList');

    async function loadNotifications() {
        try {
            let url = 'get_notifications.php';

            // Optional: pass employee_id if needed
            const employeeId = localStorage.getItem('employeeId');
            if (employeeId) url += `?employee_id=${employeeId}`;

            const res = await fetch(url);
            const data = await res.json();

            if (data.success && data.notifications.length > 0) {
                data.notifications.forEach(({ title, content }) => {
                    const notifCard = `
                        <a href="#" class="list-group-item list-group-item-action payroll-card d-flex align-items-center justify-content-between p-3">
                            <div class="d-flex align-items-center">
                                <div class="icon-shape d-flex align-items-center justify-content-center me-3">
                                    <i class="fas fa-bell"></i>
                                </div>
                                <div class="content-area">
                                    <h5 class="fw-semibold text-text-dark-grey mb-1">${title}</h5>
                                    <p class="small text-text-dark-grey mb-0 mt-1">${content}</p>
                                </div>
                            </div>
                            <div class="text-end">
                                <small class="text-primary-soft-blue text-decoration-none fw-medium">
                                    View Details <i class="fas fa-arrow-right ms-1"></i>
                                </small>
                            </div>
                        </a>
                    `;
                    notificationList.innerHTML += notifCard;
                });
            } else {
                notificationList.innerHTML = `<div class="text-center text-text-muted-grey py-3">No notifications available.</div>`;
            }
        } catch (err) {
            console.error('Error fetching notifications:', err);
            notificationList.innerHTML = `<p class="text-danger small mb-0">Failed to load notifications.</p>`;
        }
    }

    // Call the async function
    loadNotifications();
});