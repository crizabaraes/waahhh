document.addEventListener('DOMContentLoaded', function() {
    const payrollPageHeaderTitle = document.getElementById('payrollPageHeaderTitle');
    const payrollPeriodYearFilter = document.getElementById('payrollPeriodYearFilter');
    const confirmUploadModal = document.getElementById('confirmUploadModal');
    const confirmUploadYes = document.getElementById('confirmUploadYes');
    const confirmUploadNo = document.getElementById('confirmUploadNo');
    const customAlertModal = document.getElementById('customAlertModal');
    const customAlertTitle = document.getElementById('customAlertTitle');
    const customAlertMessage = document.getElementById('customAlertMessage');
    const closeCustomAlertBtn = document.getElementById('closeCustomAlertBtn');

    let currentEvaluationId = null;
    let currentEmployeeName = null;
    let currentQuarterYear = null;
    let currentEmployeeId = null;

    function showModal(modalId, title = null, message = null) {
        if (!modalId) return;

        // If title/message are provided, assume it’s an alert-style modal
        if (title !== null) {
            customAlertTitle.textContent = title;
            customAlertMessage.textContent = message;
            customAlertModal.classList.remove('d-none');
        }

        modalId.classList.remove('d-none');
    }

    function hideModal(modalId) {
        if (!modalId) return;
        modalId.classList.add('d-none');
    }

    // Close modal if backdrop clicked
    if (confirmUploadModal) {
        confirmUploadModal.addEventListener('click', (event) => {
            if (event.target === confirmUploadModal) {
                confirmUploadModal.classList.add('d-none');
            }
        });
    }

    // Function to populate the year filter combo box
    async function populateYearFilter(employeeId) {
        try {
            // The get_existing_years.php script fetches all distinct years.
            const response = await fetch(`get_existing_years.php?employee_id=${employeeId}`);
            const data = await response.json();
            const payrollPeriodYearFilter = document.getElementById('payrollPeriodYearFilter');
            if (data.success) {
                // Clear existing options
                payrollPeriodYearFilter.innerHTML = '';
                // Add a placeholder option
                const placeholder = document.createElement('option');
                placeholder.textContent = 'Select Year';
                placeholder.value = '';
                payrollPeriodYearFilter.appendChild(placeholder);

                data.years.forEach(yearObj => {
                    const year = yearObj.quarter_year; // THIS IS THE FIX
                    const option = document.createElement('option');
                    option.value = year;
                    option.textContent = year;
                    payrollPeriodYearFilter.appendChild(option);
                });
            }
        } catch (error) {
            console.error('Error populating year filter:', error);
        }
    }

    // HR Form Upload
    if (evaluationForm) {
        evaluationForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            const file = uploadEvaluationInput.files[0];
            if (!file) {
                showModal(customAlertModal, 'No File Selected', 'Please select a file to upload.');
                return;
            }

            showModal(confirmUploadModal);
            
            // Populate hidden inputs with data from URL params
            const formData = new FormData();
            formData.append('evaluation_file', file);
            formData.append('employee_id', currentEmployeeId);
            formData.append('evaluation_id', currentEvaluationId);

            if (confirmUploadYes) {
                confirmUploadYes.addEventListener('click', async function() {
                    hideModal(confirmUploadModal);
                    try {
                        const response = await fetch('upload_evaluation_form.php', {
                            method: 'POST',
                            body: formData
                        });
                        const result = await response.json();

                        if (result.success) {
                            renderUploadedFileCard(file.name, result.filePath);
                            // Hide the form since the file has been uploaded
                            evaluationForm.style.display = 'none';
                            currentHrFormFilePath = result.filePath; 
                            uploadEvaluationInput.value = ''; 
                            clearUploadedFileBtn.classList.add('d-none');
                            loadEvaluationDetails(currentEvaluationId, currentQuarterYear);
                        } else {
                            showModal(customAlertModal, 'Upload Error', 'Error uploading file: ' + result.message);
                        }
                    } catch (error) {
                        console.error('Error submitting form:', error);
                        showModal(customAlertModal, 'Upload Error', 'An unexpected error occurred during file upload. Please try again.');
                    }
                });
            }
        });
    }

    if (confirmUploadNo) {
        confirmUploadNo.addEventListener('click', function() {
            hideModal(confirmUploadModal);
        });
    }

    async function initializePage() {
        const params = new URLSearchParams(window.location.search);
        currentEmployeeId = params.get('employeeId');
        currentEvaluationId = params.get('evaluationId');
        currentEmployeeName = params.get('employeeName');

        currentQuarterYear = quarterParts[1];

        payrollPageHeaderTitle.textContent = `${currentQuarterYear} ${quarterParts[0]} Evaluation for ${currentEmployeeName}`;
        await populateYearFilter(currentEmployeeId);
        if (currentQuarterYear) {
            payrollPeriodYearFilter.value = currentQuarterYear;
        }
    }

    initializePage();
});