<?php
require 'authentication/db_connect.php'; // DB connection
date_default_timezone_set('Asia/Manila'); 
$today = date('Y-m-d');
$todayDay = date('l');
$currentHour = date('H'); // 24-hour format
$currentMinute = date('i');

// --- ABSENT check: only run at 23:59 ---
if ($currentHour == 13 && $currentMinute <= 59) {
    $employees = $conn->query("
        SELECT id, work_shift_start, work_shift_end 
        FROM employees 
        WHERE account_status != 'deactivated'
    ");

    while ($emp = $employees->fetch_assoc()) {
        $emp_id = $emp['id'];
        $shift_start = $emp['work_shift_start'];
        $shift_end = $emp['work_shift_end'];

        $stmt = $conn->prepare("
            SELECT attendance_id 
            FROM attendance 
            WHERE employee_id = ? 
            AND attendance_date = ?
        ");
        $stmt->bind_param("ss", $emp_id, $today);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        
        $update = $conn->prepare("
            UPDATE attendance
            SET status = 'ABSENT'
            WHERE employee_id = ?
              AND attendance_date = ?
              AND (
                    (time_in IS NOT NULL AND time_out IS NULL) OR
                    (time_in IS NULL AND time_out IS NOT NULL)
                  )
        ");
        
        $update->bind_param("ss", $emp_id, $today);
        $update->execute();

        if ($exists) continue;

        $stmt = $conn->prepare("
            INSERT INTO attendance (employee_id, attendance_date, status, shift_start, shift_end)
            VALUES (?, ?, 'ABSENT', ?, ?)
        ");
        $stmt->bind_param("ssss", $emp_id, $today, $shift_start, $shift_end);
        $stmt->execute();
    }
}

// --- REST check: only run at 00:00 ---
if ($currentHour == 0 && $currentMinute == 0) {
    $employees = $conn->query("
        SELECT id, rest_day, work_shift_start, work_shift_end
        FROM employees
        WHERE account_status != 'deactivated'
    ");

    while ($emp = $employees->fetch_assoc()) {
        $emp_id = $emp['id'];
        $rest_day = $emp['rest_day'];

        $stmt = $conn->prepare("
            SELECT attendance_id 
            FROM attendance 
            WHERE employee_id = ? AND attendance_date = ?
        ");
        $stmt->bind_param("ss", $emp_id, $today);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        if ($row) {
    // Check existing row's status
    $checkStatus = $conn->prepare("
        SELECT status 
        FROM attendance 
        WHERE attendance_id = ?
    ");
    $checkStatus->bind_param("i", $row['attendance_id']);
    $checkStatus->execute();
    $statusRow = $checkStatus->get_result()->fetch_assoc();

    if (in_array($statusRow['status'], ['REGULAR', 'SPECIAL'])) {
        // Update rest_day for this row
        $updateRest = $conn->prepare("
            UPDATE attendance 
            SET rest_day = ?
            WHERE attendance_id = ?
        ");
        $updateRest->bind_param("si", $emp['rest_day'], $row['attendance_id']);
        $updateRest->execute();
    }

    continue; // Skip inserting a new row
}


        if ($todayDay === $rest_day) {
            $shift_start = $emp['work_shift_start'];
            $shift_end = $emp['work_shift_end'];

            $stmt2 = $conn->prepare("
                INSERT INTO attendance (employee_id, attendance_date, status, shift_start, shift_end)
                VALUES (?, ?, 'OFF', ?, ?)
            ");
            $stmt2->bind_param("ssss", $emp_id, $today, $shift_start, $shift_end); 
            $stmt2->execute();
        }
    }
}
