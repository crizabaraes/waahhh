<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'count' => 0, 'message' => ''];

try {
    if (!isset($_GET['employee_id'])) throw new Exception('employee_id missing');

    $employeeId = $_GET['employee_id'];

    // Get the branch of this employee
    $stmt = $conn->prepare("SELECT branch FROM employees WHERE id = ?");
    $stmt->bind_param("s", $employeeId);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    if (!$row) throw new Exception('Employee not found');

    $branch = $row['branch']; // assign to $branch

    // Count employees in the same branch excluding this employee
    $stmt = $conn->prepare("SELECT COUNT(id) AS total_employees 
                            FROM employees 
                            WHERE branch = ? AND id != ? 
                              AND LOWER(position) != 'human resources'
                              AND LOWER(account_status) != 'deactivated'");
    $stmt->bind_param("ss", $branch, $employeeId);
    $stmt->execute();
    $res = $stmt->get_result();
    $countRow = $res->fetch_assoc();

    $response['success'] = true;
    $response['count'] = (int)$countRow['total_employees'];

    $stmt->close();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("get_peers_count.php error: " . $e->getMessage());
} finally {
    if ($conn) $conn->close();
}

echo json_encode($response);
?>
