<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;

    if (empty($id)) {
        $response['message'] = 'Missing event ID.';
    } else {
        // Prepare a delete statement
        $stmt = $conn->prepare("DELETE FROM events WHERE id = ?");

        if ($stmt) {
            $stmt->bind_param("i", $id); // 'i' for integer

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $response['success'] = true;
                    $response['message'] = 'Event deleted successfully.';
                } else {
                    $response['message'] = 'Event not found or already deleted.';
                }
            } else {
                $response['message'] = 'Failed to delete event: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $response['message'] = 'Database prepare error: ' . $conn->error;
        }
    }
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>
