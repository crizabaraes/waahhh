<?php
require_once 'authentication/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Fetch user details
    $stmt = $conn->prepare("SELECT * FROM login_credentials WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $current_time = time();

        // ✅ AUTO-RESET if lock time has passed
        if (!empty($user['wait_time']) && strtotime($user['wait_time']) <= $current_time) {
            $reset_stmt = $conn->prepare("UPDATE login_credentials SET failed_attempts = 0, wait_time = NULL WHERE email = ?");
            $reset_stmt->bind_param("s", $email);
            $reset_stmt->execute();
            $reset_stmt->close();
            $user['failed_attempts'] = 0;
            $user['wait_time'] = null;
        }

        // Check if user is still locked out
        if (!empty($user['wait_time']) && strtotime($user['wait_time']) > $current_time) {
            $remaining = strtotime($user['wait_time']) - $current_time;
            echo json_encode([
                'success' => false,
                'message' => 'Too many failed attempts. Try again in ' . ceil($remaining / 60) . ' minute(s).'
            ]);
            exit();
        }

        // ✅ Block login if account is not active
        if (strtolower($user['account_status'] ?? '') !== 'active') {
            echo json_encode([
                'success' => false,
                'message' => 'This account has been deactivated. Please contact HR for assistance.'
            ]);
            exit();
        }

        // Validate password
        if (password_verify($password, $user['password'])) {
            // Reset failed_attempts and wait_time
            $reset_stmt = $conn->prepare("UPDATE login_credentials SET failed_attempts = 0 WHERE email = ?");
            $reset_stmt->bind_param("s", $email);
            $reset_stmt->execute();
            $reset_stmt->close();

            // Check agreement
            if ((int)$user['agreement'] === 1) {
                $redirect = 'main.html';
            } else {
                $redirect = 'agreement.html';
            }

            echo json_encode(['success' => true, 'redirect' => $redirect]);
        } else {
            // Wrong password
            $failed_attempts = (int)$user['failed_attempts'] + 1;

            if ($failed_attempts >= 5) {
                // Set 3-minute lockout
                $wait_time = date('Y-m-d H:i:s', time() + 180);
                $update_stmt = $conn->prepare("UPDATE login_credentials SET failed_attempts = ?, wait_time = ? WHERE email = ?");
                $update_stmt->bind_param("iss", $failed_attempts, $wait_time, $email);
                $update_stmt->execute();
                $update_stmt->close();

                echo json_encode([
                    'success' => false,
                    'message' => 'Too many failed attempts. Please wait 3 minutes before trying again.'
                ]);
            } else {
                // Just increment failed attempts
                $update_stmt = $conn->prepare("UPDATE login_credentials SET failed_attempts = ? WHERE email = ?");
                $update_stmt->bind_param("is", $failed_attempts, $email);
                $update_stmt->execute();
                $update_stmt->close();

                echo json_encode([
                    'success' => false,
                    'message' => 'Incorrect email or password.'
                ]);
            }
        }
    } else {
        // No matching email
        echo json_encode(['success' => false, 'message' => 'Incorrect email or password.']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}

$conn->close();
?>
