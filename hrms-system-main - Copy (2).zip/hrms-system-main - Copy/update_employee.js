document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const employeeId = params.get("employeeId");
    const empId = localStorage.getItem('employeeId');

    // New Employee Modal elements
    const updateEmployeeBtn = document.getElementById('updateEmployeeBtn');
    const updatePasswordBtn = document.getElementById('updatePasswordBtn');
    const updateEmployeeModal = document.getElementById('updateEmployeeModal');
    const updatePasswordModal = document.getElementById('updatePasswordModal');
    const updateEmployeeForm = document.getElementById('updateEmployeeForm');
    const updatePasswordForm = document.getElementById('updatePasswordForm');
    const cancelUpdateEmployeeBtn = document.getElementById('cancelUpdateEmployeeBtn');
    const cancelUpdatePasswordBtn = document.getElementById('cancelUpdatePasswordBtn');
    const employeeBirthdayInput = document.getElementById('employeeBirthday');
    const employeeAgeInput = document.getElementById('employeeAge');
    const employeeDateJoinedInput = document.getElementById('employeeDateJoined');
    const employeeContactInput = document.getElementById('employeeContact');
    const employeeShiftStartInput = document.getElementById('employeeShiftStart');
    const employeeShiftEndInput = document.getElementById('employeeShiftEnd');
    const employeeFullName = document.getElementById('employeeFullName');
    const employeeWorkEmailInput = document.getElementById('employeeWorkEmail');
    const employeeAddress = document.getElementById('employeeAddress');
    const employeeSex = document.getElementById('employeeSex');
    const employeeCivilStatus = document.getElementById('employeeCivilStatus');
    const employeeBranch = document.getElementById('employeeBranch');
    const employeePositionn = document.getElementById('employeePositionn');
    const employeeMonthlySalary = document.getElementById('employeeMonthlySalary');
    const employeeSSSContribution = document.getElementById('employeeSSSContribution');
    const employeeHDMFContribution = document.getElementById('employeeHDMFContribution');
    const employeePHICContribution = document.getElementById('employeePHICContribution');
    const employeeRestDay = document.getElementById('employeeRestDay');
    const employeeQRcodeIdInput = document.getElementById('employeeQRcodeId');

    // Dynamic sections checkboxes
    const noEducationCheckbox = document.getElementById('noEducationCheckbox');
    const noWorkExperienceCheckbox = document.getElementById('noWorkExperienceCheckbox');
    const noTrainingCheckbox = document.getElementById('noTrainingCheckbox');
    const noCertificatesCheckbox = document.getElementById('noCertificatesCheckbox');
    const noSkillsCheckbox = document.getElementById('noSkillsCheckbox');

    // Dynamic sections containers
    const educationContainer = document.getElementById('educationContainer');
    const workExperienceContainer = document.getElementById('workExperienceContainer');
    const trainingContainer = document.getElementById('trainingContainer');
    const certificatesContainer = document.getElementById('certificatesContainer');
    const skillsContainer = document.getElementById('skillsContainer');

    // Dynamic sections add buttons
    const addEducationBtn = document.getElementById('addEducationBtn');
    const addWorkExperienceBtn = document.getElementById('addWorkExperienceBtn');
    const addTrainingBtn = document.getElementById('addTrainingBtn');
    const addCertificateBtn = document.getElementById('addCertificateBtn');
    const addSkillBtn = document.getElementById('addSkillBtn');

    let educationCounter = 0;
    let workExperienceCounter = 0;
    let trainingCounter = 0;
    let certificatesCounter = 0;
    let skillsCounter = 0;

    const passwordFields = document.querySelectorAll('.password-fields');
    const oldPassword = document.getElementById('oldPassword');
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmNewPassword');
    const oldPassword2 = document.getElementById('oldPassword2');
    const newPassword2 = document.getElementById('newPassword2');
    const confirmPassword2 = document.getElementById('confirmNewPassword2');

    // Show/hide each password field based on match
    passwordFields.forEach(el => {
        el.style.display = (employeeId === empId) ? '' : 'none';
    });

    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', () => {
            const input = button.previousElementSibling;
            const icon = button.querySelector('i');
            const isPassword = input.type === 'password';
            input.type = isPassword ? 'text' : 'password';
            icon.classList.toggle('fa-eye');
            icon.classList.toggle('fa-eye-slash');
        });
    });

    if (updatePasswordBtn) {
        updatePasswordBtn.addEventListener('click', async () => {
            updatePasswordForm.reset();
            if (updatePasswordModal) {
                updatePasswordModal.classList.remove('d-none');
                const modalContentScrollable = updatePasswordModal.querySelector('.custom-modal-content');
                if (modalContentScrollable) modalContentScrollable.scrollTop = 0;
            } else {
                console.error('Error: updatePasswordModal element not found!');
                showAlertModal('Error', 'Password modal element is missing. Please check HTML.');
            }
        });
    }

    // Show Update Employee Modal
    if (updateEmployeeBtn) {
        updateEmployeeBtn.addEventListener('click', async () => {
            updateEmployeeForm.reset();
            employeeAgeInput.value = '';

            // Reset dynamic sections content
            if (educationContainer) educationContainer.innerHTML = '';
            if (workExperienceContainer) workExperienceContainer.innerHTML = '';
            if (trainingContainer) trainingContainer.innerHTML = '';
            if (certificatesContainer) certificatesContainer.innerHTML = '';
            if (skillsContainer) skillsContainer.innerHTML = '';

            educationCounter = 0;
            workExperienceCounter = 0;
            trainingCounter = 0;
            certificatesCounter = 0;
            skillsCounter = 0;

            // Ensure checkboxes are unchecked and sections are visible
            if (noEducationCheckbox) noEducationCheckbox.checked = false;
            if (noWorkExperienceCheckbox) noWorkExperienceCheckbox.checked = false;
            if (noTrainingCheckbox) noTrainingCheckbox.checked = false;
            if (noCertificatesCheckbox) noCertificatesCheckbox.checked = false;
            if (noSkillsCheckbox) noSkillsCheckbox.checked = false;

            // Call toggleDynamicSection for each, ensuring it handles nulls internally
            toggleDynamicSection('education', false);
            toggleDynamicSection('workExperience', false);
            toggleDynamicSection('training', false);
            toggleDynamicSection('certificates', false);
            toggleDynamicSection('skills', false);

            if (updateEmployeeModal) {
                updateEmployeeModal.classList.remove('d-none');
                const modalContentScrollable = updateEmployeeModal.querySelector('.custom-modal-content');
                if (modalContentScrollable) modalContentScrollable.scrollTop = 0;
            } else {
                console.error('Error: updateEmployeeModal element not found!');
                showAlertModal('Error', 'Employee modal element is missing. Please check HTML.');
            }

            try {
                const response = await fetch("get_employee_details.php");
                if (!response.ok) throw new Error("Failed to fetch employee details");
                const data = await response.json();

                // filter the employee by ID
                const emp = data.employees.find(e => e.id == employeeId);
                if (!emp) throw new Error("Employee not found");

                if (employeePositionn) {
                    employeePositionn.value = emp.position || "";

                    // Make readonly if employee's position is "Human Resources"
                    if (emp.position && emp.position.toLowerCase() === 'human resources') {
                        employeePositionn.readOnly = true;
                    } else {
                        employeePositionn.readOnly = false;
                    }
                }

                // Fill static input fields
                if (employeeFullName) employeeFullName.value = emp.full_name || "";
                if (employeeWorkEmailInput) employeeWorkEmailInput.value = emp.work_email || "";
                if (employeeContactInput) employeeContactInput.value = emp.contact_number || "";
                if (employeeAddress) employeeAddress.value = emp.address || "";
                if (employeeBirthdayInput) employeeBirthdayInput.value = emp.birthday || "";
                if (employeeAgeInput) employeeAgeInput.value = emp.age || "";
                if (employeeSex) employeeSex.value = emp.sex || "";
                if (employeeCivilStatus) employeeCivilStatus.value = emp.civil_status || "";
                if (employeeBranch) employeeBranch.value = emp.branch || "";
                if (employeePositionn) employeePositionn.value = emp.position || "";
                if (employeeDateJoinedInput) employeeDateJoinedInput.value = emp.date_joined || "";
                if (employeeMonthlySalary) employeeMonthlySalary.value = emp.monthly_salary || "";
                if (employeeSSSContribution) employeeSSSContribution.value = emp.sss_contribution || "";
                if (employeeHDMFContribution) employeeHDMFContribution.value = emp.hdmf_contribution || "";
                if (employeePHICContribution) employeePHICContribution.value = emp.phic_contribution || "";
                if (employeeShiftStartInput) employeeShiftStartInput.value = emp.work_shift_start || "";
                if (employeeShiftEndInput) employeeShiftEndInput.value = emp.work_shift_end || "";
                if (employeeRestDay) employeeRestDay.value = emp.rest_day || "";
                if (employeeQRcodeIdInput) employeeQRcodeIdInput.value = emp.qrcode_id || "";

                // Fill dynamic sections safely (if null, skip)
                if (Array.isArray(emp.education)) {
                    emp.education.forEach(edu => {
                        const newField = createEducationField(educationCounter++);
                        if (educationContainer) {
                            educationContainer.appendChild(newField);
                            newField.querySelector(`[name$="[school]"]`).value = edu.school || "";
                            newField.querySelector(`[name$="[academic_year]"]`).value = edu.academic_year || "";
                            newField.querySelector(`[name$="[course_strand]"]`).value = edu.course_strand || "";
                            newField.querySelector(`[name$="[special_notes]"]`).value = edu.special_notes || "";

                            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);

                            const idInput = document.createElement('input');
                            idInput.type = 'hidden';
                            idInput.name = `education[${educationCounter-1}][id]`;
                            idInput.value = edu.id; // <-- this is the DB id
                            newField.appendChild(idInput);
                        }
                    });
                }

                if (Array.isArray(emp.work_experience)) {
                    emp.work_experience.forEach(work => {
                        const newField = createWorkExperienceField(workExperienceCounter++);
                        if (workExperienceContainer) {
                            workExperienceContainer.appendChild(newField);
                            newField.querySelector(`[name$="[company]"]`).value = work.company || "";
                            newField.querySelector(`[name$="[length_of_service]"]`).value = work.length_of_service || "";
                            newField.querySelector(`[name$="[position]"]`).value = work.position || "";
                            newField.querySelector(`[name$="[duties_achievements]"]`).value = work.duties_achievements || "";

                            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);

                            const idInput = document.createElement('input');
                            idInput.type = 'hidden';
                            idInput.name = `work_experience[${workExperienceCounter-1}][id]`;
                            idInput.value = work.id; // <-- this is the DB id
                            newField.appendChild(idInput);
                        }
                    });
                }

                if (Array.isArray(emp.trainings)) {
                    emp.trainings.forEach(training => {
                        const newField = createTrainingField(trainingCounter++);
                        if (trainingContainer) {
                            trainingContainer.appendChild(newField);
                            newField.querySelector(`[name$="[training_name]"]`).value = training.training_name || "";
                            newField.querySelector(`[name$="[date_attended]"]`).value = training.date_attended || "";
                            newField.querySelector(`[name$="[notes]"]`).value = training.notes || "";

                            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);

                            const idInput = document.createElement('input');
                            idInput.type = 'hidden';
                            idInput.name = `trainings[${trainingCounter-1}][id]`;
                            idInput.value = training.id; // <-- this is the DB id
                            newField.appendChild(idInput);
                        }
                    });
                }

                if (Array.isArray(emp.certificates)) {
                    emp.certificates.forEach(cert => {
                        const newField = createCertificateField(certificatesCounter++);
                        if (certificatesContainer) {
                            certificatesContainer.appendChild(newField);
                            newField.querySelector(`[name$="[certificate_name]"]`).value = cert.certificate_name || "";
                            newField.querySelector(`[name$="[issuing_body]"]`).value = cert.issuing_body || "";
                            newField.querySelector(`[name$="[date_issued]"]`).value = cert.date_issued || "";

                            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);

                            const idInput = document.createElement('input');
                            idInput.type = 'hidden';
                            idInput.name = `certificates[${certificatesCounter-1}][id]`;
                            idInput.value = cert.id; // <-- this is the DB id
                            newField.appendChild(idInput);
                        }
                    });
                }

                if (Array.isArray(emp.skills)) {
                    emp.skills.forEach(skill => {
                        const newField = createSkillField(skillsCounter++);
                        if (skillsContainer) {
                            skillsContainer.appendChild(newField);
                            newField.querySelector(`[name$="[skill_name]"]`).value = skill.skill_name || "";

                            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);

                            const idInput = document.createElement('input');
                            idInput.type = 'hidden';
                            idInput.name = `skills[${skillsCounter-1}][id]`;
                            idInput.value = skill.id; // <-- this is the DB id
                            newField.appendChild(idInput);
                        }
                    });
                }
            } catch (err) {
                console.error("Error loading employee details:", err);
                showAlertModal('Error', 'Failed to load employee details. Please try again.');
            }
            checker();
        });
    }

    function checkPasswordMatch() {
        const newVal = newPassword.value.trim();
        const confirmVal = confirmPassword.value.trim();
        if (newVal === '' || confirmVal === '') {
            // Reset to original
            newPassword.style.borderColor = '';
            confirmPassword.style.borderColor = '';
            newPassword.style.boxShadow = '';
            confirmPassword.style.boxShadow = '';
        } else if (newVal === confirmVal) {
            newPassword.style.borderColor = 'rgb(8, 195, 33)';
            confirmPassword.style.borderColor = 'rgb(8, 195, 33)';
            newPassword.style.boxShadow = '0 0 0 0.25rem rgba(22, 202, 22, 0.57)';
            confirmPassword.style.boxShadow = '0 0 0 0.25rem rgba(22, 202, 22, 0.57)';
        } else {
            newPassword.style.borderColor = 'rgb(231, 10, 10)';
            confirmPassword.style.borderColor = 'rgb(231, 10, 10)';
            newPassword.style.boxShadow = '0 0 0 0.25rem rgba(240, 0, 0, 0.47)';
            confirmPassword.style.boxShadow = '0 0 0 0.25rem rgba(240, 0, 0, 0.47)';
        }
    }

    const strengthFill = document.querySelector('.strength-fill');
    const strengthText = document.querySelector('.strength-text');

    function checkPasswordStrength() {
        const val = newPassword.value.trim();
        let strength = 0;

        if (val.length >= 12) strength++;             // minimum length
        if (/[a-z]/.test(val)) strength++;            // lowercase
        if (/[A-Z]/.test(val)) strength++;            // uppercase
        if (/[0-9]/.test(val)) strength++;            // number
        if (/[\W]/.test(val)) strength++;             // special char

        if (val.length === 0) {
        // Reset to initial state
            strengthFill.style.width = '0%';
            strengthFill.style.backgroundColor = 'red'; // keep red or original
            strengthText.textContent = '';
            strengthText.style.color = 'text-muted'; // or 'inherit'
        } else {
            // Update bar and text
            switch(strength) {
                case 0:
                case 1:
                case 2:
                case 3:
                    strengthFill.style.width = '33%';
                    strengthFill.style.backgroundColor = 'red';
                    strengthText.textContent = 'Weak';
                    strengthText.style.color = 'red';
                    break;
                case 4:
                    strengthFill.style.width = '66%';
                    strengthFill.style.backgroundColor = 'orange';
                    strengthText.textContent = 'Medium';
                    strengthText.style.color = 'orange';
                    break;
                case 5:
                    strengthFill.style.width = '100%';
                    strengthFill.style.backgroundColor = 'green';
                    strengthText.textContent = 'Strong';
                    strengthText.style.color = 'green';
                    break;
            }
        }
        return strength;
    }

    newPassword.addEventListener('input', () => {
        checkPasswordStrength();
        checkPasswordMatch(); // keep your confirm match check working
    });
    confirmPassword.addEventListener('input', checkPasswordMatch);

    function checkPasswordMatch2() {
        const newVal = newPassword2.value.trim();
        const confirmVal = confirmPassword2.value.trim();
        if (newVal === '' || confirmVal === '') {
            // Reset to original
            newPassword2.style.borderColor = '';
            confirmPassword2.style.borderColor = '';
            newPassword2.style.boxShadow = '';
            confirmPassword2.style.boxShadow = '';
        } else if (newVal === confirmVal) {
            newPassword2.style.borderColor = 'rgb(8, 195, 33)';
            confirmPassword2.style.borderColor = 'rgb(8, 195, 33)';
            newPassword2.style.boxShadow = '0 0 0 0.25rem rgba(22, 202, 22, 0.57)';
            confirmPassword2.style.boxShadow = '0 0 0 0.25rem rgba(22, 202, 22, 0.57)';
        } else {
            newPassword2.style.borderColor = 'rgb(231, 10, 10)';
            confirmPassword2.style.borderColor = 'rgb(231, 10, 10)';
            newPassword2.style.boxShadow = '0 0 0 0.25rem rgba(240, 0, 0, 0.47)';
            confirmPassword2.style.boxShadow = '0 0 0 0.25rem rgba(240, 0, 0, 0.47)';
        }
    }

    const strengthFill2 = document.querySelector('.forPassFill');
    const strengthText2 = document.querySelector('.forPassText');

    function checkPasswordStrength2() {
        const val = newPassword2.value.trim();
        let strength2 = 0;

        if (val.length >= 12) strength2++;             // minimum length
        if (/[a-z]/.test(val)) strength2++;            // lowercase
        if (/[A-Z]/.test(val)) strength2++;            // uppercase
        if (/[0-9]/.test(val)) strength2++;            // number
        if (/[\W]/.test(val)) strength2++;             // special char

        if (val.length === 0) {
        // Reset to initial state
            strengthFill2.style.width = '0%';
            strengthFill2.style.backgroundColor = 'red'; // keep red or original
            strengthText2.textContent = '';
            strengthText2.style.color = 'text-muted'; // or 'inherit'
        } else {
            // Update bar and text
            switch(strength2) {
                case 0:
                case 1:
                case 2:
                case 3:
                    strengthFill2.style.width = '33%';
                    strengthFill2.style.backgroundColor = 'red';
                    strengthText2.textContent = 'Weak';
                    strengthText2.style.color = 'red';
                    break;
                case 4:
                    strengthFill2.style.width = '66%';
                    strengthFill2.style.backgroundColor = 'orange';
                    strengthText2.textContent = 'Medium';
                    strengthText2.style.color = 'orange';
                    break;
                case 5:
                    strengthFill2.style.width = '100%';
                    strengthFill2.style.backgroundColor = 'green';
                    strengthText2.textContent = 'Strong';
                    strengthText2.style.color = 'green';
                    break;
            }
        }
        return strength2;
    }

    newPassword2.addEventListener('input', () => {
        checkPasswordStrength2();
        checkPasswordMatch2(); // keep your confirm match check working
    });
    confirmPassword2.addEventListener('input', checkPasswordMatch2);

    // Hide Update Employee Modal
    if (cancelUpdateEmployeeBtn) {
        cancelUpdateEmployeeBtn.addEventListener('click', () => {
            if (updateEmployeeModal) {
                newPassword.style.borderColor = '';
                confirmPassword.style.borderColor = '';
                newPassword.style.boxShadow = '';
                confirmPassword.style.boxShadow = '';
                strengthFill.style.width = '0%';
                strengthFill.style.backgroundColor = 'red';
                strengthText.textContent = '';
                strengthText.style.color = 'text-muted';
                updateEmployeeModal.classList.add('d-none');
                updateEmployeeForm.reset();
            }
        });
    }

    if (cancelUpdatePasswordBtn) {
        cancelUpdatePasswordBtn.addEventListener('click', () => {
            if (updatePasswordModal) {
                newPassword2.style.borderColor = '';
                    confirmPassword2.style.borderColor = '';
                    newPassword2.style.boxShadow = '';
                    confirmPassword2.style.boxShadow = '';
                    strengthFill2.style.width = '0%';
                    strengthFill2.style.backgroundColor = 'red';
                    strengthText2.textContent = '';
                    strengthText2.style.color = 'text-muted';
                    updatePasswordModal.classList.add('d-none');
                    updatePasswordForm.reset();
            }
        });
    }

    function checker() {
        // Function to calculate age from birthday
        if (employeeBirthdayInput && employeeAgeInput) { // Ensure both elements exist
            employeeBirthdayInput.addEventListener('change', function() {
                const birthday = new Date(this.value);
                if (isNaN(birthday.getTime())) { // Use getTime() for robust NaN check
                    employeeAgeInput.value = '';
                    return;
                }
                const today = new Date();
                let age = today.getFullYear() - birthday.getFullYear();
                const m = today.getMonth() - birthday.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthday.getDate())) {
                    age--;
                }

                if (age < 18) {
                    showAlertModal('Age Restriction', 'Employee must be at least 18 years old.');
                    employeeAgeInput.value = '';
                    employeeBirthdayInput.value = ''; // Clear birthday as well
                } else {
                    employeeAgeInput.value = age >= 0 ? age : ''; // Ensure age is not negative
                }
            });
        }

        // Real-time Shift Time Validation
        if (employeeShiftStartInput && employeeShiftEndInput) {
            const validateShiftTimes = () => {
                const startTime = employeeShiftStartInput.value;
                const endTime = employeeShiftEndInput.value;

                if (startTime && endTime) { // Only validate if both are filled
                    const startDateTime = new Date(`2000/01/01 ${startTime}`);
                    const endDateTime = new Date(`2000/01/01 ${endTime}`);

                    if (endDateTime <= startDateTime) {
                        showAlertModal('Invalid Shift Times', 'End shift time cannot be earlier than or the same as the start shift time.');
                        employeeShiftEndInput.value = ''; // Clear end time
                        employeeShiftEndInput.focus();
                        return false;
                    }
                }
                return true;
            };

            employeeShiftStartInput.addEventListener('change', validateShiftTimes);
            employeeShiftEndInput.addEventListener('change', validateShiftTimes);
        }

        // Real-time Date Joined Validation
        if (employeeDateJoinedInput) {
            employeeDateJoinedInput.addEventListener('change', function() {
                if (!isDateNotInFuture(this.value, 'Date Joined')) {
                    this.value = ''; // Clear the input if it's a future date
                }
            });
        }
    }

    // Function to validate Philippine mobile contact number (09xxxxxxxxx format)
    function isValidPhilippineContact(number) {
        const mobileRegex = /^09\d{9}$/; // Starts with 09, followed by 9 digits
        return mobileRegex.test(number);
    }

    // Helper function to check if a date is not in the future
    function isDateNotInFuture(dateString, fieldLabel) {
        if (!dateString) return true; // Allow empty date if not required, validation handles required
        const inputDate = new Date(dateString);
        const today = new Date();

        if (inputDate > today) {
            showAlertModal('Invalid Date', `${fieldLabel} cannot be a future date.`);
            return false;
        }
        return true;
    }

    // Helper function to toggle visibility and required status of dynamic sections
    function toggleDynamicSection(sectionName, hide) {
        const container = document.getElementById(`${sectionName}Container`);
        const addButtonId = `add${sectionName.charAt(0).toUpperCase() + sectionName.slice(1)}Btn`;
        const addButton = document.getElementById(addButtonId);

        if (hide) {
            if (container) container.classList.add('d-none');
            if (addButton) addButton.disabled = true; // Disable add button
            // Remove required attribute from all inputs in this section
            if (container) {
                container.querySelectorAll('input, select, textarea').forEach(input => {
                    input.removeAttribute('required');
                });
            }
        } else {
            if (container) container.classList.remove('d-none');
            if (addButton) addButton.disabled = false; // Enable add button
            // Required attributes will be added when fields are dynamically created
        }
    }

    // Helper function to validate if a dynamic section has at least one filled required field
    function validateDynamicSection(containerId, checkboxId, fieldNames) {
        const checkbox = document.getElementById(checkboxId);
        const container = document.getElementById(containerId);
        const sectionNameMap = {
        'education': 'educational background',
        'workExperience': 'work experience',
        'training': 'training/seminar/workshop',
        'certificates': 'certificate',
        'skills': 'skill'
        };
        const rawSectionName = containerId.replace('Container', '');
        const formattedSectionName = sectionNameMap[rawSectionName] || rawSectionName.replace(/([A-Z])/g, ' $1').toLowerCase();

        if (checkbox && !checkbox.checked && container && container.children.length === 0) {
            showAlertModal('Missing Information', `Please add at least one entry for ${formattedSectionName} or tick the 'No ${formattedSectionName} to add' checkbox.`);
            return false;
        }

        // If checkbox is ticked and no children, or checkbox is not ticked and children exist, proceed to field validation
        if (checkbox && checkbox.checked) {
            return true; // Checkbox is ticked and no entries, or entries were cleared - valid for this scenario
        }

        // If checkbox is NOT ticked, then we expect fields to be present and filled
        let allFieldsValid = true;
        Array.from(container.children).forEach(card => {
            fieldNames.forEach(field => {
                const input = card.querySelector(`[name$="[${field}]"]`);
                if (input && input.hasAttribute('required') && !input.value.trim()) {
                    allFieldsValid = false;
                    input.focus();
                }
            });
        });

        if (!allFieldsValid) {
            showAlertModal('Missing Information', `Please fill in all required fields in the ${formattedSectionName} section.`);
            return false;
        }
        return true;
    }

    // Template for Education Section
    function createEducationField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="education" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-6">
                    <label for="educationSchool${index}" class="form-label text-text-dark-grey fw-medium">School <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="educationSchool${index}" name="education[${index}][school]" required>
                </div>
                <div class="col-md-6">
                    <label for="educationAcademicYear${index}" class="form-label text-text-dark-grey fw-medium">Academic Year <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="educationAcademicYear${index}" name="education[${index}][academic_year]" placeholder="e.g., 2018-2022" required>
                </div>
                <div class="col-12">
                    <label for="educationCourseStrand${index}" class="form-label text-text-dark-grey fw-medium">Course/Strand <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="educationCourseStrand${index}" name="education[${index}][course_strand]" placeholder="If junior high school, put N/A" required>
                </div>
                <div class="col-12">
                    <label for="educationNotes${index}" class="form-label text-text-dark-grey fw-medium">Special notes (e.g., major, minor, awards)</label>
                    <textarea class="form-control" id="educationNotes${index}" name="education[${index}][special_notes]" rows="2"></textarea>
                </div>
            </div>
        `;
        return div;
    }

    // Template for Work Experience Section
    function createWorkExperienceField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="workExperience" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-6">
                    <label for="workExpCompany${index}" class="form-label text-text-dark-grey fw-medium">Company <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="workExpCompany${index}" name="work_experience[${index}][company]" required>
                </div>
                <div class="col-md-6">
                    <label for="workExpLength${index}" class="form-label text-text-dark-grey fw-medium">Length of Service <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="workExpLength${index}" name="work_experience[${index}][length_of_service]" placeholder="e.g., 2012-2016" required>
                </div>
                <div class="col-12">
                    <label for="workExpPosition${index}" class="form-label text-text-dark-grey fw-medium">Position <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="workExpPosition${index}" name="work_experience[${index}][position]" required>
                </div>
                <div class="col-12">
                    <label for="workExpDuties${index}" class="form-label text-text-dark-grey fw-medium">Duties & Notable Achievements</label>
                    <textarea class="form-control" id="workExpDuties${index}" name="work_experience[${index}][duties_achievements]" rows="3"></textarea>
                </div>
            </div>
        `;
        return div;
    }

    // Template for Training Section
    function createTrainingField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="training" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-8">
                    <label for="trainingName${index}" class="form-label text-text-dark-grey fw-medium">Training Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="trainingName${index}" name="training[${index}][training_name]" required>
                </div>
                <div class="col-md-4">
                    <label for="trainingDate${index}" class="form-label text-text-dark-grey fw-medium">Date Attended <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="trainingDate${index}" name="training[${index}][date_attended]" required>
                </div>
                <div class="col-12">
                    <label for="trainingNotes${index}" class="form-label text-text-dark-grey fw-medium">Notes</label>
                    <textarea class="form-control" id="trainingNotes${index}" name="training[${index}][notes]" rows="2"></textarea>
                </div>
            </div>
        `;
        setTimeout(() => { // Use a small timeout to ensure the element is in the DOM
            const trainingDateInput = div.querySelector(`#trainingDate${index}`);
            if (trainingDateInput) {
                trainingDateInput.addEventListener('change', function() {
                    if (!isDateNotInFuture(this.value, 'Date Attended')) {
                        this.value = ''; // Clear the input if it's a future date
                    }
                });
            }
        }, 0);
        return div;
    }

    // Template for Certificates Section
    function createCertificateField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="certificates" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-8">
                    <label for="certificateName${index}" class="form-label text-text-dark-grey fw-medium">Certificate Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="certificateName${index}" name="certificates[${index}][certificate_name]" required>
                </div>
                <div class="col-md-4">
                    <label for="certificateDate${index}" class="form-label text-text-dark-grey fw-medium">Date Issued <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="certificateDate${index}" name="certificates[${index}][date_issued]" required>
                </div>
                <div class="col-12">
                    <label for="certificateIssuingBody${index}" class="form-label text-text-dark-grey fw-medium">Issuing Body</label>
                    <input type="text" class="form-control" id="certificateIssuingBody${index}" name="certificates[${index}][issuing_body]">
                </div>
            </div>
        `;
        setTimeout(() => { // Use a small timeout to ensure the element is in the DOM
            const certificateDateInput = div.querySelector(`#certificateDate${index}`);
            if (certificateDateInput) {
                certificateDateInput.addEventListener('change', function() {
                    if (!isDateNotInFuture(this.value, 'Date Issued')) {
                        this.value = ''; // Clear the input if it's a future date
                    }
                });
            }
        }, 0);
        return div;
    }

    // Template for Skills Section
    function createSkillField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="skills" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-12"> <!-- Changed to col-12 as only one field now -->
                    <label for="skillName${index}" class="form-label text-text-dark-grey fw-medium">Skill Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="skillName${index}" name="skills[${index}][skill_name]" required>
                </div>
            </div>
        `;
        return div;
    }

    // Event listeners for Add buttons
    if (addEducationBtn) {
        addEducationBtn.addEventListener('click', () => {
            const newField = createEducationField(educationCounter++);
            if (educationContainer) educationContainer.appendChild(newField);
            // Add event listener for the new remove button
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addWorkExperienceBtn) {
        addWorkExperienceBtn.addEventListener('click', () => {
            const newField = createWorkExperienceField(workExperienceCounter++);
            if (workExperienceContainer) workExperienceContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addTrainingBtn) {
        addTrainingBtn.addEventListener('click', () => {
            const newField = createTrainingField(trainingCounter++);
            if (trainingContainer) trainingContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addCertificateBtn) {
        addCertificateBtn.addEventListener('click', () => {
            const newField = createCertificateField(certificatesCounter++);
            if (certificatesContainer) certificatesContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addSkillBtn) {
        addSkillBtn.addEventListener('click', () => {
            const newField = createSkillField(skillsCounter++);
            if (skillsContainer) skillsContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }

    // Track deleted section IDs
    function removeDynamicSection(event) {
        const button = event.currentTarget;
        const sectionCard = button.closest('.card');
        const hiddenIdInput = sectionCard.querySelector('input[type="hidden"][name$="[id]"]');
        const deletedIdsInput = document.getElementById('deleted_ids');

        // Only track deletion if record has an existing DB id
        if (hiddenIdInput && hiddenIdInput.value) {
            const deletedId = hiddenIdInput.value.trim();
            if (deletedId) {
                let currentIds = deletedIdsInput.value ? deletedIdsInput.value.split(',') : [];
                if (!currentIds.includes(deletedId)) currentIds.push(deletedId);
                deletedIdsInput.value = currentIds.join(',');
            }
        }

        // Remove card from UI
        sectionCard.remove();
    }

    const sections = [
        { addBtn: addEducationBtn, checkbox: noEducationCheckbox, container: educationContainer, counter: 'educationCounter' },
        { addBtn: addWorkExperienceBtn, checkbox: noWorkExperienceCheckbox, container: workExperienceContainer, counter: 'workExperienceCounter' },
        { addBtn: addTrainingBtn, checkbox: noTrainingCheckbox, container: trainingContainer, counter: 'trainingCounter' },
        { addBtn: addCertificateBtn, checkbox: noCertificatesCheckbox, container: certificatesContainer, counter: 'certificatesCounter' },
        { addBtn: addSkillBtn, checkbox: noSkillsCheckbox, container: skillsContainer, counter: 'skillsCounter' }
    ];

    // Attach behavior for all sections
    sections.forEach(({ addBtn, checkbox, container, counter }) => {
        if (!addBtn || !checkbox || !container) return;

        // When Add button clicked → uncheck checkbox and show container
        addBtn.addEventListener('click', () => {
            checkbox.checked = false;
            container.classList.remove('d-none');
        });

        // When checkbox toggled → hide/reset container
        checkbox.addEventListener('change', () => {
            if (checkbox.checked) {
                container.classList.add('d-none');
                container.innerHTML = '';
                checkbox.closest('.form-check').style.marginBottom = '8px';
                window[counter] = 0; // reset counter dynamically
            } 
        });
    });

    const email = localStorage.getItem('userEmail');
    if (updatePasswordForm) {
        updatePasswordForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            if (newPassword2.value.trim() !== confirmPassword2.value.trim()) {
                showAlertModal('Unmatched New Passwords', 'New Password and Confirm New Password does not match.');
                confirmPassword2.focus();
                return;
            }

            const strength2 = checkPasswordStrength2();
            if (strength2 < 5) { // less than Strong
                showAlertModal('Insecure New Password', 'New Password must be strong.');
                newPassword2.focus();
                return;
            }

            const formData = new FormData(updatePasswordForm);
            formData.append('email', email);
            try {
                // Disable button and show spinner
                const submitBtn = document.getElementById('submitUpdatePasswordBtn');
                if (submitBtn) {
                    submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...`;
                    submitBtn.disabled = true;
                }

                const response = await fetch('get_update_owner.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    const successMessage = `Password has been successfully updated!`
                    showAlertModal('Password Updated Successfully', successMessage);
                    newPassword2.style.borderColor = '';
                    confirmPassword2.style.borderColor = '';
                    newPassword2.style.boxShadow = '';
                    confirmPassword2.style.boxShadow = '';
                    strengthFill2.style.width = '0%';
                    strengthFill2.style.backgroundColor = 'red';
                    strengthText2.textContent = '';
                    strengthText2.style.color = 'text-muted';
                    if (updatePasswordModal) {
                        updatePasswordModal.classList.add('d-none'); // Hide modal
                    }
                    updatePasswordForm.reset(); // Clear form
                    initializeProfile();
                } else {
                    if (result.message && result.message.includes('Old Password is incorrect')) {
                        showAlertModal('Invalid Action', 'Old Password is incorrect.');
                    } else {
                        // For other errors, show a generic failure message
                        console.error(result.message);
                    }
                }
            } catch (error) {
                console.error('Error updating password:', error);
                showAlertModal('Error', 'An error occurred while updating password.');
            } finally {
                // Re-enable button
                const submitBtn = document.getElementById('submitUpdatePasswordBtn');
                if (submitBtn) {
                    submitBtn.innerHTML = `Update`;
                    submitBtn.disabled = false;
                }
            }
        });
    }

    // Handle Update Employee Form Submission
    if (updateEmployeeForm) {
        updateEmployeeForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            // Client-side validation for required fields
            const requiredInputs = updateEmployeeForm.querySelectorAll('[required]');
            for (const input of requiredInputs) {
                // Check if the input is visible (not part of a hidden dynamic section)
                if (input.offsetParent !== null && !input.value) { // offsetParent checks visibility
                    showAlertModal('Missing Information', `Please fill in the required field: ${input.previousElementSibling?.textContent?.replace(' *', '') || input.id}`); // Added optional chaining for textContent
                    input.focus();
                    return;
                }
            }

            if ((oldPassword.value && !newPassword.value) || (!oldPassword.value && newPassword.value)) {
                showAlertModal('Invalid Action', 'Please fill in both Old Password and New Password fields to change your password.');
                newPassword.focus();
                return;
            }

            if (newPassword.value.trim() !== confirmPassword.value.trim()) {
                showAlertModal('Unmatched New Passwords', 'New Password and Confirm New Password does not match.');
                confirmPassword.focus();
                return;
            }

            const strength = checkPasswordStrength();
            if (strength && strength < 5) { // less than Strong
                showAlertModal('Insecure New Password', 'New Password must be strong.');
                newPassword.focus();
                return;
            }

            if (employeeContactInput && !isValidPhilippineContact(employeeContactInput.value.trim())) {
                showAlertModal('Invalid Contact Number', 'Please enter a valid Philippine mobile (e.g., 09xxxxxxxxx) number.');
                employeeContactInput.focus();
                return; // Stop form submission
            }

            if (!validateDynamicSection('educationContainer', 'noEducationCheckbox', ['school', 'academic_year', 'course_strand'])) return;
            if (!validateDynamicSection('workExperienceContainer', 'noWorkExperienceCheckbox', ['company', 'length_of_service', 'position'])) return;
            if (!validateDynamicSection('trainingContainer', 'noTrainingCheckbox', ['training_name'])) return;
            if (!validateDynamicSection('certificatesContainer', 'noCertificatesCheckbox', ['certificate_name'])) return;
            if (!validateDynamicSection('skillsContainer', 'noSkillsCheckbox', ['skill_name'])) return;

            const formData = new FormData(updateEmployeeForm);
            const collectDynamicData = (containerId, fieldNames) => {
                const container = document.getElementById(containerId);
                const items = [];
                // Only collect if the container is visible (not hidden by checkbox)
                if (container && container.offsetParent !== null) { // Check if container exists and is visible
                    Array.from(container.children).forEach(card => {
                        const item = {};
                        let isValid = true; // Assume valid until a required sub-field is empty
                        // Inside collectDynamicData function, within the fieldNames.forEach loop:
                        fieldNames.forEach(field => {
                            const input = card.querySelector(`[name$="[${field}]"]`);
                            if (input) {
                                // If a sub-field is marked required and is empty, invalidate the item
                                if (input.hasAttribute('required') && !input.value.trim()) { // Changed !input.value to !input.value.trim() for robust check
                                    isValid = false;
                                }
                                if (input.type === 'date' && !isDateNotInFuture(input.value, input.previousElementSibling?.textContent?.replace(' *', '') || input.id)) {
                                    isValid = false; // Mark the card as invalid if date is in future
                                    input.focus(); // Focus on the problematic input
                                }
                                item[field] = input.value.trim(); // Trim whitespace
                            }
                        });

                        const idInput = card.querySelector(`input[type="hidden"][name$="[id]"]`);
                        if (idInput) item.id = idInput.value;
                        if (isValid) {
                            items.push(item);
                        }
                    });
                }
                return items;
            };

            // Collect data for each dynamic section if not unchecked
            if (noEducationCheckbox && !noEducationCheckbox.checked) {
                const educationData = collectDynamicData('educationContainer', ['school', 'academic_year', 'course_strand', 'special_notes']);
                if (educationData.length > 0) formData.append('education_data', JSON.stringify(educationData));
            }
            if (noWorkExperienceCheckbox && !noWorkExperienceCheckbox.checked) {
                const workExperienceData = collectDynamicData('workExperienceContainer', ['company', 'length_of_service', 'position', 'duties_achievements']);
                if (workExperienceData.length > 0) formData.append('work_experience_data', JSON.stringify(workExperienceData));
            }
            if (noTrainingCheckbox && !noTrainingCheckbox.checked) {
                const trainingData = collectDynamicData('trainingContainer', ['training_name', 'date_attended', 'notes']);
                if (trainingData.length > 0) formData.append('training_data', JSON.stringify(trainingData));
            }
            if (noCertificatesCheckbox && !noCertificatesCheckbox.checked) {
                const certificatesData = collectDynamicData('certificatesContainer', ['certificate_name', 'issuing_body', 'date_issued']);
                if (certificatesData.length > 0) formData.append('certificates_data', JSON.stringify(certificatesData));
            }
            if (noSkillsCheckbox && !noSkillsCheckbox.checked) {
                const skillsData = collectDynamicData('skillsContainer', ['skill_name']);
                if (skillsData.length > 0) formData.append('skills_data', JSON.stringify(skillsData));
            }

            formData.append('id', employeeId);
            formData.append('action', 'update_info');
            try {
                // Disable button and show spinner
                const submitBtn = document.getElementById('submitUpdateEmployeeBtn');
                if (submitBtn) {
                    submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...`;
                    submitBtn.disabled = true;
                }

                const response = await fetch('update_employee.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    const successMessage = `Profile has been successfully updated!`
                    showAlertModal('Profile Updated Successfully', successMessage);
                    newPassword.style.borderColor = '';
                    confirmPassword.style.borderColor = '';
                    newPassword.style.boxShadow = '';
                    confirmPassword.style.boxShadow = '';
                    strengthFill.style.width = '0%';
                    strengthFill.style.backgroundColor = 'red';
                    strengthText.textContent = '';
                    strengthText.style.color = 'text-muted';
                    if (updateEmployeeModal) {
                        updateEmployeeModal.classList.add('d-none'); // Hide modal
                    }
                    updateEmployeeForm.reset(); // Clear form
                    initializeProfile();
                } else {
                    if (result.message && result.message.includes('Old Password is incorrect')) {
                        showAlertModal('Invalid Action', 'Old Password is incorrect.');
                    } else if (result.message && result.message.includes('Human Resources')) {
                        showAlertModal('Cannot Add HR', result.message);
                    } else {
                        // For other errors, show a generic failure message
                        console.error(result.message);
                    }
                }
            } catch (error) {
                console.error('Error updating profile:', error);
                showAlertModal('Error', 'An error occurred while updating profile.');
            } finally {
                // Re-enable button
                const submitBtn = document.getElementById('submitUpdateEmployeeBtn');
                if (submitBtn) {
                    submitBtn.innerHTML = `Update`;
                    submitBtn.disabled = false;
                }
            }
        });
    }
});
