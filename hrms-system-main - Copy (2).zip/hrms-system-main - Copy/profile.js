document.addEventListener('DOMContentLoaded', function() {
    window.initializeProfile = function() {
        const profilePictureInput = document.getElementById('profilePictureInput');
        const profilePicturePreview = document.getElementById('profilePicturePreview');
        const enrollFingerprintBtn = document.getElementById('enrollFingerprintBtn');
        const attendanceRecordsContainer = document.getElementById('attendanceRecordsContainer');
        const attendanceFilter = document.getElementById('attendanceFilter');
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const searchToggleIcon = document.getElementById("searchToggleIcon");
        const searchGroup = document.querySelector(".input-group.rounded-pill");
        const dashboardTitle = document.querySelector("h2.fw-bold.mb-0");
        const notificationBtn = document.querySelector(".fa-bell").closest("button");
        const profileDropdown = document.querySelector("#userDropdown").closest(".dropdown");
        const deactivateBtn = document.getElementById('deactivateBtn');
        const activateBtn = document.getElementById('activateBtn');
        const updateEmployeeBtn = document.getElementById('updateEmployeeBtn');
        const updatePasswordBtn = document.getElementById('updatePasswordBtn');
        document.addEventListener('click', (e) => {
            document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
                const inst = bootstrap.Tooltip.getInstance(el);
                if (inst) inst.hide();
            });
        });
        
        function setDeactivateButtonState() {
            if (!deactivateBtn) return;
            const existingTooltip = bootstrap.Tooltip.getInstance(deactivateBtn);
            if (existingTooltip) existingTooltip.dispose();
            if (window.innerWidth <= 995) {
                deactivateBtn.innerHTML = '<i class="fas fa-user-slash"></i>';
                deactivateBtn.classList.add('deactivate-button-circle', 'position-absolute');
                deactivateBtn.setAttribute('title', 'Deactivate');
                deactivateBtn.setAttribute('data-bs-toggle', 'tooltip');
                new bootstrap.Tooltip(deactivateBtn);
            } else {
                deactivateBtn.textContent = 'Deactivate';
                deactivateBtn.classList.remove('deactivate-button-circle', 'position-absolute');
                deactivateBtn.removeAttribute('title');
                deactivateBtn.removeAttribute('data-bs-toggle');
            }
        }

        function setActivateButtonState() {
            if (!activateBtn) return;
            const existingTooltip = bootstrap.Tooltip.getInstance(activateBtn);
            if (existingTooltip) existingTooltip.dispose();
            if (window.innerWidth <= 995) {
                activateBtn.innerHTML = '<i class="fas fa-user-check"></i>';
                activateBtn.classList.add('activate-button-circle', 'position-absolute');
                activateBtn.setAttribute('title', 'Activate');
                activateBtn.setAttribute('data-bs-toggle', 'tooltip');
                new bootstrap.Tooltip(activateBtn);
            } else {
                activateBtn.textContent = 'Activate';
                activateBtn.classList.remove('activate-button-circle', 'position-absolute');
                activateBtn.removeAttribute('title');
                activateBtn.removeAttribute('data-bs-toggle');
            }
        }

        // Function to set sidebar state based on screen width
        function setSidebarState() {
            if (window.innerWidth <= 995) { // iPad and smaller screens (Bootstrap's 'md' breakpoint and below)
                if (sidebar) sidebar.classList.add('collapsed'); // Always collapsed on these screens
            } else { // Larger screens
                if (sidebar) sidebar.classList.remove('collapsed'); // Always open on larger screens
            }
            setDeactivateButtonState();
            setActivateButtonState();
        }

         function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
        }

        // Event listener for desktop sidebar toggle
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', toggleSidebar);
        }

        // Call setSidebarState initially on load to set the correct state
        setSidebarState();
        window.addEventListener('resize', setSidebarState);

        const backButton = document.createElement("button");
        backButton.innerHTML = '<i class="fas fa-arrow-left fs-6"></i>';
        backButton.className = "btn btn-link text-text-dark-grey me-1 d-none";
        searchGroup.parentNode.insertBefore(backButton, searchGroup);

        function showSearch() {
            const headerParent = searchGroup.parentElement;
            headerParent.style.width = '100%';
            searchGroup.style.display = 'flex';
            searchGroup.style.flex = '1 1 auto';
            backButton.classList.remove('d-none');
            searchToggleIcon.classList.add('d-none');
            dashboardTitle.classList.add('d-none');
            notificationBtn.classList.add('d-none');
            profileDropdown.classList.add('d-none');
            }

        function hideSearch() {
            searchGroup.style.display = 'none';
            backButton.classList.add('d-none');
            searchToggleIcon.classList.remove('d-none');
            dashboardTitle.classList.remove('d-none');
            notificationBtn.classList.remove('d-none');
            profileDropdown.classList.remove('d-none');
            searchGroup.style.width = '380px';
            const headerParent = searchGroup.parentElement;
            headerParent.style.width = '';
        }

        searchToggleIcon.addEventListener("click", showSearch);
        backButton.addEventListener("click", hideSearch);

        // Handle resize
        window.addEventListener("resize", () => {
        if (window.innerWidth > 960) {
            searchGroup.style.display = 'flex';
            searchToggleIcon.classList.add("d-none");
            backButton.classList.add("d-none");
            dashboardTitle.classList.remove("d-none");
            notificationBtn.classList.remove("d-none");
            profileDropdown.classList.remove("d-none");
        } else {
            hideSearch();
        }
        });

        const navLinks = document.querySelectorAll('.sidebar .nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                if (href && href.startsWith('#')) {
                    e.preventDefault();

                    // Scroll to section
                    const target = document.querySelector(href);
                    if (target) {
                        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                }

                // Update active class
                navLinks.forEach(l => l.classList.remove('active-link'));
                this.classList.add('active-link');
            });
        });

        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        tooltipTriggerList.forEach(function (tooltipTriggerEl) {
            new bootstrap.Tooltip(tooltipTriggerEl)
        })

        const params = new URLSearchParams(window.location.search);
        const employeeId = params.get("employeeId");
        const accountStatus = params.get("status");
        const emailParam = params.get("email");

        if (accountStatus === 'active') {
            deactivateBtn.style.display = '';
            activateBtn.style.display = 'none';
        } else {
            deactivateBtn.style.display = 'none';
            activateBtn.style.display = '';
            activateBtn.style.position = window.getComputedStyle(deactivateBtn).position || 'absolute';
            activateBtn.style.top = deactivateBtn.style.top || window.getComputedStyle(deactivateBtn).top;
            activateBtn.style.right = deactivateBtn.style.right || window.getComputedStyle(deactivateBtn).right;
        }
        updateEmployeeBtn.style.display = (accountStatus === 'active') ? '' : 'none';

        const profilePictureOverlay = document.getElementById('profilePictureOverlay');
        const profilePictureEdit = document.getElementById('profilePictureEdit');
        const personalTab = document.getElementById('personalTab');
        const attendanceTab = document.getElementById('attendanceTab');
        const payrollTab = document.getElementById('payrollTab');
        const benefitsTab = document.getElementById('benefitsTab');
        const accountInfoTab = document.getElementById('accountInfoTab');
        const personalSection = document.getElementById('personalSection');
        const educationSection = document.getElementById('educationSection');
        const workExperienceSection = document.getElementById('workExperienceSection');
        const trainingsSection = document.getElementById('trainingsSection');
        const certificatesSection = document.getElementById('certificatesSection');
        const skillsSection = document.getElementById('skillsSection');
        const accountInfoSection = document.getElementById('accountInfoSection');
        const tabs = {
            personalTab: document.getElementById('personalTab'),
            attendanceTab: document.getElementById('attendanceTab'),
            payrollTab: document.getElementById('payrollTab'),
            benefitsTab: document.getElementById('benefitsTab'),
            accountInfoTab: document.getElementById('accountInfoTab')
        };

        const sections = {
            personalSection: document.getElementById('personalSection'),
            educationSection: document.getElementById('educationSection'),
            workExperienceSection: document.getElementById('workExperienceSection'),
            trainingsSection: document.getElementById('trainingsSection'),
            certificatesSection: document.getElementById('certificatesSection'),
            skillsSection: document.getElementById('skillsSection'),
            accountInfoSection: document.getElementById('accountInfoSection')
        };

        // Helper function to show/hide multiple elements
        function setVisibility(elements, visible) {
            elements.forEach(el => {
                if (el) el.style.display = visible ? '' : 'none';
            });
        }

        // Logic
        if (emailParam && !employeeId && !accountStatus) {
            // Only show account info
            fetch(`get_update_owner.php?email=${encodeURIComponent(emailParam)}`)
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.owner.length > 0) {
                        const emp = data.owner[0];
                        const position = emp.position.trim().toLowerCase();

                        if (position === 'owner') {
                            setVisibility([
                                deactivateBtn, activateBtn, updateEmployeeBtn,
                                personalTab, attendanceTab, payrollTab, benefitsTab,
                                personalSection, educationSection, workExperienceSection,
                                trainingsSection, certificatesSection, skillsSection,
                                enrollFingerprintBtn, profilePictureEdit, profilePictureOverlay
                            ], false);

                            accountInfoTab.classList.remove('d-none');
                            accountInfoSection.classList.remove('d-none');

                            document.getElementById("ownerEmail").textContent = emp.email;
                            document.getElementById("ownerPosition").textContent = emp.position;
                        }
                    }
                })
                .catch(console.error);
        } else if (employeeId && accountStatus) {
            // Show all employee tabs and sections, hide account info
            setVisibility([tabs.personalTab, tabs.attendanceTab, tabs.payrollTab, tabs.benefitsTab,
                        sections.personalSection, sections.educationSection, sections.workExperienceSection,
                        sections.trainingsSection, sections.certificatesSection, sections.skillsSection], true);
            setVisibility([tabs.accountInfoTab, sections.accountInfoSection], false);

            // Set activate/deactivate button visibility
            if (accountStatus === 'active') {
                deactivateBtn.style.display = '';
                activateBtn.style.display = 'none';
            } else {
                deactivateBtn.style.display = 'none';
                activateBtn.style.display = '';
            }
        }

        if (profilePictureInput && profilePicturePreview) {
            profilePictureInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (!file) return;

                const formData = new FormData();
                formData.append('profile_picture', file);
                formData.append('id', employeeId);
                formData.append('action', 'upload_picture');

                fetch('update_employee.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.new_picture_path) {
                        profilePicturePreview.src = data.new_picture_path + '?' + new Date().getTime();
                    } else {
                        console.error(data.message);
                    }
                });

                const reader = new FileReader();
                reader.onload = function(e) {
                    profilePicturePreview.src = e.target.result;
                    profilePicturePreview.classList.remove('d-none');
                };
                reader.readAsDataURL(file);
            });
        }

        if (enrollFingerprintBtn) {
            enrollFingerprintBtn.addEventListener('click', function() {

                // Placeholder for the URL of your Arduino/server
                const arduinoUrl = "http://10.17.91.241/enroll_fingerprint";

                // Use the Fetch API to simulate sending a request
                fetch(arduinoUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ employee_id: employeeId }),
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json(); // Assuming the Arduino sends back a JSON response
                })
                .then(data => {
                    console.log('Fingerprint enrollment initiated successfully!', data);
                })
                .catch(error => {
                    console.error('Error initiating fingerprint enrollment:', error);
                    showAlertModal('Error', 'Error starting enrollment. Check the console for details.');
                });
            });
        }

        if (deactivateBtn) {
            deactivateBtn.addEventListener('click', function() {
                // 1️⃣ Get the fingerprint_id from your database first
                fetch(`get_fingerprint_id.php?employee_id=${employeeId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (!data.success) {
                            showAlertModal('Fetching Failed', 'Failed to get fingerprint ID from the database.');
                            return;
                        }

                        const fingerprintId = data.fingerprint_id;

                        if (fingerprintId === null) {
                            showAlertModal('Invalid Fingerprint ID', 'This employee has no fingerprint registered.');
                            return;
                        }

                        // 2️⃣ Send delete request to the ESP32
                        const espUrl = "http://172.20.10.2/delete_employee_fingerprint";

                        fetch(espUrl, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ fingerprint_id: fingerprintId })
                        })
                        .then(res => res.json())
                        .then(result => {
                            if (result.status === "deleted") {
                                showAlertModal('Deletion Successful', `Fingerprint ID ${fingerprintId} deleted successfully from ESP32.`);
                            } else {
                                showAlertModal('Deletion Failed', `Failed to delete fingerprint ID ${fingerprintId} from ESP32.`);
                            }
                        })
                        .catch(err => {
                            console.error("Error deleting fingerprint:", err);
                            showAlertModal('Error', 'Error connecting to ESP32.');
                        });
                    })
                    .catch(error => {
                        console.error("Error fetching fingerprint ID:", error);
                        showAlertModal('Error', 'Error retrieving fingerprint ID from database.');
                    });
            });
        }

        if (employeeId) {
            fetch("get_employee_details.php")
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const emp = data.employees.find(e => e.id == employeeId);
                        if (emp) {
                            // Top section
                            document.getElementById("employeeName").textContent = emp.full_name;
                            document.getElementById("employeePosition").textContent = emp.position;

                            // Profile picture
                            const photoEl = document.getElementById("profilePicturePreview");
                            if (emp.picture_file_path && emp.picture_file_path.trim() !== "") {
                                photoEl.src = emp.picture_file_path;
                            } else {
                                const names = emp.full_name.trim().split(" ");
                                let initials = names.length > 1
                                    ? names[0][0] + names[names.length - 1][0]
                                    : names[0][0];
                                initials = initials.toUpperCase();
                                photoEl.src = `https://placehold.co/150x150/FFAB91/ffffff?text=${initials}`;
                            }

                            // Personal info section
                            document.getElementById("fullName").textContent = emp.full_name;
                            document.getElementById("workEmail").textContent = emp.work_email;
                            document.getElementById("contactNumber").textContent = emp.contact_number;
                            document.getElementById("age").textContent = emp.age;
                            document.getElementById("sex").textContent = emp.sex;
                            document.getElementById("civilStatus").textContent = emp.civil_status;
                            document.getElementById("address").textContent = emp.address;
                            document.getElementById("branch").textContent = emp.branch;
                            document.getElementById("position").textContent = emp.position;
                            document.getElementById("workShift").textContent = emp.work_shift_start + " - " + emp.work_shift_end;
                            document.getElementById("restDay").textContent = emp.rest_day;
                            document.getElementById("qrcodeId").textContent = emp.qrcode_id;
                            document.getElementById("fingerprintId").textContent = emp.fingerprint_id || "N/A";

                            const monthlySalaryEl = document.getElementById("monthlySalary");
                            if (emp.monthly_salary) {
                                const formattedSalary = Number(emp.monthly_salary).toLocaleString('en-PH', {
                                    style: 'currency',
                                    currency: 'PHP',
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                                monthlySalaryEl.textContent = formattedSalary;
                            } else {
                                monthlySalaryEl.textContent = "₱0";
                            }

                            ['birthday', 'date_joined'].forEach(id => {
                                const el = document.getElementById(id === 'date_joined' ? 'dateJoined' : id); // map to HTML id
                                el.textContent = emp[id] 
                                    ? new Date(emp[id]).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) 
                                    : "-";
                            });

                            const workShiftEl = document.getElementById("workShift");

                            function formatTime24to12(timeStr) {
                                if (!timeStr) return "-";
                                const [hours, minutes] = timeStr.split(":").map(Number);
                                let period = hours >= 12 ? "PM" : "AM";
                                let hour12 = hours % 12 || 12; // convert 0 → 12
                                return `${hour12}:${minutes.toString().padStart(2,'0')} ${period}`;
                            }

                            workShiftEl.textContent = `${formatTime24to12(emp.work_shift_start)} - ${formatTime24to12(emp.work_shift_end)}`;

                            // Store the shift duration (in hours) globally so attendance calculations can use it
                            (function() {
                                try {
                                    if (emp.work_shift_start && emp.work_shift_end) {
                                        const [sh, sm] = emp.work_shift_start.split(':').map(Number);
                                        const [eh, em] = emp.work_shift_end.split(':').map(Number);
                                        const start = new Date(); start.setHours(sh, sm, 0, 0);
                                        const end = new Date(); end.setHours(eh, em, 0, 0);
                                        let diff = (end - start) / (1000 * 60 * 60); // hours
                                        if (diff <= 0) diff += 24; // handle overnight shifts
                                        window.employeeShiftDurationHours = diff;
                                    } else {
                                        window.employeeShiftDurationHours = 8; // default
                                    }
                                } catch (e) {
                                    window.employeeShiftDurationHours = 8;
                                }
                            })();

                            populateSection('education', emp.education);
                            populateSection('workExperience', emp.work_experience);
                            populateSection('trainings', emp.trainings);
                            populateSection('certificates', emp.certificates);
                            populateSection('skills', emp.skills);

                            document.getElementById("totalSssContributions").textContent = emp.sss_contribution;
                            document.getElementById("totalHdmfContributions").textContent = emp.hdmf_contribution;
                            document.getElementById("totalPhicContributions").textContent = emp.phic_contribution;

                            const sssContributions = parseInt(emp.sss_contribution, 10);
                            const hdmfContributions = parseInt(emp.hdmf_contribution, 10);
                            const phicContributions = parseInt(emp.phic_contribution, 10);
                            const isFemale = emp.sex.toLowerCase() === 'female';

                            const sssBenefits = [
                                { 
                                    name: "Sickness Benefit", 
                                    eligible: sssContributions >= 3,
                                    reason: sssContributions < 3 ? `Requires a minimum of 3 contributions` : null, 
                                    claim: "Online via the My.SSS account or by submitting an Sickness Notification Form to the employer."
                                },
                                { 
                                    name: "Maternity Benefit", 
                                    eligible: sssContributions >= 3 && isFemale, 
                                    reason: !isFemale ? "For female employees only" : sssContributions < 3 ? `Requires a minimum of 3 contributions` : null,
                                    claim: "Online via the My.SSS account or by submitting a Maternity Notification Form to the employer."
                                },
                                { 
                                    name: "Unemployment Benefit", 
                                    eligible: sssContributions >= 36, 
                                    reason: sssContributions < 36 ? `Requires a minimum of 36 contributions` : null,
                                    claim: "Online via the My.SSS account by applying for the Unemployment Benefit."
                                },
                                { 
                                    name: "Disability Benefit", 
                                    eligible: sssContributions >= 36, 
                                    reason: sssContributions < 36 ? `Requires a minimum of 36 contributions` : null,
                                    claim: "Submit a Disability Claim Application and medical documents to an SSS branch."
                                },
                                { 
                                    name: "Retirement Benefit", 
                                    eligible: sssContributions >= 120, 
                                    reason: sssContributions < 120 ? `Requires a minimum of 120 contributions` : null,
                                    claim: "Submit a Retirement Claim Application to an SSS branch or online via My.SSS."
                                },
                                { 
                                    name: "Death Benefit", 
                                    eligible: sssContributions >= 36, 
                                    reason: sssContributions < 36 ? `Requires a minimum of 36 contributions` : null,
                                    claim: "Beneficiaries must submit a Death Claim Application and required documents to an SSS branch."
                                },
                                { 
                                    name: "Funeral Benefit", 
                                    eligible: true, 
                                    reason: null,
                                    claim: "The person who paid for the funeral must submit a Funeral Claim Application to an SSS branch."
                                },
                            ];

                            const hdmfBenefits = [
                                { 
                                    name: "Multi-Purpose Loan", 
                                    eligible: hdmfContributions >= 24, 
                                    reason: hdmfContributions < 24 ? `Requires a minimum of 24 contributions` : null,
                                    claim: "Apply for the loan online via Virtual Pag-IBIG or at any Pag-IBIG branch."
                                },
                                { 
                                    name: "Housing Loan", 
                                    eligible: hdmfContributions >= 24, 
                                    reason: hdmfContributions < 24 ? `Requires a minimum of 24 contributions` : null,
                                    claim: "Apply for the loan at any Pag-IBIG branch or via the online housing loan portal."
                                },
                                {
                                    name: "Calamity Loan",
                                    eligible: hdmfContributions >= 24,
                                    reason: hdmfContributions < 24 ? `Requires a minimum of 24 contributions` : null,
                                    claim: "Apply for the loan online via Virtual Pag-IBIG or at any Pag-IBIG branch after a calamity is declared."
                                },
                                {
                                    name: "Regular Savings Withdrawal",
                                    eligible: hdmfContributions >= 240,
                                    reason: hdmfContributions < 240 ? `Requires a minimum of 240 contributions (20 years)` : null,
                                    claim: "Withdrawal can be claimed upon membership maturity (after 20 years), retirement, or other valid reasons. Process via Virtual Pag-IBIG or branch."
                                }
                            ];

                            const phicBenefits = [
                                { 
                                    name: "Inpatient Benefits", 
                                    eligible: phicContributions >= 9, 
                                    reason: phicContributions < 9 ? `Requires a minimum of 9 contributions` : null,
                                    claim: "The hospital will automatically deduct the PhilHealth benefit from the total bill upon discharge."
                                },
                                { 
                                    name: "Outpatient Benefits", 
                                    eligible: phicContributions >= 9, 
                                    reason: phicContributions < 9 ? `Requires a minimum of 9 contributions` : null,
                                    claim: "The clinic or facility will process the benefit deduction from your total bill."
                                },
                                {
                                    name: "Z Benefits (for Catastrophic Illnesses)",
                                    eligible: phicContributions >= 9,
                                    reason: phicContributions < 9 ? `Requires a minimum of 9 contributions` : null,
                                    claim: "The hospital will process the claim and deduct the package amount from the total bill."
                                },
                                {
                                    name: "Special Benefit Packages",
                                    eligible: phicContributions >= 9,
                                    reason: phicContributions < 9 ? `Requires a minimum of 9 contributions` : null,
                                    claim: "Your chosen healthcare provider will process the claim and apply the deduction to your bill."
                                }
                            ];

                            populateBenefits('sss', sssBenefits);
                            populateBenefits('hdmf', hdmfBenefits);
                            populateBenefits('phic', phicBenefits);
                        }
                    } else {
                        console.error(data.message);
                    }
                })
                .catch(err => console.error("Fetch error:", err));
        }

        function populateSection(sectionName, data) {
            const listEl = document.getElementById(sectionName + 'List');
            listEl.innerHTML = ''; // Clear previous content

            if (data && data.length > 0) {
                data.forEach(item => {
                    const itemEl = document.createElement('div');
                    itemEl.classList.add('mb-3', 'p-3', 'rounded-3', 'bg-light', 'info-card');

                    // Build the content based on the section
                    let content = '';
                    if (sectionName === 'education') {
                        content = `
                            <h6 class="fw-bold text-text-dark-grey">${item.school}</h6>
                            <p class="mb-0 text-text-muted-grey">Academic Year: ${item.academic_year}</p>
                            <p class="mb-0 text-text-muted-grey">Course/Strand: ${item.course_strand}</p>
                            ${item.special_notes ? `<p class="mb-0 text-text-muted-grey">Special notes: ${item.special_notes}</p` : ''}
                        `;
                    } else if (sectionName === 'workExperience') {
                        content = `
                            <h6 class="fw-bold text-text-dark-grey">${item.company}</h6>
                            <p class="mb-0 text-text-muted-grey">Length of Service: ${item.length_of_service}</p>
                            <p class="mb-0 text-text-muted-grey">Position: ${item.position}</p>
                            ${item.duties_achievements ? `<p class="mb-0 text-text-muted-grey">Duties and Notable Achievements: ${item.duties_achievements}</p>` : ''}
                        `;
                    } else if (sectionName === 'trainings') {
                        content = `
                            <h6 class="fw-bold text-text-dark-grey">${item.training_name}</h6>
                            ${item.date_attended ? `<p class="mb-0 text-text-muted-grey">Date Attended: ${item.date_attended}</p>` : ''}
                            ${item.notes ? `<p class="mb-0 text-text-muted-grey">Notes: ${item.notes}</p>` : ''}
                        `;
                    } else if (sectionName === 'certificates') {
                        content = `
                            <h6 class="fw-bold text-text-dark-grey">${item.certificate_name}</h6>
                            ${item.date_issued ? `<p class="mb-0 text-text-muted-grey">Date Issued: ${item.date_issued}</p>` : ''}
                            ${item.issuing_body ? `<p class="mb-0 text-text-muted-grey">Issuing Body: ${item.issuing_body}</p>` : ''}
                        `;
                    } else if (sectionName === 'skills') {
                        // For skills, we can create a simple list
                        itemEl.classList.remove('mb-3', 'p-3', 'rounded-3', 'bg-light', 'info-card');
                        itemEl.classList.add('badge', 'bg-accent-peach', 'text-dark-grey', 'me-2', 'skill-badge');
                        content = item.skill_name;
                    }

                    itemEl.innerHTML = content;
                    listEl.appendChild(itemEl);
                });
            } else {
                // Show a message if there is no data
                const noDataEl = document.createElement('p');
                noDataEl.classList.add('text-text-muted-grey');
                noDataEl.textContent = 'No data available for this section.';
                listEl.appendChild(noDataEl);
            }
        }

        async function loadAttendance(id, year, month) {
            if (!id) {
                attendanceRecordsContainer.innerHTML = '<p class="text-text-muted-grey">Employee ID not found.</p>';
                return;
            }

            try {
                // Build first/last day of the month
                const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
                const endDate = new Date(year, month, 0); // last day of month
                const endDateStr = `${year}-${String(month).padStart(2, '0')}-${String(endDate.getDate()).padStart(2, '0')}`;

                const response = await fetch(`get_attendance_details.php?employeeId=${id}&startDate=${startDate}&endDate=${endDateStr}`);
                const data = await response.json();

                attendanceRecordsContainer.innerHTML = '';

                if (data.success && data.attendance.length > 0) {
                    const monthCard = document.createElement('div');
                    monthCard.classList.add('card', 'mb-4', 'shadow-sm');

                    // Helper to format duration (milliseconds) into H:mm and decimal hours
                    function formatDuration(ms) {
                        if (!ms || ms <= 0) return { hhmm: '-', hours: 0 };
                        const totalMinutes = Math.round(ms / (1000 * 60));
                        const h = Math.floor(totalMinutes / 60);
                        const m = totalMinutes % 60;
                        const hoursDecimal = (totalMinutes / 60);
                        return { hhmm: `${h}:${String(m).padStart(2, '0')}`, hours: hoursDecimal };
                    }

                    // Use shift duration stored earlier, fallback to 8
                    const shiftHours = window.employeeShiftDurationHours || 8;

                    // Build table rows
                    let rowsHtml = '';

                    data.attendance.forEach(record => {
                        const dateStr = record.attendance_date
                            ? new Date(record.attendance_date).toLocaleDateString('en-US', { day: 'numeric', month: 'short' })
                            : '-';

                        const timeInStr = record.time_in
                            ? new Date(`${record.attendance_date}T${record.time_in}`).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
                            : '-';
                        const timeOutStr = record.time_out
                            ? new Date(`${record.attendance_date}T${record.time_out}`).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
                            : '-';

                        // Parse shift start/end as Date objects
                        const shiftStart = record.shift_start ? new Date(`${record.attendance_date}T${record.shift_start}`) : null;
                        const shiftEnd = record.shift_end ? new Date(`${record.attendance_date}T${record.shift_end}`) : null;

                        // Compute Late (only if time_in exists)
                        let lateMinutes = 0;
                        if (record.time_in && shiftStart) {
                            const actualIn = new Date(`${record.attendance_date}T${record.time_in}`);
                            const diffMinutes = (actualIn - shiftStart) / (1000 * 60);
                            lateMinutes = diffMinutes > 10 ? diffMinutes - 10 : 0; // subtract 10 min grace
                        }

                        // Compute Undertime (only if time_out exists)
                        let undertimeMinutes = 0;
                        if (record.time_out && shiftEnd) {
                            const actualOut = new Date(`${record.attendance_date}T${record.time_out}`);
                            const diffMinutes = (shiftEnd - actualOut) / (1000 * 60);
                            undertimeMinutes = diffMinutes > 0 ? diffMinutes : 0;
                        }

                        // Compute Hours Worked
                        let hoursWorkedMs = 0;
                        if (record.time_in && record.time_out) {
                            const tin = new Date(`${record.attendance_date}T${record.time_in}`);
                            const tout = new Date(`${record.attendance_date}T${record.time_out}`);
                            hoursWorkedMs = tout - tin;
                            if (hoursWorkedMs < 0) hoursWorkedMs = 0;
                        }
                        const dur = formatDuration(hoursWorkedMs);

                        // Compute Overtime (only if time_out exists)
                        let overtimeMinutes = 0;
                        if (record.time_out && shiftEnd) {
                            const actualOut = new Date(`${record.attendance_date}T${record.time_out}`);
                            const diffMinutes = (actualOut - shiftEnd) / (1000 * 60);
                            overtimeMinutes = diffMinutes > 0 ? diffMinutes : 0;
                        }

                        // Pictures
                        let pictureLinkIn = record.time_in_picture && record.time_in_picture.trim() !== ''
                            ? `<a href="${record.time_in_picture}" download target="_blank">${record.time_in_picture.split('/').pop()}</a>`
                            : '-';
                        let pictureLinkOut = record.time_out_picture && record.time_out_picture.trim() !== ''
                            ? `<a href="${record.time_out_picture}" download target="_blank">${record.time_out_picture.split('/').pop()}</a>`
                            : '-';

                        // Status
                        const statusLower = (record.status || '').toLowerCase();
                        let statusHtml = '';
                        switch (statusLower) {
                            case 'present': statusHtml = '<span class="text-success">Present</span>'; break;
                            case 'absent': statusHtml = '<span class="text-danger">Absent</span>'; break;
                            case 'paid': statusHtml = '<span class="text-primary">Paid Leave</span>'; break;
                            case 'unpaid': statusHtml = '<span class="text-primary">Unpaid Leave</span>'; break;
                            case 'off': statusHtml = '<span class="text-primary">Rest Day</span>'; break;
                            case 'closed': statusHtml = '<span class="text-primary">Closed</span>'; break;
                            case 'half': statusHtml = '<span class="text-primary">Half Day</span>'; break;
                            case 'regular':
                                statusHtml = record.time_in && record.time_out
                                    ? '<span class="text-success">Present</span> <span>(Regular Holiday)</span>'
                                    : '<span class="text-primary">Regular Holiday</span>';
                                break;
                            case 'special':
                                statusHtml = record.time_in && record.time_out
                                    ? '<span class="text-success">Present</span> <span>(Special Non-working Holiday)</span>'
                                    : '<span class="text-primary">Special Non-working Holiday</span>';
                                break;
                            default: statusHtml = `<span>${record.status || '-'}</span>`;
                        }

                        rowsHtml += `
                            <tr>
                                <td>${dateStr}</td>
                                <td>${statusHtml}</td>
                                <td>${shiftStart ? shiftStart.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}</td>
                                <td>${shiftEnd ? shiftEnd.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}</td>
                                <td>${timeInStr}</td>
                                <td>${timeOutStr}</td>
                                <td>${dur.hhmm}</td>
                                <td>${lateMinutes > 0 ? lateMinutes.toFixed(0) + ' min' : '-'}</td>
                                <td>${undertimeMinutes > 0 ? (undertimeMinutes/60).toFixed(2)+' hrs' : '-'}</td>
                                <td>${overtimeMinutes > 0 ? (overtimeMinutes/60).toFixed(2)+' hrs' : '-'}</td>
                                <td>${pictureLinkIn}</td>
                                <td>${pictureLinkOut}</td>
                            </tr>
                        `;
                    });

                    monthCard.innerHTML = `
                        <div class="card-header bg-primary-soft-blue text-white fw-bold">
                            ${new Date(startDate).toLocaleString('default', { month: 'long', year: 'numeric' })}
                        </div>
                        <div class="card-body p-3">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered mb-2">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Shift Start</th>
                                            <th>Shift End</th>
                                            <th>Time In</th>
                                            <th>Time Out</th>
                                            <th>Hours Worked</th>
                                            <th>Late</th>
                                            <th>Undertime</th>
                                            <th>Overtime</th>
                                            <th>Time-in Picture</th>
                                            <th>Time-out Picture</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${rowsHtml}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    `;

                    attendanceRecordsContainer.appendChild(monthCard);

                } else {
                    attendanceRecordsContainer.innerHTML = '<p class="text-text-muted-grey">No attendance records found for this month.</p>';
                }
            } catch (error) {
                console.error('Error fetching attendance data:', error);
                attendanceRecordsContainer.innerHTML = '<p class="text-danger">Failed to load attendance data.</p>';
            }
        }

        async function populateAttendanceMonths(employeeId) {
            if (!employeeId) return;

            try {
                const response = await fetch(`get_existing_attendance.php?employee_id=${employeeId}`);
                const data = await response.json();

                if (data.success && data.months.length > 0) {
                    attendanceFilter.innerHTML = '';
                    data.months.forEach(m => {
                        const option = document.createElement('option');
                        option.value = `${m.year}-${m.month}`;
                        option.textContent = m.label;
                        attendanceFilter.appendChild(option);
                    });

                    // Default: latest month
                    const [year, month] = attendanceFilter.value.split('-');
                    loadAttendance(employeeId, year, month);

                    attendanceFilter.addEventListener('change', function () {
                        const [y, m] = this.value.split('-');
                        loadAttendance(employeeId, y, m);
                    });

                } else {
                    attendanceFilter.innerHTML = '<option value="">No records</option>';
                    attendanceRecordsContainer.innerHTML = '<p class="text-text-muted-grey">No attendance records found.</p>';
                }
            } catch (err) {
                console.error('Error fetching months:', err);
                attendanceFilter.innerHTML = '<option value="">Error loading months</option>';
            }
        }

        populateAttendanceMonths(employeeId);

        async function refreshEmployeeData() {
            if (!employeeId) return;

            try {
                const res = await fetch(`get_employee_details.php`);
                const data = await res.json();
                if (data.success) {
                    const emp = data.employees.find(e => e.id == employeeId);
                    if (emp) {
                        // Update fingerprint ID
                        document.getElementById("fingerprintId").textContent = emp.fingerprint_id || "N/A";

                        if (attendanceFilter.value) {
                        const [y, m] = attendanceFilter.value.split('-');
                        loadAttendance(employeeId, y, m);
                    }
                    }
                }
            } catch(err) {
                console.error("Error refreshing employee data:", err);
            }
        }

        setInterval(refreshEmployeeData, 6000);

        function populateBenefits(type, data) {
            const listEl = document.getElementById(type + 'BenefitsList');
            listEl.innerHTML = ''; // Clear existing content

            if (data && data.length > 0) {
                data.forEach(item => {
                    const benefitCard = document.createElement('div');
                    benefitCard.classList.add('card', 'mb-2', 'p-3', 'shadow-sm', 'info-card-peach');
                    let eligibleText = item.eligible 
                        ? `<span class="text-success">Yes</span>` 
                        : `<span class="text-danger">No</span>` + (item.reason ? ` <span class="text-dark">(${item.reason})</span>` : '');

                    benefitCard.innerHTML = `
                        <h6 class="fw-bold text-text-dark-grey">${item.name}</h6>
                        <p class="mb-1"><span class="fw-medium">Eligible:</span> ${eligibleText}</p>
                        <p class="mb-0"><span class="fw-medium">How to Claim:</span> ${item.claim}</p>
                    `;
                    listEl.appendChild(benefitCard);
                });
            } else {
                const noDataEl = document.createElement('p');
                noDataEl.classList.add('text-text-muted-grey');
                noDataEl.textContent = 'No benefits information available.';
                listEl.appendChild(noDataEl);
            }
        }
        
        const exportAttendanceBtn = document.getElementById("exportAttendanceBtn");
        if (exportAttendanceBtn) {
            exportAttendanceBtn.addEventListener("click", async () => {
                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF("l", "mm", "a4");

                // Add Inter font if available (needs to be added to jsPDF first)
                // For simplicity, we use 'helvetica' as a placeholder
                const font = "helvetica"; // replace with 'Inter' if added via addFont

                const pageWidth = pdf.internal.pageSize.getWidth();
                const monthCards = document.querySelectorAll("#attendanceRecordsContainer .card");
                if (!monthCards.length) return;

                monthCards.forEach((card, index) => {
                    const header = card.querySelector(".card-header");
                    const table = card.querySelector("table");
                    if (!table) return;

                    // Month header
                    if (header) {
                        pdf.setFillColor(92, 125, 138); // #5C7D8A
                        pdf.rect(10, 10, pageWidth - 20, 10, "F"); // header rectangle
                        pdf.setFont(font, "bold");
                        pdf.setFontSize(12);
                        pdf.setTextColor(255, 255, 255); // white text
                        pdf.text(header.innerText, 12, 17);
                    }

                    // Table columns & rows
                    const columns = Array.from(table.querySelectorAll("thead th")).map(th => th.innerText);
                    const rows = Array.from(table.querySelectorAll("tbody tr")).map(tr =>
                        Array.from(tr.querySelectorAll("td")).map(td => {
                            // Determine color for status column
                            const status = td.innerText.toLowerCase();
                            if (status.includes("present")) return { content: td.innerText, styles: { textColor: [40, 167, 69] } }; // green
                            if (status.includes("absent")) return { content: td.innerText, styles: { textColor: [220, 53, 69] } }; // red
                            if (status.includes("paid") || status.includes("unpaid") || status.includes("rest") || status.includes("closed") || status.includes("holiday")) {
                                return { content: td.innerText, styles: { textColor: [2, 123, 255] } };
                            }
                            return { content: td.innerText, styles: { textColor: [0, 0, 0] } }; // default black
                        })
                    );

                    pdf.autoTable({
                        startY: 22,
                        head: [columns],
                        body: rows,
                        theme: "grid",
                        headStyles: {
                            fillColor: [245, 245, 245], // light gray
                            textColor: [0, 0, 0],
                            font: font,
                            fontStyle: "bold",
                            fontSize: 10,
                            halign: "center",
                        },
                        bodyStyles: { font: font, fontSize: 9, textColor: [0, 0, 0] },
                        alternateRowStyles: { fillColor: [255, 255, 255] },
                        margin: { left: 10, right: 10 },
                    });

                    if (index < monthCards.length - 1) pdf.addPage();
                });

                pdf.save("attendance.pdf");
            });
        }

    }
    
    initializeProfile();
});