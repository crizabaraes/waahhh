<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

// Check if employeeId is provided in the GET request
if (!isset($_GET['employeeId'])) {
    die(json_encode(["success" => false, "message" => "Employee ID not provided."]));
}

$employeeId = $_GET['employeeId'];

// (FOR TESTING) $fakeToday = '2025-11-15';
// $conn->query("SET @today = '$fakeToday'");
// $sql = "SELECT * FROM attendance WHERE employee_id = ? AND attendance_date <= @today";

$sql = "SELECT * FROM attendance WHERE employee_id = ? AND attendance_date <= CURDATE()";

// Optional: Add date range filtering if a start and end date are provided
if (isset($_GET['startDate']) && isset($_GET['endDate'])) {
    $sql .= " AND attendance_date BETWEEN ? AND ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $employeeId, $_GET['startDate'], $_GET['endDate']);
} else {
    // Only filter by employeeId
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $employeeId);
}

// Execute the query
if (!$stmt->execute()) {
    die(json_encode(["success" => false, "message" => "Query failed: " . $stmt->error]));
}

$result = $stmt->get_result();
$attendanceRecords = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $attendanceRecords[] = $row;
    }
    echo json_encode(["success" => true, "attendance" => $attendanceRecords]);
} else {
    echo json_encode(["success" => false, "message" => "No attendance records found for this employee.", "attendance" => []]);
}

$stmt->close();
$conn->close();
?>