<?php
require_once 'authentication/db_connect.php';
header('Content-Type: application/json');
$response = ['success' => false, 'message' => ''];

$action = $_GET['action'] ?? null;

try {
    switch ($action) {

        /**
         * -----------------------------------------------------
         * 1. SCAN (ESP32 endpoint)
         * -----------------------------------------------------
         */
        case 'scan':
            $data = json_decode(file_get_contents('php://input'), true);

            $fingerprint_id = $data['fingerprint_id'] ?? null;
            $qrcode_id = $data['qrcode_id'] ?? null;
            $qrcode_picture = $data['qrcode_picture'] ?? null; // Only filled if QR Code scan

            if (!$fingerprint_id && !$qrcode_id) {
                throw new Exception('Fingerprint or QR Code ID required.');
            }

            // Find employee
            if ($fingerprint_id) {
                $stmt = $conn->prepare("SELECT id FROM employees WHERE fingerprint_id = ? AND account_status != 'deactivated'");
                $stmt->bind_param("i", $fingerprint_id);
            } else {
                $stmt = $conn->prepare("SELECT id FROM employees WHERE qrcode_id = ? AND account_status != 'deactivated'");
                $stmt->bind_param("s", $qrcode_id);
            }
            $stmt->execute();
            $employee = $stmt->get_result()->fetch_assoc();
            if (!$employee) throw new Exception('Employee not found.');
            $employee_id = $employee['id'];

            $today = date('Y-m-d');

            // Check if employee already has an attendance row today (ANY status, even if time_in NULL)
            $stmt = $conn->prepare("
                SELECT * FROM attendance
                WHERE employee_id = ? AND attendance_date = ?
            ");

            $stmt->bind_param("ss", $employee_id, $today);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();

            // Check if employee already completed attendance today (both in and out)
            if ($existing && $existing['time_in'] && $existing['time_out']) {
                $response['success'] = false;
                $response['message'] = 'Already completed attendance for today.';
                break;
            }

            if ($existing) {
                // Clock-out scenario
                if ($existing['time_out'] === null) {
                    $nowTime = date('H:i:s');

                    if ($qrcode_id && $qrcode_picture) {
                        $uploadDir = "uploads/attendance_pictures/";
                        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                        $filename = $uploadDir . "att_" . time() . "_" . rand(1000,9999) . ".jpg";
                        file_put_contents($filename, base64_decode($qrcode_picture));
                        $stmt = $conn->prepare("UPDATE attendance SET time_out = ?, time_out_picture = ? WHERE attendance_id = ?");
                        $stmt->bind_param("ssi", $nowTime, $filename, $existing['attendance_id']);
                    } else {
                        $stmt = $conn->prepare("UPDATE attendance SET time_out = ? WHERE attendance_id = ?");
                        $stmt->bind_param("si", $nowTime, $existing['attendance_id']);
                    }
                    $stmt->execute();
                    $response['success'] = true;
                    $response['message'] = 'Clock-out recorded.';

                    $picCheck = $conn->prepare("
                        SELECT time_in_picture, time_out_picture 
                        FROM attendance 
                        WHERE employee_id = ? AND attendance_date = ? 
                        AND (time_in_picture IS NOT NULL OR time_out_picture IS NOT NULL)
                        LIMIT 1
                    ");
                    $picCheck->bind_param("ss", $employee_id, $today);
                    $picCheck->execute();
                    $picRow = $picCheck->get_result()->fetch_assoc();

                    if ($picRow) {
                        $n = $conn->query("SELECT full_name FROM employees WHERE id = '$employee_id'")->fetch_assoc();
                        $full_name = $n['full_name'];

                        $stmtN = $conn->prepare("
                            INSERT INTO notifications (employee_id, title, content, date_sent)
                            VALUES (?, 'Attendance Picture Confirmation', ?, NOW())
                        ");

                        $content = $full_name . ' has an attendance picture to confirm, check it out on their timesheet.';
                        $stmtN->bind_param("ss", $employee_id, $content);
                        $stmtN->execute();
                    }
                    break;
                } else {
                    $response['success'] = false;
                    $response['message'] = 'Already clocked out today.';
                    break;
                }
            } else {
                // Clock-in scenario
                $time_in_picture = null;
                if ($qrcode_id && $qrcode_picture) {
                    $uploadDir = "uploads/attendance_pictures/";
                    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                    $filename = $uploadDir . "att_" . time() . "_" . rand(1000,9999) . ".jpg";
                    file_put_contents($filename, base64_decode($qrcode_picture));
                    $time_in_picture = $filename;  // <-- store file path instead of base64
                }

                // Default status ONLY for new rows
                $status = 'PRESENT';

                // Fetch shift start/end from employees table
                $ss = $conn->prepare("SELECT work_shift_start, work_shift_end FROM employees WHERE id = ?");
                $ss->bind_param("s", $employee_id);
                $ss->execute();
                $sh = $ss->get_result()->fetch_assoc();

                $shift_start = $sh['work_shift_start'];
                $shift_end = $sh['work_shift_end'];

                $today = date('Y-m-d');          // attendance date
                $nowTime = date('H:i:s');        // current time only

                $stmt = $conn->prepare("
                    INSERT INTO attendance 
                    (employee_id, fingerprint_id, qrcode_id, attendance_date, time_in, time_in_picture, status, shift_start, shift_end)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("sisssssss", $employee_id, $fingerprint_id, $qrcode_id, $today, $nowTime, $time_in_picture, $status, $shift_start, $shift_end);
                $stmt->execute();

                $response['success'] = true;
                $response['message'] = 'Clock-in recorded.';
                break;
            }

        case 'leave':
            // Input: employee_id, status ('PAID', 'UNPAID', 'HALF'), date
            // Optional: shift_start, shift_end (if HR marks half-day or modified shift)
            $employee_id = $_POST['employee_id'];
            $status = $_POST['status'];
            $date = $_POST['date'];

            $shift_start = $_POST['shift_start'] ?? null;
            $shift_end = $_POST['shift_end'] ?? null;

            if (!$shift_start || !$shift_end) {
                // Fetch default shift from employees table
                $s = $conn->prepare("SELECT work_shift_start, work_shift_end FROM employees WHERE id = ?");
                $s->bind_param("s", $employee_id);
                $s->execute();
                $row = $s->get_result()->fetch_assoc();
                $shift_start = $shift_start ?: $row['work_shift_start'];
                $shift_end = $shift_end ?: $row['work_shift_end'];
            }

            // Check if row exists
            $stmt = $conn->prepare("SELECT attendance_id FROM attendance WHERE employee_id = ? AND attendance_date = ?");
            $stmt->bind_param("ss", $employee_id, $date);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();

            if ($existing) {
                $stmt = $conn->prepare("
                    UPDATE attendance 
                    SET status = ?, shift_start = ?, shift_end = ?
                    WHERE attendance_id = ?
                ");
                $stmt->bind_param("sssi", $status, $shift_start, $shift_end, $existing['attendance_id']);
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO attendance (employee_id, attendance_date, status, shift_start, shift_end)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("sssss", $employee_id, $date, $status, $shift_start, $shift_end);
                $stmt->execute();
            }

            $response['success'] = true;
            $response['message'] = "Leave applied/updated.";
            break;

        case 'holiday':
            $date = $_POST['date'];
            $type = $_POST['type']; // REGULAR or SPECIAL
            $shift_start = $_POST['shift_start'] ?? null;
            $shift_end = $_POST['shift_end'] ?? null;

            // Fetch all employees except HR and deactivated
            $emp_stmt = $conn->prepare("
                SELECT id, work_shift_start, work_shift_end 
                FROM employees 
                WHERE position != 'Human Resources' AND account_status != 'deactivated'
            ");
            $emp_stmt->execute();
            $employees = $emp_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            foreach ($employees as $emp) {
                $employee_id = $emp['id'];

                // Determine shift times
                $s_start = $shift_start ?: $emp['work_shift_start'];
                $s_end = $shift_end ?: $emp['work_shift_end'];

                // Check existing attendance
                $check = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ? AND attendance_date = ?");
                $check->bind_param("ss", $employee_id, $date);
                $check->execute();
                $existing = $check->get_result()->fetch_assoc();

                if ($existing) {
                    if (in_array($existing['status'], ['REGULAR', 'SPECIAL'])) {
                        $updates = [];
                        $params = [];
                        $types = "";

                        $updates[] = "status = ?";
                        $params[] = $type;
                        $types .= "s";

                        if ($shift_start !== null) {
                            $updates[] = "shift_start = ?";
                            $params[] = $s_start;
                            $types .= "s";
                        }

                        if ($shift_end !== null) {
                            $updates[] = "shift_end = ?";
                            $params[] = $s_end;
                            $types .= "s";
                        }

                        $setClause = implode(", ", $updates);

                        $upd = $conn->prepare("UPDATE attendance SET $setClause WHERE attendance_id = ?");
                        $types .= "i";
                        $params[] = $existing['attendance_id'];

                        $upd->bind_param($types, ...$params);
                        $upd->execute();
                    }
                } else {
                    $ins = $conn->prepare("
                        INSERT INTO attendance (employee_id, attendance_date, status, shift_start, shift_end)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $ins->bind_param("sssss", $employee_id, $date, $type, $s_start, $s_end);
                    $ins->execute();
                }
            }

            $response['success'] = true;
            $response['message'] = "Holiday recorded for all employees.";
            break;

        case 'closed':
            // Input: date
            $date = $_POST['date'];
            $branch = $_POST['branch'];

            $stmt = $conn->prepare("SELECT id FROM employees WHERE account_status != 'deactivated' AND branch = ?");
            $stmt->bind_param("s", $branch);
            $stmt->execute();
            $employees = $stmt->get_result();
            while ($emp = $employees->fetch_assoc()) {
                $employee_id = $emp['id'];

                // Check if row exists
                $stmt = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ? AND attendance_date = ?");
                $stmt->bind_param("ss", $employee_id, $date);
                $stmt->execute();
                $existing = $stmt->get_result()->fetch_assoc();

                if ($existing) {
                    $stmt = $conn->prepare("UPDATE attendance SET status = 'CLOSED' WHERE attendance_id = ?");
                    $stmt->bind_param("i", $existing['attendance_id']);
                    $stmt->execute();
                } else {
                    $stmt = $conn->prepare("INSERT INTO attendance (employee_id, attendance_date, status) VALUES (?, ?, 'CLOSED')");
                    $stmt->bind_param("ss", $employee_id, $date);
                    $stmt->execute();
                }
            }

            $response['success'] = true;
            $response['message'] = "Business closed updated for all employees.";
            break;

        default:
            throw new Exception('Invalid action.');
    }

} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
}

$conn->close();
echo json_encode($response);
?>
