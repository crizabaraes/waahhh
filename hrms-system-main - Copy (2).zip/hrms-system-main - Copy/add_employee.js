document.addEventListener('DOMContentLoaded', function() {
    // New Employee Modal elements
    const addEmployeeBtn = document.getElementById('addEmployeeBtn');
    const addEmployeeModal = document.getElementById('addEmployeeModal');
    const addEmployeeForm = document.getElementById('addEmployeeForm');
    const cancelAddEmployeeBtn = document.getElementById('cancelAddEmployeeBtn');
    const profilePictureInput = document.getElementById('profilePictureInput');
    const profilePicturePreview = document.getElementById('profilePicturePreview');
    const employeeWorkEmailInput = document.getElementById('employeeWorkEmail');
    const employeeConfirmWorkEmailInput = document.getElementById('employeeConfirmWorkEmail');
    const employeePasswordInput = document.getElementById('employeePassword');
    const employeeBirthdayInput = document.getElementById('employeeBirthday');
    const employeeAgeInput = document.getElementById('employeeAge');
    const employeePosition = document.getElementById('employeePosition');
    const employeeDateJoinedInput = document.getElementById('employeeDateJoined');
    const employeeQRcodeIdInput = document.getElementById('employeeQRcodeId');
    const employeeContactInput = document.getElementById('employeeContact');
    const employeeShiftStartInput = document.getElementById('employeeShiftStart');
    const employeeShiftEndInput = document.getElementById('employeeShiftEnd');

    // Dynamic sections checkboxes
    const noEducationCheckbox = document.getElementById('noEducationCheckbox');
    const noWorkExperienceCheckbox = document.getElementById('noWorkExperienceCheckbox');
    const noTrainingCheckbox = document.getElementById('noTrainingCheckbox');
    const noCertificatesCheckbox = document.getElementById('noCertificatesCheckbox');
    const noSkillsCheckbox = document.getElementById('noSkillsCheckbox');
    const noOtherFileCheckbox = document.getElementById('noOtherFileCheckbox');

    // Dynamic sections containers
    const educationContainer = document.getElementById('educationContainer');
    const workExperienceContainer = document.getElementById('workExperienceContainer');
    const trainingContainer = document.getElementById('trainingContainer');
    const certificatesContainer = document.getElementById('certificatesContainer');
    const skillsContainer = document.getElementById('skillsContainer');
    const otherFilesContainer = document.getElementById('otherFilesContainer');

    // Dynamic sections add buttons
    const addEducationBtn = document.getElementById('addEducationBtn');
    const addWorkExperienceBtn = document.getElementById('addWorkExperienceBtn');
    const addTrainingBtn = document.getElementById('addTrainingBtn');
    const addCertificateBtn = document.getElementById('addCertificateBtn');
    const addSkillBtn = document.getElementById('addSkillBtn');
    const addOtherFileBtn = document.getElementById('addOtherFileBtn');

    let educationCounter = 0;
    let workExperienceCounter = 0;
    let trainingCounter = 0;
    let certificatesCounter = 0;
    let skillsCounter = 0;
    let otherFileCounter = 0;

    // Show Add Employee Modal
    if (addEmployeeBtn) {
        addEmployeeBtn.addEventListener('click', () => {
            addEmployeeForm.reset(); // Clear form fields
            generateRandomPassword(); // Generate password on modal load
            employeeAgeInput.value = ''; // Clear age

            if (profilePicturePreview) {
                profilePicturePreview.src = '';
                profilePicturePreview.classList.add('d-none'); // keep it hidden
            }
            
            // Reset dynamic sections content
            if (educationContainer) educationContainer.innerHTML = '';
            if (workExperienceContainer) workExperienceContainer.innerHTML = '';
            if (trainingContainer) trainingContainer.innerHTML = '';
            if (certificatesContainer) certificatesContainer.innerHTML = '';
            if (skillsContainer) skillsContainer.innerHTML = '';
            if (otherFilesContainer) otherFilesContainer.innerHTML = '';

            educationCounter = 0;
            workExperienceCounter = 0;
            trainingCounter = 0;
            certificatesCounter = 0;
            skillsCounter = 0;
            otherFileCounter = 0;

            // Ensure checkboxes are unchecked and sections are visible
            if (noEducationCheckbox) noEducationCheckbox.checked = false;
            if (noWorkExperienceCheckbox) noWorkExperienceCheckbox.checked = false;
            if (noTrainingCheckbox) noTrainingCheckbox.checked = false;
            if (noCertificatesCheckbox) noCertificatesCheckbox.checked = false;
            if (noSkillsCheckbox) noSkillsCheckbox.checked = false;
            if (noOtherFileCheckbox) noOtherFileCheckbox.checked = false;

            // Call toggleDynamicSection for each, ensuring it handles nulls internally
            toggleDynamicSection('education', false);
            toggleDynamicSection('workExperience', false);
            toggleDynamicSection('training', false);
            toggleDynamicSection('certificates', false);
            toggleDynamicSection('skills', false);
            toggleDynamicSection('otherFiles', false);

            if (addEmployeeModal) {
                addEmployeeModal.classList.remove('d-none'); // This should make the modal visible
                const modalContentScrollable = addEmployeeModal.querySelector('.custom-modal-content');
                if (modalContentScrollable) {
                    modalContentScrollable.scrollTop = 0; // Scroll the content area to the top
                }
            } else {
                console.error('Error: addEmployeeModal element not found!');
            }
        });
    } else {
        console.error('Error: addEmployeeBtn element not found!'); // Debugging log
    }

    // Hide Add Employee Modal
    if (cancelAddEmployeeBtn) {
        cancelAddEmployeeBtn.addEventListener('click', () => {
            if (addEmployeeModal) {
                addEmployeeModal.classList.add('d-none');
            }
        });
    }

    // Function to generate a random password
    function generateRandomPassword() {
        const lower = "abcdefghijklmnopqrstuvwxyz";
        const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const numbers = "0123456789";
        const symbols = "!@#$%^&*()_+";
        const allChars = lower + upper + numbers + symbols;
        const passwordLength = 12;

        let password = "";

        // Ensure at least one character from each category
        password += lower.charAt(Math.floor(Math.random() * lower.length));
        password += upper.charAt(Math.floor(Math.random() * upper.length));
        password += numbers.charAt(Math.floor(Math.random() * numbers.length));
        password += symbols.charAt(Math.floor(Math.random() * symbols.length));

        // Fill the remaining characters randomly
        for (let i = 4; i < passwordLength; i++) {
            password += allChars.charAt(Math.floor(Math.random() * allChars.length));
        }

        // Shuffle the password so the first 4 characters aren't predictable
        password = password.split('').sort(() => 0.5 - Math.random()).join('');

        if (employeePasswordInput) {
            employeePasswordInput.value = password;
        }

        return password;
    }

    // Event listener for profile picture file input
    if (profilePictureInput && profilePicturePreview) {
        profilePictureInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    profilePicturePreview.src = e.target.result;
                    profilePicturePreview.classList.remove('d-none'); // show the image
                };
                reader.readAsDataURL(file);
            } else {
                // If no file selected, reset to default and hide if needed
                profilePicturePreview.src = '';
                profilePicturePreview.classList.remove('d-none');
            }
        });
    }

    // Function to calculate age from birthday
    if (employeeBirthdayInput && employeeAgeInput) { // Ensure both elements exist
        employeeBirthdayInput.addEventListener('change', function() {
            const birthday = new Date(this.value);
            if (isNaN(birthday.getTime())) { // Use getTime() for robust NaN check
                employeeAgeInput.value = '';
                return;
            }
            const today = new Date();
            let age = today.getFullYear() - birthday.getFullYear();
            const m = today.getMonth() - birthday.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthday.getDate())) {
                age--;
            }

            if (age < 18) {
                showAlertModal('Age Restriction', 'Employee must be at least 18 years old.');
                employeeAgeInput.value = '';
                employeeBirthdayInput.value = ''; // Clear birthday as well
            } else {
                employeeAgeInput.value = age >= 0 ? age : ''; // Ensure age is not negative
            }
        });
    }

    // Real-time Shift Time Validation
    if (employeeShiftStartInput && employeeShiftEndInput) {
        const validateShiftTimes = () => {
            const startTime = employeeShiftStartInput.value;
            const endTime = employeeShiftEndInput.value;

            if (startTime && endTime) { // Only validate if both are filled
                const startDateTime = new Date(`2000/01/01 ${startTime}`);
                const endDateTime = new Date(`2000/01/01 ${endTime}`);

                if (endDateTime <= startDateTime) {
                    showAlertModal('Invalid Shift Times', 'End shift time cannot be earlier than or the same as the start shift time.');
                    employeeShiftEndInput.value = ''; // Clear end time
                    employeeShiftEndInput.focus();
                    return false;
                }
            }
            return true;
        };

        employeeShiftStartInput.addEventListener('change', validateShiftTimes);
        employeeShiftEndInput.addEventListener('change', validateShiftTimes);
    }

    // Real-time Date Joined Validation
    if (employeeDateJoinedInput) {
        employeeDateJoinedInput.addEventListener('change', function() {
            if (!isDateNotInFuture(this.value, 'Date Joined')) {
                this.value = ''; // Clear the input if it's a future date
                employeeQRcodeIdInput.value = '';
            }
            generateRandomQRcodeId();
        });
    }

    // Function to validate Philippine mobile contact number (09xxxxxxxxx format)
    function isValidPhilippineContact(number) {
        const mobileRegex = /^09\d{9}$/; // Starts with 09, followed by 9 digits
        return mobileRegex.test(number);
    }

    // Helper function to check if a date is not in the future
    function isDateNotInFuture(dateString, fieldLabel) {
        if (!dateString) return true; // Allow empty date if not required, validation handles required
        const inputDate = new Date(dateString);
        const today = new Date();

        if (inputDate > today) {
            showAlertModal('Invalid Date', `${fieldLabel} cannot be a future date.`);
            return false;
        }
        return true;
    }

    // Function to generate QR ID
    function generateRandomQRcodeId() {
        if (employeeDateJoinedInput && employeeQRcodeIdInput) {
            const dateJoined = employeeDateJoinedInput.value;
            if (!dateJoined) return; // If no date joined yet, do nothing

            const yearJoined = new Date(dateJoined).getFullYear();
            const randomNum = Math.floor(Math.random() * 10000); 
            const uniqueNumbers = String(randomNum).padStart(4, '0');
            employeeQRcodeIdInput.value = `EMP${yearJoined}${uniqueNumbers}`;
        }
    }

    // Helper function to toggle visibility and required status of dynamic sections
    function toggleDynamicSection(sectionName, hide) {
        const container = document.getElementById(`${sectionName}Container`);
        const addButtonId = `add${sectionName.charAt(0).toUpperCase() + sectionName.slice(1)}Btn`;
        const addButton = document.getElementById(addButtonId);

        if (hide) {
            if (container) container.classList.add('d-none');
            if (addButton) addButton.disabled = true; // Disable add button
            // Remove required attribute from all inputs in this section
            if (container) {
                container.querySelectorAll('input, select, textarea').forEach(input => {
                    input.removeAttribute('required');
                });
            }
        } else {
            if (container) container.classList.remove('d-none');
            if (addButton) addButton.disabled = false; // Enable add button
            // Required attributes will be added when fields are dynamically created
        }
    }

    // Helper function to validate if a dynamic section has at least one filled required field
    function validateDynamicSection(containerId, checkboxId, fieldNames) {
        const checkbox = document.getElementById(checkboxId);
        const container = document.getElementById(containerId);
        const sectionNameMap = {
        'education': 'educational background',
        'workExperience': 'work experience',
        'training': 'training/seminar/workshop',
        'certificates': 'certificate',
        'skills': 'skill',
        'otherFiles': 'other file'
        };
        const rawSectionName = containerId.replace('Container', '');
        const formattedSectionName = sectionNameMap[rawSectionName] || rawSectionName.replace(/([A-Z])/g, ' $1').toLowerCase();

        if (checkbox && !checkbox.checked && container && container.children.length === 0) {
            showAlertModal('Missing Information', `Please add at least one entry for ${formattedSectionName} or tick the 'No ${formattedSectionName} to add' checkbox.`);
            return false;
        }

        // If checkbox is ticked and no children, or checkbox is not ticked and children exist, proceed to field validation
        if (checkbox && checkbox.checked) {
            return true; // Checkbox is ticked and no entries, or entries were cleared - valid for this scenario
        }

        // If checkbox is NOT ticked, then we expect fields to be present and filled
        let allFieldsValid = true;
        Array.from(container.children).forEach(card => {
            fieldNames.forEach(field => {
                const input = card.querySelector(`[name$="[${field}]"]`);
                if (input && input.hasAttribute('required') && !input.value.trim()) {
                    allFieldsValid = false;
                    input.focus();
                }
            });
        });

        if (!allFieldsValid) {
            showAlertModal('Missing Information', `Please fill in all required fields in the ${formattedSectionName} section.`);
            return false;
        }
        return true;
    }

    // Template for Education Section
    function createEducationField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="education" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-6">
                    <label for="educationSchool${index}" class="form-label text-text-dark-grey fw-medium">School <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="educationSchool${index}" name="education[${index}][school]" required>
                </div>
                <div class="col-md-6">
                    <label for="educationAcademicYear${index}" class="form-label text-text-dark-grey fw-medium">Academic Year <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="educationAcademicYear${index}" name="education[${index}][academic_year]" placeholder="e.g., 2018-2022" required>
                </div>
                <div class="col-12">
                    <label for="educationCourseStrand${index}" class="form-label text-text-dark-grey fw-medium">Course/Strand <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="educationCourseStrand${index}" name="education[${index}][course_strand]" placeholder="If junior high school, put N/A" required>
                </div>
                <div class="col-12">
                    <label for="educationNotes${index}" class="form-label text-text-dark-grey fw-medium">Special notes (e.g., major, minor, awards)</label>
                    <textarea class="form-control" id="educationNotes${index}" name="education[${index}][special_notes]" rows="2"></textarea>
                </div>
            </div>
        `;
        return div;
    }

    // Template for Work Experience Section
    function createWorkExperienceField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="workExperience" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-6">
                    <label for="workExpCompany${index}" class="form-label text-text-dark-grey fw-medium">Company <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="workExpCompany${index}" name="work_experience[${index}][company]" required>
                </div>
                <div class="col-md-6">
                    <label for="workExpLength${index}" class="form-label text-text-dark-grey fw-medium">Length of Service <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="workExpLength${index}" name="work_experience[${index}][length_of_service]" placeholder="e.g., 2012-2016" required>
                </div>
                <div class="col-12">
                    <label for="workExpPosition${index}" class="form-label text-text-dark-grey fw-medium">Position <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="workExpPosition${index}" name="work_experience[${index}][position]" required>
                </div>
                <div class="col-12">
                    <label for="workExpDuties${index}" class="form-label text-text-dark-grey fw-medium">Duties & Notable Achievements</label>
                    <textarea class="form-control" id="workExpDuties${index}" name="work_experience[${index}][duties_achievements]" rows="3"></textarea>
                </div>
            </div>
        `;
        return div;
    }

    // Template for Training Section
    function createTrainingField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="training" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-8">
                    <label for="trainingName${index}" class="form-label text-text-dark-grey fw-medium">Training Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="trainingName${index}" name="training[${index}][training_name]" required>
                </div>
                <div class="col-md-4">
                    <label for="trainingDate${index}" class="form-label text-text-dark-grey fw-medium">Date Attended <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="trainingDate${index}" name="training[${index}][date_attended]" required>
                </div>
                <div class="col-12">
                    <label for="trainingNotes${index}" class="form-label text-text-dark-grey fw-medium">Notes</label>
                    <textarea class="form-control" id="trainingNotes${index}" name="training[${index}][notes]" rows="2"></textarea>
                </div>
            </div>
        `;
        setTimeout(() => { // Use a small timeout to ensure the element is in the DOM
            const trainingDateInput = div.querySelector(`#trainingDate${index}`);
            if (trainingDateInput) {
                trainingDateInput.addEventListener('change', function() {
                    if (!isDateNotInFuture(this.value, 'Date Attended')) {
                        this.value = ''; // Clear the input if it's a future date
                    }
                });
            }
        }, 0);
        return div;
    }

    // Template for Certificates Section
    function createCertificateField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="certificates" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-md-8">
                    <label for="certificateName${index}" class="form-label text-text-dark-grey fw-medium">Certificate Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="certificateName${index}" name="certificates[${index}][certificate_name]" required>
                </div>
                <div class="col-md-4">
                    <label for="certificateDate${index}" class="form-label text-text-dark-grey fw-medium">Date Issued <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="certificateDate${index}" name="certificates[${index}][date_issued]" required>
                </div>
                <div class="col-12">
                    <label for="certificateIssuingBody${index}" class="form-label text-text-dark-grey fw-medium">Issuing Body</label>
                    <input type="text" class="form-control" id="certificateIssuingBody${index}" name="certificates[${index}][issuing_body]">
                </div>
            </div>
        `;
        setTimeout(() => { // Use a small timeout to ensure the element is in the DOM
            const certificateDateInput = div.querySelector(`#certificateDate${index}`);
            if (certificateDateInput) {
                certificateDateInput.addEventListener('change', function() {
                    if (!isDateNotInFuture(this.value, 'Date Issued')) {
                        this.value = ''; // Clear the input if it's a future date
                    }
                });
            }
        }, 0);
        return div;
    }

    // Template for Skills Section
    function createSkillField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="skills" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-12"> <!-- Changed to col-12 as only one field now -->
                    <label for="skillName${index}" class="form-label text-text-dark-grey fw-medium">Skill Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="skillName${index}" name="skills[${index}][skill_name]" required>
                </div>
            </div>
        `;
        return div;
    }

    function createOtherFileField(index) {
        const div = document.createElement('div');
        div.className = 'card p-3 mb-3';
        div.innerHTML = `
            <button type="button" class="remove-section-btn" data-section="otherFiles" data-index="${index}"><i class="fas fa-times"></i></button>
            <div class="row g-2">
                <div class="col-12">
                    <label for="otherFileName${index}" class="form-label text-text-dark-grey fw-medium">
                        Type of File <span class="text-danger">*</span>
                    </label>

                    <input class="form-control" list="fileOptions${index}" id="otherFileName${index}" name="otherFiles[${index}][otherFile_name]" required placeholder="Select or type file type">

                    <datalist id="fileOptions${index}">
                        <option value="Birth Certificate">
                        <option value="Marriage Certificate">
                        <option value="Valid IDs">
                        <option value="Employment Contract">
                        <option value="NDA / Company Agreements">
                        <option value="Performance Evaluations">
                        <option value="Disciplinary Actions">
                        <option value="Incident Reports">
                        <option value="Medical Certificate">
                        <option value="Merit / Commendation Letters">
                        <option value="Promotion Documents">
                    </datalist>
                </div>
                <div class="col-12">
                    <label for="otherFileUpload${index}" class="form-label text-text-dark-grey fw-medium">Supporting Document <span class="text-danger">*</span> </label>
                    <input type="file" class="form-control" id="otherFileUpload${index}" name="otherFiles[${index}][otherFile_upload]" required>
                </div>
            </div>
        `;
        return div;
    }

    // Event listeners for Add buttons
    if (addEducationBtn) {
        addEducationBtn.addEventListener('click', () => {
            const newField = createEducationField(educationCounter++);
            if (educationContainer) educationContainer.appendChild(newField);
            // Add event listener for the new remove button
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addWorkExperienceBtn) {
        addWorkExperienceBtn.addEventListener('click', () => {
            const newField = createWorkExperienceField(workExperienceCounter++);
            if (workExperienceContainer) workExperienceContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addTrainingBtn) {
        addTrainingBtn.addEventListener('click', () => {
            const newField = createTrainingField(trainingCounter++);
            if (trainingContainer) trainingContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addCertificateBtn) {
        addCertificateBtn.addEventListener('click', () => {
            const newField = createCertificateField(certificatesCounter++);
            if (certificatesContainer) certificatesContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addSkillBtn) {
        addSkillBtn.addEventListener('click', () => {
            const newField = createSkillField(skillsCounter++);
            if (skillsContainer) skillsContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }
    if (addOtherFileBtn) {
        addOtherFileBtn.addEventListener('click', () => {
            const newField = createOtherFileField(otherFileCounter++);
            if (otherFilesContainer) otherFilesContainer.appendChild(newField);
            newField.querySelector('.remove-section-btn')?.addEventListener('click', removeDynamicSection);
        });
    }

    // Function to remove a dynamic section
    function removeDynamicSection(event) {
        const button = event.target.closest('.remove-section-btn');
        const sectionDiv = button?.closest('.card'); // Use optional chaining
        if (sectionDiv) {
            sectionDiv.remove();
        }
    }

    // Map each section to its elements and counter
    const sections = [
        { addBtn: addEducationBtn, checkbox: noEducationCheckbox, container: educationContainer, counter: 'educationCounter' },
        { addBtn: addWorkExperienceBtn, checkbox: noWorkExperienceCheckbox, container: workExperienceContainer, counter: 'workExperienceCounter' },
        { addBtn: addTrainingBtn, checkbox: noTrainingCheckbox, container: trainingContainer, counter: 'trainingCounter' },
        { addBtn: addCertificateBtn, checkbox: noCertificatesCheckbox, container: certificatesContainer, counter: 'certificatesCounter' },
        { addBtn: addSkillBtn, checkbox: noSkillsCheckbox, container: skillsContainer, counter: 'skillsCounter' },
        { addBtn: addOtherFileBtn, checkbox: noOtherFileCheckbox, container: otherFilesContainer, counter: 'otherFileCounter' }
    ];

    // Attach behavior for all sections
    sections.forEach(({ addBtn, checkbox, container, counter }) => {
        if (!addBtn || !checkbox || !container) return;

        // When Add button clicked → uncheck checkbox and show container
        addBtn.addEventListener('click', () => {
            checkbox.checked = false;
            container.style.visibility = 'visible';
        });

        // When checkbox toggled → hide/reset container
        checkbox.addEventListener('change', () => {
            if (checkbox.checked) {
                container.style.visibility = 'hidden';
                container.innerHTML = '';
                window[counter] = 0; // reset counter dynamically
            } 
        });
    });

    // Handle Add Employee Form Submission
    if (addEmployeeForm) {
        addEmployeeForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            // Client-side validation for required fields
            const requiredInputs = addEmployeeForm.querySelectorAll('[required]');
            for (const input of requiredInputs) {
                // Check if the input is visible (not part of a hidden dynamic section)
                if (input.offsetParent !== null && !input.value) { // offsetParent checks visibility
                    showAlertModal(`Missing Information', 'Please fill in the required field: ${input.previousElementSibling?.textContent?.replace(' *', '') || input.id}`);
                    input.focus();
                    return;
                }
            }

            // Validate email and confirm email match
            if (employeeWorkEmailInput && employeeConfirmWorkEmailInput) {
                if (employeeWorkEmailInput.value !== employeeConfirmWorkEmailInput.value) {
                    showAlertModal('Email Mismatch', 'Work Email and Confirm Work Email do not match. Please ensure they are identical.');
                    employeeConfirmWorkEmailInput.focus();
                    return;
                }
            }

            if (employeeContactInput && !isValidPhilippineContact(employeeContactInput.value.trim())) {
                showAlertModal('Invalid Contact Number', 'Please enter a valid Philippine mobile (e.g., 09xxxxxxxxx) number.');
                employeeContactInput.focus();
                return; // Stop form submission
            }

            if (!validateDynamicSection('educationContainer', 'noEducationCheckbox', ['school', 'academic_year', 'course_strand'])) return;
            if (!validateDynamicSection('workExperienceContainer', 'noWorkExperienceCheckbox', ['company', 'length_of_service', 'position'])) return;
            if (!validateDynamicSection('trainingContainer', 'noTrainingCheckbox', ['training_name'])) return;
            if (!validateDynamicSection('certificatesContainer', 'noCertificatesCheckbox', ['certificate_name'])) return;
            if (!validateDynamicSection('skillsContainer', 'noSkillsCheckbox', ['skill_name'])) return;
            if (!validateDynamicSection('otherFilesContainer', 'noOtherFileCheckbox', ['otherFile_name'])) return;

            const formData = new FormData(addEmployeeForm);

            // Add profile picture if selected
            if (profilePictureInput && profilePictureInput.files[0]) {
                formData.append('profile_picture', profilePictureInput.files[0]);
            }

            // Collect dynamic section data manually to ensure correct array structure and append as JSON strings if the section is NOT unchecked
            const collectDynamicData = (containerId, fieldNames) => {
                const container = document.getElementById(containerId);
                const items = [];
                // Only collect if the container is visible (not hidden by checkbox)
                if (container && container.offsetParent !== null) { // Check if container exists and is visible
                    Array.from(container.children).forEach(card => {
                        const item = {};
                        let isValid = true; // Assume valid until a required sub-field is empty
                        // Inside collectDynamicData function, within the fieldNames.forEach loop:
                        fieldNames.forEach(field => {
                            const input = card.querySelector(`[name$="[${field}]"]`);
                            if (input) {
                                // If a sub-field is marked required and is empty, invalidate the item
                                if (input.hasAttribute('required') && !input.value.trim()) { // Changed !input.value to !input.value.trim() for robust check
                                    isValid = false;
                                }
                                if (input.type === 'date' && !isDateNotInFuture(input.value, input.previousElementSibling?.textContent?.replace(' *', '') || input.id)) {
                                    isValid = false; // Mark the card as invalid if date is in future
                                    input.focus(); // Focus on the problematic input
                                }
                                item[field] = input.value.trim(); // Trim whitespace
                            }
                        });
                        if (isValid) {
                            items.push(item);
                        }
                    });
                }
                return items;
            };

            // Collect data for each dynamic section if not unchecked
            if (noEducationCheckbox && !noEducationCheckbox.checked) {
                const educationData = collectDynamicData('educationContainer', ['school', 'academic_year', 'course_strand', 'special_notes']);
                if (educationData.length > 0) formData.append('education_data', JSON.stringify(educationData));
            }
            if (noWorkExperienceCheckbox && !noWorkExperienceCheckbox.checked) {
                const workExperienceData = collectDynamicData('workExperienceContainer', ['company', 'length_of_service', 'position', 'duties_achievements']);
                if (workExperienceData.length > 0) formData.append('work_experience_data', JSON.stringify(workExperienceData));
            }
            if (noTrainingCheckbox && !noTrainingCheckbox.checked) {
                const trainingData = collectDynamicData('trainingContainer', ['training_name', 'date_attended', 'notes']);
                if (trainingData.length > 0) formData.append('training_data', JSON.stringify(trainingData));
            }
            if (noCertificatesCheckbox && !noCertificatesCheckbox.checked) {
                const certificatesData = collectDynamicData('certificatesContainer', ['certificate_name', 'issuing_body', 'date_issued']);
                if (certificatesData.length > 0) formData.append('certificates_data', JSON.stringify(certificatesData));
            }
            if (noSkillsCheckbox && !noSkillsCheckbox.checked) {
                const skillsData = collectDynamicData('skillsContainer', ['skill_name']);
                if (skillsData.length > 0) formData.append('skills_data', JSON.stringify(skillsData));
            }
            if (noOtherFileCheckbox && !noOtherFileCheckbox.checked) {
    const otherFilesData = collectDynamicData('otherFilesContainer', ['otherFile_name']);
    if (otherFilesData.length > 0) {
        otherFilesData.forEach((item, idx) => {
            // Append each file input and its metadata to FormData
            const fileInput = document.querySelector(`#otherFileUpload${idx}`);
            if (fileInput && fileInput.files[0]) {
                formData.append(`otherFiles[${idx}][file_upload]`, fileInput.files[0]);
            }
            formData.append(`otherFiles[${idx}][file_name]`, item.otherFile_name);
        });
    }
}


            try {
                // Disable button and show spinner
                const submitBtn = document.getElementById('submitAddEmployeeBtn');
                if (submitBtn) {
                    submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...`;
                    submitBtn.disabled = true;
                }

                const response = await fetch('add_employee.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    const employeeEmail = formData.get('work_email');
                    const successMessage = `Employee has been successfully added! Login credentials have been sent to ${employeeEmail}.`

                    if (result.new_qrcode && result.new_qrcode !== formData.get('qrcode_id')) {
                        showAlertModal('QR Code Changed', `The original QR Code was taken. A new QR Code (${result.new_qrcode}) has been generated.`);
                    } else {
                        showAlertModal('Employee Added Successfully', successMessage);
                    }

                    if (addEmployeeModal) {
                        addEmployeeModal.classList.add('d-none'); // Hide modal
                    }
                    addEmployeeForm.reset(); // Clear form
                    // Optionally, update employee count on dashboard or reload relevant sections
                } else {
                    if (result.message && result.message.includes('different email')) {
                        showAlertModal('Duplicate Email', result.message);
                    } else if (result.message && result.message.includes('Branch Manager')) {
                        showAlertModal('Cannot Add Branch Manager', result.message);
                    } else {
                        console.error('Error adding employee:', result.message);
                    }
                }
            } catch (error) {
                console.error('Error adding employee:', error);
                showAlertModal('Error', 'An error occurred while adding the employee. Please check browser console for details.');
            } finally {
                // Re-enable button
                const submitBtn = document.getElementById('submitAddEmployeeBtn');
                if (submitBtn) {
                    submitBtn.innerHTML = `Add`;
                    submitBtn.disabled = false;
                }
                loadEmployees();
            }
        });
    }
});
