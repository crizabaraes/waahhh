<?php
require_once 'authentication/db_connect.php'; // Your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'employees' => [], 'message' => ''];
$email = isset($_GET['work_email']) ? $_GET['work_email'] : null;

try {
   if ($email) {
        // Fetch single employee by work_email
        $sql = "SELECT * FROM employees WHERE work_email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
    } else {
        // Fetch all employees
        $sql = "SELECT * FROM employees ORDER BY full_name ASC";
        $stmt = $conn->prepare($sql);
    }

    if (!$stmt) {
        throw new Exception('Prepare statement failed: ' . $conn->error);
    }

    if (!$stmt->execute()) {
        throw new Exception('Execute statement failed: ' . $stmt->error);
    }

    $result = $stmt->get_result();
    $employees = [];
    while ($row = $result->fetch_assoc()) {
        $employeeId = $row['id'];

        // Fetch related data for this employee
        $row['education'] = [];
        $eduSql = "SELECT * FROM employee_education WHERE employee_id = ?";
        $eduStmt = $conn->prepare($eduSql);
        $eduStmt->bind_param("s", $employeeId);
        $eduStmt->execute();
        $eduRes = $eduStmt->get_result();
        while ($eduRow = $eduRes->fetch_assoc()) {
            $row['education'][] = $eduRow;
        }
        $eduStmt->close();

        $row['work_experience'] = [];
        $workSql = "SELECT * FROM employee_work_experience WHERE employee_id = ?";
        $workStmt = $conn->prepare($workSql);
        $workStmt->bind_param("s", $employeeId);
        $workStmt->execute();
        $workRes = $workStmt->get_result();
        while ($workRow = $workRes->fetch_assoc()) {
            $row['work_experience'][] = $workRow;
        }
        $workStmt->close();

        $row['trainings'] = [];
        $trainSql = "SELECT * FROM employee_trainings WHERE employee_id = ?";
        $trainStmt = $conn->prepare($trainSql);
        $trainStmt->bind_param("s", $employeeId);
        $trainStmt->execute();
        $trainRes = $trainStmt->get_result();
        while ($trainRow = $trainRes->fetch_assoc()) {
            $row['trainings'][] = $trainRow;
        }
        $trainStmt->close();

        $row['certificates'] = [];
        $certSql = "SELECT * FROM employee_certificates WHERE employee_id = ?";
        $certStmt = $conn->prepare($certSql);
        $certStmt->bind_param("s", $employeeId);
        $certStmt->execute();
        $certRes = $certStmt->get_result();
        while ($certRow = $certRes->fetch_assoc()) {
            $row['certificates'][] = $certRow;
        }
        $certStmt->close();

        $row['skills'] = [];
        $skillSql = "SELECT * FROM employee_skills WHERE employee_id = ?";
        $skillStmt = $conn->prepare($skillSql);
        $skillStmt->bind_param("s", $employeeId);
        $skillStmt->execute();
        $skillRes = $skillStmt->get_result();
        while ($skillRow = $skillRes->fetch_assoc()) {
            $row['skills'][] = $skillRow;
        }
        $skillStmt->close();

        $employees[] = $row;
    }

    $stmt->close();

    $response['success'] = true;
    $response['employees'] = $employees;

} catch (Exception $e) {
    $response['message'] = 'Error fetching employee list: ' . $e->getMessage();
    error_log("get_employee_details.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
