<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'events' => []];

// Fetch events ordered by event_date ascending (earliest first)
$sql = "SELECT id, title, details, post_date, event_date FROM events ORDER BY event_date ASC";
$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $response['events'][] = $row;
        }
        $response['success'] = true;
    } else {
        $response['message'] = 'No events found.';
        $response['success'] = true; // Still success, just no data
    }
} else {
    $response['message'] = 'Database query failed: ' . $conn->error;
}

$conn->close();
echo json_encode($response);
?>
