<?php
require_once 'authentication/db_connect.php';
header('Content-Type: application/json');

if (!isset($_GET['employee_id'])) {
    echo json_encode(['success' => false, 'message' => 'employee_id is required']);
    exit;
}

$employee_id = $_GET['employee_id'];

$stmt = $conn->prepare("SELECT fingerprint_id FROM employees WHERE id = ?");
$stmt->bind_param("s", $employee_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row && $row['fingerprint_id'] !== null) {
    echo json_encode(['success' => true, 'fingerprint_id' => (int)$row['fingerprint_id']]);
} else {
    echo json_encode(['success' => true, 'fingerprint_id' => null]);
}

$stmt->close();
$conn->close();
?>
