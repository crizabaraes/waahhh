<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $details = $_POST['details'] ?? '';
    $event_date = $_POST['event_date'] ?? ''; // New field for event date

    if (empty($title) || empty($details) || empty($event_date)) {
        $response['message'] = 'Missing required fields: Title, Details, or Event Date.';
    } else {
        // Prepare an insert statement
        $stmt = $conn->prepare("INSERT INTO events (title, details, event_date, post_date) VALUES (?, ?, ?, NOW())");

        if ($stmt) {
            $stmt->bind_param("sss", $title, $details, $event_date); // 'sss' for string, string, string (date is string for bind_param)

            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Event added successfully.';
            } else {
                $response['message'] = 'Failed to add event: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $response['message'] = 'Database prepare error: ' . $conn->error;
        }
    }
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>
