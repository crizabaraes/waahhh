<?php
include 'authentication/db_connect.php';

// Get email from POST
if (isset($_POST['email'])) {
    $email = trim($_POST['email']);

    // Prepare and execute the update query securely
    $stmt = $conn->prepare("UPDATE login_credentials SET agreement = 1 WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(["success" => true, "message" => "Agreement status updated."]);
        } else {
            echo json_encode(["success" => false, "message" => "No matching user found."]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Database error."]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "Email not provided."]);
}

$conn->close();
?>
