<?php
require_once 'authentication/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'pending_peer_evaluations' => [], 'current_quarter' => '', 'message' => ''];

$email = $_GET['email'] ?? null; // logged-in employee email

try {
    if (!$email) {
        throw new Exception("Email is required");
    }

    // 1️⃣ Get position from login_credentials
    $stmt = $conn->prepare("SELECT position FROM login_credentials WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $posResult = $stmt->get_result();

    if (!$posRow = $posResult->fetch_assoc()) {
        throw new Exception("User not found in login_credentials");
    }

    $position = strtolower(trim($posRow['position'] ?? ''));

    if ($position !== 'employee') {
        throw new Exception("Not an employee"); // Only employees fetch peers
    }

    // 2️⃣ Get employee info from employees table
    $stmt2 = $conn->prepare("SELECT id, branch FROM employees WHERE work_email = ? LIMIT 1");
    $stmt2->bind_param("s", $email);
    $stmt2->execute();
    $empResult = $stmt2->get_result();

    if (!$empRow = $empResult->fetch_assoc()) {
        throw new Exception("Employee not found in employees table");
    }

    $employeeId = $empRow['id'];
    $branch = $empRow['branch'];

    // 3️⃣ Determine current quarter
    $currentMonth = (int)date('n');
    $currentYear = (int)date('Y');

    if ($currentMonth <= 3) $currentQuarterName = "Q4-" . ($currentYear - 1);
    elseif ($currentMonth <= 6) $currentQuarterName = "Q1-{$currentYear}";
    elseif ($currentMonth <= 9) $currentQuarterName = "Q2-{$currentYear}";
    else $currentQuarterName = "Q3-{$currentYear}";

    $response['current_quarter'] = $currentQuarterName;

    // 4️⃣ Fetch pending peer evaluations (same branch, exclude self, status = 'analysis_needed')
    $stmt3 = $conn->prepare("
        SELECT 
            e.id AS id,
            e.full_name,
            e.branch,
            lc.position,
            e.account_status,
            eval.evaluation_id,
            eval.quarter_name,
            eval.form_file_path,
            eval.analysis_data,
            eval.status
        FROM evaluations eval
        INNER JOIN employees e ON eval.employee_id = e.id
        LEFT JOIN login_credentials lc ON e.work_email = lc.email
        WHERE eval.quarter_name = ? 
        AND eval.status = 'analysis_needed'
        AND e.branch = ?
        AND e.id != ?
        AND NOT EXISTS (
            SELECT 1 
            FROM evaluation_responses er
            WHERE er.evaluation_id = eval.evaluation_id
                AND er.employee_id = ?
        )
        ORDER BY e.full_name ASC
    ");

    $stmt3->bind_param("ssss", $currentQuarterName, $branch, $employeeId, $employeeId);
    $stmt3->execute();
    $res = $stmt3->get_result();

    $pending_peer_evaluations = [];
    while ($row = $res->fetch_assoc()) {
        $pending_peer_evaluations[] = $row;
    }
    $stmt3->close();

    $response['success'] = true;
    $response['pending_peer_evaluations'] = $pending_peer_evaluations;

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
} finally {
    if ($conn) $conn->close();
}

echo json_encode($response);
