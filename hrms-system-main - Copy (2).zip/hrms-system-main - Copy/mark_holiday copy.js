document.addEventListener('DOMContentLoaded', function() {
    const hrEmail = localStorage.getItem('userEmail');
    const getCodeBtn = document.getElementById('getCodeBtn');
    const markHolidayBtn = document.getElementById('markHolidayBtn');
    const markHolidayForm = document.getElementById('markHolidayForm');
    const holidayType = document.getElementById('holidayType');
    const branchFieldWrapper = document.getElementById('branchFieldWrapper');
    const holidayDate = document.getElementById('holidayDate');
    const workShiftStart = document.getElementById('workShiftStart');
    const workShiftEnd = document.getElementById('workShiftEnd');
    const workShiftWrapper = document.getElementById('workShiftWrapper');

    // --- Toggle fields based on holiday type ---
    holidayType.addEventListener('change', function() {
        if (this.value === 'Store Closure') {
            branchFieldWrapper.classList.remove('d-none');
            workShiftWrapper.classList.add('d-none');
            document.getElementById('branch').required = true;
        } else {
            branchFieldWrapper.classList.add('d-none');
            workShiftWrapper.classList.remove('d-none');
            document.getElementById('branch').required = false;
        }
    });

    async function sendVerificationCode(email) {
        const code = Math.floor(100000 + Math.random() * 900000);
        const expiresAt = Date.now() + 30000; // 30s expiry

        // Store in localStorage
        localStorage.setItem('verificationCode', code);
        localStorage.setItem('verificationExpires', expiresAt);

        const subject = "HRMS Holiday Verification Code";
        const body = `
            <html><head><style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f9f9f9; padding: 20px; color: #333; }
            .container { max-width: 600px; margin: auto; background: #fff; border-radius: 8px; padding: 25px; box-shadow: 0 3px 8px rgba(0,0,0,0.1); }
            .header { font-size: 20px; font-weight: 600; color: #444; margin-bottom: 15px; }
            .code-box { font-size: 24px; letter-spacing: 2px; background: #f1f1f1; border: 1px solid #ddd; border-radius: 6px; padding: 10px 15px; text-align: center; margin: 20px 0; color: #222; font-weight: 700; }
            </style></head><body>
            <div class='container'>
                <div class='header'>Holiday Verification Code</div>
                <p>Use the verification code below to confirm this holiday entry (expires in 30 seconds):</p>
                <div class='code-box'>${code}</div>
                <p>Do not share this code with anyone.</p>
                <p>Best regards,<br>HRMS Team</p>
            </div>
            </body></html>`;

        const response = await fetch('send_verification_code.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ to: email, subject, body })
        });

        const result = await response.json();
        if (!result.success) throw new Error(result.message || "Failed to send email");
    }

    holidayDate.addEventListener('change', function() {
        const selectedDate = new Date(this.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate.getTime() < today.getTime()) {
            showAlertModal('Invalid Date', 'You cannot mark a day in the past.');
            this.value = '';
        }
    });

    function validateShiftTimes() {
        if (!workShiftStart.value || !workShiftEnd.value) return;

        const start = workShiftStart.value;
        const end = workShiftEnd.value;

        // Compare times (HH:MM)
        if (end <= start) {
            showAlertModal('Invalid Shift Times', 'End shift time cannot be earlier than or the same as the start shift time.');
            workShiftEnd.value = '';
        }
    }
    workShiftStart.addEventListener('change', validateShiftTimes);
    workShiftEnd.addEventListener('change', validateShiftTimes);

    // --- Get Code Button Click ---
    getCodeBtn.addEventListener('click', async function() {
        if (!hrEmail) {
            showAlertModal('Invalid Email', 'HR email not found. Please log in again.');
            return;
        }

        this.disabled = true; // disable immediately

        try {
            await sendVerificationCode(hrEmail);
            // re-enable after 30 seconds
            setTimeout(() => { getCodeBtn.disabled = false; }, 30000);
        } catch (error) {
            console.error(error);
            showAlertModal('Sending Failed', 'Error sending verification code. Please try again.');
            this.disabled = false; // re-enable on error
        }
    });

    // --- Form Submission Logic ---
    markHolidayForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const type = holidayType.value;
        const date = document.getElementById('holidayDate').value;
        const branch = document.getElementById('branch')?.value || '';
        const shiftStart = workShiftStart.value;
        const shiftEnd = workShiftEnd.value;
        const verification = document.getElementById('verificationCode').value.trim();

        // Validate code
        const storedCode = localStorage.getItem('verificationCode');
        const expiresAt = localStorage.getItem('verificationExpires');

        if ((shiftStart && !shiftEnd) || (!shiftStart && shiftEnd)) {
            showAlertModal('Missing Information', 'Please fill both Shift Start and Shift End.');
            return; // stop the form submission
        }

        if (
            !storedCode ||
            !expiresAt ||
            Date.now() > parseInt(expiresAt) ||
            verification !== storedCode
        ) {
            showAlertModal('Verification Error', 'Invalid or expired verification code.');
            return;
        }

        let formData = new FormData();
        formData.append('date', date);
        let endpoint = '';

        if (type === 'Store Closure') {
            endpoint = 'log_attendance.php?action=closed';
            formData.append('branch', branch);
        } else {
            endpoint = 'log_attendance.php?action=holiday';
            formData.append('type', type === 'Regular Holiday' ? 'REGULAR' : 'SPECIAL');
            if (shiftStart && shiftEnd) {
                formData.append('shift_start', shiftStart);
                formData.append('shift_end', shiftEnd);
            }
        }

        try {
            const res = await fetch(endpoint, { method: 'POST', body: formData });
            const result = await res.json();

            if (result.success) {
                showAlertModal('Update Successful', 'Holiday successfully recorded.');
                markHolidayForm.reset();
                localStorage.removeItem('verificationCode');
                localStorage.removeItem('verificationExpires');
            } else {
                console.error(result.message);
            }
        } catch (err) {
            showAlertModal('Server Error', 'Error connecting to server.');
        } finally {
            markHolidayBtn.disabled = false;
        }
    });


});
