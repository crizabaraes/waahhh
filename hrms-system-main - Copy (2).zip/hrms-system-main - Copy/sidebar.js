document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const searchToggleIcon = document.getElementById("searchToggleIcon");
    const searchGroup = document.querySelector(".input-group.rounded-pill");
    const dashboardTitle = document.querySelector("h2.fw-bold.mb-0");
    const notificationBtn = document.querySelector(".fa-bell").closest("button");
    const profileDropdown = document.querySelector("#userDropdown").closest(".dropdown");

    // Function to set sidebar state based on screen width
    function setSidebarState() {
        if (window.innerWidth <= 700) { // iPad and smaller screens (Bootstrap's 'md' breakpoint and below)
            if (sidebar) sidebar.classList.add('collapsed'); // Always collapsed on these screens
        } else { // Larger screens
            if (sidebar) sidebar.classList.remove('collapsed'); // Always open on larger screens
        }
    }

    // Function to toggle sidebar (for manual button click)
    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
    }

    // Event listener for desktop sidebar toggle
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }
    
    // Call setSidebarState initially on load to set the correct state
    setSidebarState();
    // Close sidebar on larger screens if it was collapsed on mobile
    window.addEventListener('resize', setSidebarState);

    const backButton = document.createElement("button");
    backButton.innerHTML = '<i class="fas fa-arrow-left fs-6"></i>';
    backButton.className = "btn btn-link text-text-dark-grey me-1 d-none";
    searchGroup.parentNode.insertBefore(backButton, searchGroup);

    function showSearch() {
        const headerParent = searchGroup.parentElement;
        headerParent.style.width = '100%';
        searchGroup.style.display = 'flex';
        searchGroup.style.flex = '1 1 auto';
        backButton.classList.remove('d-none');
        searchToggleIcon.classList.add('d-none');
        dashboardTitle.classList.add('d-none');
        notificationBtn.classList.add('d-none');
        profileDropdown.classList.add('d-none');
        }

    function hideSearch() {
        searchGroup.style.display = 'none';
        backButton.classList.add('d-none');
        searchToggleIcon.classList.remove('d-none');
        dashboardTitle.classList.remove('d-none');
        notificationBtn.classList.remove('d-none');
        profileDropdown.classList.remove('d-none');
        searchGroup.style.width = '380px';
        const headerParent = searchGroup.parentElement;
        headerParent.style.width = '';
    }

    searchToggleIcon.addEventListener("click", showSearch);
    backButton.addEventListener("click", hideSearch);

    // Handle resize
    window.addEventListener("resize", () => {
    if (window.innerWidth > 960) {
        searchGroup.style.display = "flex";
        searchToggleIcon.classList.add("d-none");
        backButton.classList.add("d-none");
        dashboardTitle.classList.remove("d-none");
        notificationBtn.classList.remove("d-none");
        profileDropdown.classList.remove("d-none");
    } else {
        hideSearch();
    }
    });

    const navLinks = document.querySelectorAll('.sidebar .nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href && href.startsWith('#')) {
                e.preventDefault();

                // Scroll to section
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }

            // Update active class
            navLinks.forEach(l => l.classList.remove('active-link'));
            this.classList.add('active-link');
        });
    });
});