<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'owner' => [], 'message' => ''];

$email = $_GET['email'] ?? null;
$old_password = trim($_POST['old_password'] ?? '');
$new_password = trim($_POST['new_password'] ?? '');

try {
    $conn->begin_transaction();

    // -------------------------
    // Handle password change
    // -------------------------
    if (!empty($old_password)) {
        $passCheckStmt = $conn->prepare("SELECT password FROM login_credentials WHERE email = ?");
        if (!$passCheckStmt) throw new Exception("Prepare failed: " . $conn->error);

        $passCheckStmt->bind_param("s", $email);
        if (!$passCheckStmt->execute()) throw new Exception("Execute failed: " . $passCheckStmt->error);

        $passRes = $passCheckStmt->get_result();
        if ($passRes->num_rows === 0) throw new Exception("Employee record not found.");

        $row = $passRes->fetch_assoc();
        $current_password = $row['password'];
        $email = $row['email'];
        $passCheckStmt->close();

        if (!password_verify($old_password, $current_password)) {
            throw new Exception("Old Password is incorrect.");
        }

        $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

        $updateLoginPass = $conn->prepare("UPDATE login_credentials SET password = ? WHERE email = ?");
        $updateLoginPass->bind_param("ss", $hashedPassword, $email);
        if (!$updateLoginPass->execute()) throw new Exception("Failed to update login password.");
        $updateLoginPass->close();
    }

    // -------------------------
    // Fetch owner info if email is provided
    // -------------------------
    if ($email) {
        $stmt = $conn->prepare("SELECT * FROM login_credentials WHERE email = ?");
        if (!$stmt) throw new Exception("Prepare failed: " . $conn->error);

        $stmt->bind_param("s", $email);
        if (!$stmt->execute()) throw new Exception("Execute failed: " . $stmt->error);

        $result = $stmt->get_result();
        $owner = [];
        while ($row = $result->fetch_assoc()) {
            $owner[] = $row;
        }
        $stmt->close();

        $response['owner'] = $owner;
    }

    $conn->commit();
    $response['success'] = true;

} catch (Exception $e) {
    if ($conn) $conn->rollback();
    $response['message'] = $e->getMessage();
    error_log("Error in owner/password update: " . $e->getMessage());
} finally {
    if ($conn) $conn->close();
}

echo json_encode($response);
