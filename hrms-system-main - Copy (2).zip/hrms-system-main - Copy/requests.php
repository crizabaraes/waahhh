<?php
require_once 'authentication/db_connect.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // -------------------------------
    // 1️⃣ Add a new request
    // -------------------------------
    case 'add_request':
        $employee_id    = $_POST['employee_id'] ?? '';
        $request_type   = $_POST['request_type'] ?? ''; // 'advance' or 'leave'
        $leave_type     = $_POST['leave_type'] ?? null;
        $advance_amount = (float)($_POST['advance_amount'] ?? 0.0);
        $leave_from = !empty($_POST['leave_from']) ? $_POST['leave_from'] : null;
        $leave_to   = !empty($_POST['leave_to'])   ? $_POST['leave_to']   : null;
        $explanation    = $_POST['explanation'] ?? null;
        $first_half = 'Half Leave (First Half)';
        $second_half = 'Half Leave (Second Half)';

        $proof = null;
        if (isset($_FILES['proof']) && $_FILES['proof']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/uploads/leave_proofs/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

            $filename = time() . '_' . basename($_FILES['proof']['name']); // unique filename
            $targetPath = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['proof']['tmp_name'], $targetPath)) {
                $proof = 'uploads/leave_proofs/' . $filename; // store relative path in DB
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to upload proof.']);
                exit();
            }
        }

        if (!$employee_id || !$request_type) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
            exit();
        }

        $shift_start = null;
        $shift_end = null;

        // Calculate first/second half if leave_type is half
        if ($leave_type === $first_half || $leave_type === $second_half) {
            $stmtShift = $conn->prepare("SELECT work_shift_start, work_shift_end FROM employees WHERE id = ?");
            $stmtShift->bind_param("s", $employee_id);
            $stmtShift->execute();
            $resShift = $stmtShift->get_result();
            if ($row = $resShift->fetch_assoc()) {
                $start = $row['work_shift_start']; // "HH:MM:SS"
                $end   = $row['work_shift_end'];   // "HH:MM:SS"

                // Convert to minutes
                list($sh, $sm) = explode(':', $start);
                list($eh, $em) = explode(':', $end);
                $startMinutes = $sh * 60 + $sm;
                $endMinutes = $eh * 60 + $em;
                $midMinutes = $startMinutes + ($endMinutes - $startMinutes) / 2;

                $midH = floor($midMinutes / 60);
                $midM = $midMinutes % 60;

                // First half
                if ($leave_type === $first_half) {
                    $shift_start = sprintf("%02d:%02d:00", $sh, $sm);
                    $shift_end   = sprintf("%02d:%02d:00", $midH, $midM);
                }
                // Second half
                else if ($leave_type === $second_half) {
                    $shift_start = sprintf("%02d:%02d:00", $midH, $midM);
                    $shift_end   = sprintf("%02d:%02d:00", $eh, $em);
                }
            }
            $stmtShift->close();
        }

        $stmt = $conn->prepare("
            INSERT INTO requests 
            (employee_id, request_type, leave_type, advance_amount, leave_from, leave_to, shift_start, shift_end, explanation, proof)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "ssssssssss",
            $employee_id,
            $request_type,
            $leave_type,
            $advance_amount,
            $leave_from,
            $leave_to,
            $shift_start,
            $shift_end,
            $explanation,
            $proof
        );

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Request submitted successfully.',
                'request_id' => $stmt->insert_id
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to submit request.']);
        }
        $stmt->close();
        exit();

    // -------------------------------
    // 2️⃣ Get all requests
    // -------------------------------
    case 'get_requests':
        $email = $_POST['email'] ?? '';
        $user_id = $_POST['employee_id'] ?? '';

        // Get position from login_credentials (owner check)
        $stmtLogin = $conn->prepare("SELECT LOWER(position) AS position FROM login_credentials WHERE email = ?");
        $stmtLogin->bind_param("s", $email);
        $stmtLogin->execute();
        $resLogin = $stmtLogin->get_result();
        $loginData = $resLogin->fetch_assoc();
        $loginPosition = $loginData['position'] ?? '';
        $stmtLogin->close();

        // Get position from employees table (HR, super admin, others)
        $stmtEmp = $conn->prepare("SELECT LOWER(position) AS position FROM employees WHERE id = ?");
        $stmtEmp->bind_param("s", $user_id);
        $stmtEmp->execute();
        $resEmp = $stmtEmp->get_result();
        $empData = $resEmp->fetch_assoc();
        $empPosition = $empData['position'] ?? '';
        $stmtEmp->close();

        // Base query
        $sql = "SELECT r.*, e.full_name, LOWER(e.position) AS emp_position
                FROM requests r
                JOIN employees e ON r.employee_id = e.id";

        $params = [];
        $types = '';

        // Determine which requests to show
        if ($loginPosition === 'owner' || $empPosition === 'human resources') {
        } else {
            // Normal employee sees only their own
            $sql .= " WHERE r.employee_id = ?";
            $params[] = $user_id;
            $types .= 's';
        }

        $sql .= " ORDER BY r.request_date DESC";

        $stmt = $conn->prepare($sql);

        // Bind parameters if needed
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        $requests = [];
        while ($row = $result->fetch_assoc()) {
            $requests[] = [
                'request_id'    => $row['request_id'],
                'employee_id'   => $row['employee_id'],
                'employee_name' => $row['full_name'],
                'request_type'  => $row['request_type'],
                'leave_type'    => $row['leave_type'],
                'advance_amount'=> $row['advance_amount'],
                'leave_from'    => $row['leave_from'],
                'leave_to'      => $row['leave_to'],
                'shift_start'   => $row['shift_start'],
                'shift_end'     => $row['shift_end'],
                'request_date'  => $row['request_date'],
                'explanation'   => $row['explanation'],
                'proof'         => $row['proof'],
                'status'        => $row['status'],
                'reason'        => $row['reason'],
            ];
        }

        echo json_encode(['success' => true, 'requests' => $requests]);
        $stmt->close();
        exit();

    case 'get_requests_count':
        $email = $_POST['email'] ?? '';
        $user_id = $_POST['employee_id'] ?? '';

        // Get login position
        $stmtLogin = $conn->prepare("SELECT LOWER(position) AS position FROM login_credentials WHERE email = ?");
        $stmtLogin->bind_param("s", $email);
        $stmtLogin->execute();
        $resLogin = $stmtLogin->get_result();
        $loginData = $resLogin->fetch_assoc();
        $loginPosition = $loginData['position'] ?? '';
        $stmtLogin->close();

        if (empty($user_id)) {
            $stmtEmp = $conn->prepare("SELECT id FROM employees WHERE work_email = ?");
            $stmtEmp->bind_param("s", $email);
            $stmtEmp->execute();
            $resEmp = $stmtEmp->get_result();
            $empData = $resEmp->fetch_assoc();
            $user_id = $empData['id'] ?? '';
            $stmtEmp->close();
        }

        // Base query
        $sql = "SELECT COUNT(*) AS pending_requests FROM requests";
        $params = [];
        $types = '';

        if ($loginPosition === 'owner' || $loginPosition === 'hr') {
            // Count all pending requests
            $sql .= " WHERE status = 'pending'";
        } else {
            // Count pending requests for this employee only
            $sql .= " WHERE status = 'pending' AND employee_id = ?";
            $params[] = $user_id;
            $types .= 's';
        }

        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $countData = $result->fetch_assoc();
        $totalPending = $countData['pending_requests'] ?? 0;

        echo json_encode(['success' => true, 'pending_requests' => $totalPending]);
        $stmt->close();
        exit();

    // -------------------------------
// 3️⃣ Update request status
// -------------------------------
case 'update_request':
    $request_id = $_POST['request_id'] ?? '';
    $status     = $_POST['status'] ?? ''; // 'approved' or 'rejected'
    $reason     = $_POST['reason'] ?? null;

    if (!$request_id || !in_array($status, ['approved','rejected'])) {
        echo json_encode(['success'=>false, 'message'=>'Missing or invalid fields.']);
        exit();
    }

    // 1️⃣ Update the request status and reason
    $stmt = $conn->prepare("UPDATE requests SET status = ?, reason = ? WHERE request_id = ?");
    $stmt->bind_param("ssi", $status, $reason, $request_id);
    $updated = $stmt->execute();
    $stmt->close();

    if (!$updated) {
        echo json_encode(['success'=>false, 'message'=>'Failed to update request.']);
        exit();
    }

    // 2️⃣ Get request details
    $stmt = $conn->prepare("SELECT employee_id, request_type, leave_type, leave_from, leave_to, advance_amount FROM requests WHERE request_id = ?");
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $reqData = $res->fetch_assoc();
    $stmt->close();

    if ($reqData && $status === 'approved') {
        $employee_id = $reqData['employee_id'];

        if ($reqData['request_type'] === 'leave' && !empty($reqData['leave_type'])) {
            $leave_type  = strtolower($reqData['leave_type']);
            $from        = $reqData['leave_from'];
            $to          = $reqData['leave_to'];

            $dayCount = 0;
            if ($from && $to) {
                $start = new DateTime($from);
                $end   = new DateTime($to);
                $dayCount = $start->diff($end)->days + 1;
            }

            $leave_type_clean = strtolower(str_replace(' leave', '', trim($reqData['leave_type'])));
            $balanceCol = '';
            switch ($leave_type_clean) {
                case 'vacation':
                    $balanceCol = 'vl_balance';
                    break;
                case 'sick':
                    $balanceCol = 'sl_balance';
                    break;
                case 'emergency':
                    $balanceCol = 'el_balance';
                    break;
                case 'solo_parent':
                    $balanceCol = 'spl_balance';
                    break;
            }

            if ($balanceCol && $dayCount > 0) {
                // Decrease the balance
                $stmt = $conn->prepare("UPDATE employees SET $balanceCol = GREATEST(0, $balanceCol - ?) WHERE id = ?");
                $stmt->bind_param("is", $dayCount, $employee_id);
                $stmt->execute();
                $stmt->close();
            }
        }

        // 3️⃣ If advance request, update advance_balance in employees table
        if ($reqData['request_type'] === 'advance') {
            $advanceAmount = (float)$reqData['advance_amount'];
            $stmt = $conn->prepare("UPDATE employees SET advance_balance = ? WHERE id = ?");
            $stmt->bind_param("ds", $advanceAmount, $employee_id); // decimal and string
            $stmt->execute();
            $stmt->close();
        }
    }

    echo json_encode(['success'=>true, 'message'=>'Request updated successfully.']);
    exit();


}
$conn->close();
