<?php
require 'authentication/db_connect.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];

    // First, get the filepath from the database to delete the file from the server
    $stmt = $conn->prepare("SELECT filepath FROM training_materials WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $filePath = $row['filepath'];
    $stmt->close();

    if ($filePath && file_exists($filePath)) {
        unlink($filePath);
    }

    // Now, delete the record from the database
    $stmt = $conn->prepare("DELETE FROM training_materials WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Training file deleted successfully!';
        } else {
            $response['message'] = 'Database error: ' . $stmt->error;
        }
        $stmt->close();
    } else {
        $response['message'] = 'Failed to prepare statement: ' . $conn->error;
    }
} else {
    $response['message'] = 'Invalid request.';
}

$conn->close();
header('Content-Type: application/json');
echo json_encode($response);
?>