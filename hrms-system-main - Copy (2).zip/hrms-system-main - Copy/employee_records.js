document.addEventListener('DOMContentLoaded', function() {
    const employeeRecordsList = document.getElementById('employeeRecordsList');
    const deactivatedRecordsList = document.getElementById('deactivatedRecordsList');

    window.loadEmployees = function() {
        fetch('get_employee_details.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const employees = data.employees;
                    const employeeRecordsList = document.getElementById('employeeRecordsList');
                    
                    if (employeeRecordsList) employeeRecordsList.innerHTML = '';

                    if (employees.length === 0) {
                        if (employeeRecordsList) employeeRecordsList.innerHTML = `<div class="text-center text-text-muted-grey py-3">No employees found.</div>`;
                        return;
                    }

                    employees
                        .sort((a, b) => {
                            if (a.account_status === b.account_status) {
                                return a.full_name.localeCompare(b.full_name);
                            }
                            return a.account_status === 'active' ? -1 : 1;
                        })
                        .filter(employee => employee.position.toLowerCase() !== "human resources")
                        .forEach(employee => {

                            // build iconHtml here (your existing logic)
                            let iconHtml = '';
                            if (employee.picture_file_path) {
                                iconHtml = `<img src="${employee.picture_file_path}" alt="Profile" class="rounded-circle empPicRes" style="width:40px;height:40px;object-fit:cover;">`;
                            } else {
                                const names = employee.full_name.trim().split(" ");
                                let initials = names.length > 1
                                    ? names[0][0] + names[names.length - 1][0]
                                    : names[0][0];
                                initials = initials.toUpperCase();

                                iconHtml = `<img src="https://placehold.co/40x40/5C7D8A/ffffff?text=${initials}" class="rounded-circle empInRes" style="width:40px;height:40px;object-fit:cover;">`;
                            }

                            const cardHtml = `
                                <a href="profile.html?employeeId=${employee.id}&status=${employee.account_status}" 
                                class="list-group-item list-group-item-action employee-card d-flex align-items-center justify-content-between p-3">
                                    <div class="d-flex align-items-start ress">
                                        <div class="icon-wrapper2 me-3" style="background-color: var(--primary-soft-blue); display:flex; align-items:center; justify-content:center; width:40px;height:40px;border-radius:50%;">
                                            ${iconHtml}
                                        </div>
                                        <div class="content-area">
                                            <h5 class="fw-semibold text-text-dark-grey d-flex align-items-center empNameRes">
                                                ${employee.full_name}
                                                ${employee.account_status === 'active' 
                                                    ? '<span class="active-indicator" title="Active"></span>'
                                                    : '<span class="deactivated-indicator" title="Deactivated"></span>'}
                                            </h5>
                                            <p class="small text-text-muted-grey mb-0 empBranchRes">${employee.branch}</p>
                                        </div>
                                    </div>
                                    <small class="text-primary-soft-blue fw-medium viewProfRes">
                                        View Profile <i class="fas fa-arrow-right ms-1"></i>
                                    </small>
                                </a>
                            `;

                            // append only to the correct list
                            if (employee.account_status === 'active') {
                                employeeRecordsList.innerHTML += cardHtml;
                            } else {
                                deactivatedRecordsList.innerHTML += cardHtml;
                            }
                        });
                } else {
                    if (employeeRecordsList) employeeRecordsList.innerHTML = `<div class="text-center text-danger py-3">Error loading employees.</div>`;
                    console.error('API Error:', data.message);
                }
            })
            .catch(error => {
                if (employeeRecordsList) employeeRecordsList.innerHTML = `<div class="text-center text-danger py-3">Network error.</div>`;
                console.error('Fetch Error:', error);
            });
    }

    const addEmployeeBtn = document.getElementById('addEmployeeBtn');
    const email = localStorage.getItem('userEmail');
    if (email) {
        fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.owner.length > 0) {
                    const emp = data.owner[0];
                    const position = emp.position.trim();

                    if (position && position.toLowerCase() === 'owner') {
                        addEmployeeBtn.style.visibility = 'hidden';
                    } 
                }
            })
            .catch(err => console.error(err));
    }

    loadEmployees();
});