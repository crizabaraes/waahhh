<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $employee_id = $_POST['employee_id'] ?? null;
    $quarter_name = $_POST['quarter_name'] ?? null;
    $evaluation_id = $_POST['evaluation_id'] ?? null; // Will be present if updating an existing record

    if (!$employee_id || !$quarter_name) {
        throw new Exception('Employee ID and Quarter Name are required.');
    }

    if (!isset($_FILES['evaluation_file']) || $_FILES['evaluation_file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error.');
    }

    $file = $_FILES['evaluation_file'];
    $fileName = basename($file['name']);
    $fileTmpName = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileError = $file['error'];
    $fileType = $file['type'];

    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowed = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

    if (!in_array($fileExt, $allowed)) {
        throw new Exception('Invalid file type. Only PDF, DOC, DOCX, JPG, JPEG, PNG are allowed.');
    }
    if ($fileSize > 10000000) { // 10MB max file size
        throw new Exception('File is too large (max 10MB).');
    }
    if ($fileError !== 0) {
        throw new Exception('There was an error uploading your file.');
    }

    $uploadDir = 'uploads/evaluation_forms/';
    $filePath = $uploadDir . $fileName;

    // Ensure the upload directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Create directory with full permissions
    }

    if (!move_uploaded_file($fileTmpName, $filePath)) {
        throw new Exception('Failed to move uploaded file.');
    }

    // Start a transaction
    $conn->begin_transaction();

    if ($evaluation_id) {
        // If an evaluation_id is provided, it's an update
        $stmt = $conn->prepare("UPDATE evaluations SET form_file_path = ?, status = 'analysis_needed' WHERE evaluation_id = ? AND employee_id = ? AND quarter_name = ?");
        if (!$stmt) {
            throw new Exception('Prepare statement failed (update form): ' . $conn->error);
        }
        $stmt->bind_param("siss", $filePath, $evaluation_id, $employee_id, $quarter_name);

    } else {
        // This is a new form, insert a new record
        // Determine the quarter's start date
        $q = substr($quarter_name, 0, 2);
        $year = substr($quarter_name, -4);
        $month = 4; // Default to April for Q1 (January-March)

        // New Quarter Ranges: Q1=Apr, Q2=Jul, Q3=Oct, Q4=Jan
        if ($q === 'Q2') $month = 7;
        elseif ($q === 'Q3') $month = 10;
        elseif ($q === 'Q4') $month = 1;
        
        $quarter_start_date = "{$year}-" . str_pad($month, 2, '0', STR_PAD_LEFT) . "-01";

        // Insert new evaluation record (should have been created by generate_quarter_evaluations.php, but as fallback)
        $stmt = $conn->prepare("INSERT INTO evaluations (employee_id, quarter_name, quarter_start_date, form_file_path, status) VALUES (?, ?, ?, ?, 'analysis_needed')");
        if (!$stmt) {
            throw new Exception('Prepare statement failed (insert form): ' . $conn->error);
        }
        $stmt->bind_param("ssss", $employee_id, $quarter_name, $quarter_start_date, $filePath);
    }

    if (!$stmt->execute()) {
        throw new Exception('Execute statement failed (form upload): ' . $stmt->error);
    }
    $stmt->close();

    $conn->commit();
    $response['success'] = true;
    $response['message'] = 'Evaluation form uploaded successfully.';
    $response['filePath'] = $filePath; // Send the file path back for the client to use

} catch (Exception $e) {
    $conn->rollback();
    // If file was moved but DB update failed, try to delete the file
    if (isset($filePath) && file_exists($filePath)) {
        unlink($filePath);
    }
    $response['message'] = 'Error uploading form: ' . $e->getMessage();
    error_log("upload_evaluation_form.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>
