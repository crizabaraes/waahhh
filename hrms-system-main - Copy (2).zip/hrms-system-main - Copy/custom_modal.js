document.addEventListener('DOMContentLoaded', function() {
     // Custom Alert Modal elements
    const customAlertModal = document.getElementById('customAlertModal');
    const customAlertTitle = document.getElementById('customAlertTitle');
    const customAlertMessage = document.getElementById('customAlertMessage');
    const closeCustomAlertBtn = document.getElementById('closeCustomAlertBtn');
    // Function to show custom alert modal
    window.showAlertModal = function(title, message) {
        if (customAlertModal && customAlertTitle && customAlertMessage) {
            customAlertTitle.textContent = title;
            customAlertMessage.textContent = message;
            customAlertModal.classList.remove('d-none');
        } else {
            console.error('Custom alert modal elements not found.');
        }
    }

    // Event listener for custom alert modal close button
    if (closeCustomAlertBtn) {
        closeCustomAlertBtn.addEventListener('click', () => {
            if (customAlertModal) {
                customAlertModal.classList.add('d-none');
            }
        });
    }
    // Close modal if backdrop clicked
    if (customAlertModal) {
        customAlertModal.addEventListener('click', (event) => {
            if (event.target === customAlertModal) {
                customAlertModal.classList.add('d-none');
            }
        });
    }
});