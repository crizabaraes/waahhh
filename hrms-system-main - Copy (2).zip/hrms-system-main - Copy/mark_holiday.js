document.addEventListener('DOMContentLoaded', function () {
    // Sample data object for holiday names based on type
    const holidayData = {
        "Regular Holiday": [
            "New Year's Day",
            "Maundy Thursday",
            "Good Friday",
            "Araw ng Kagitingan",
            "Labor Day",
            "Independence Day",
            "National Heroes Day",
            "Bonifacio Day",
            "Christmas Day",
            "Rizal Day"
        ],
        "Special Non-working Holiday": [
            "Eid'l Fitr",
            "Eid'l Adha",
            "Chinese New Year",
            "Black Nazarene Feast",
            "All Saints' Day (if declared special)",
            "Ninoy Aquino Day (if declared special)"
        ]
        
    };

    // Get references to the select elements
    const holidayTypeSelect = document.getElementById('holidayType');
    const holidayNameSelect = document.getElementById('holidayName');

    // Get reference to the holidayDate input (define it early so we can set attributes)
    const holidayDate = document.getElementById('holidayDate');

    // Set the min attribute to today's date to restrict past dates in the date picker
    const today = new Date().toISOString().split('T')[0];  // Get YYYY-MM-DD format
    holidayDate.setAttribute('min', today);

    // Add event listener to #holidayType for when the user changes the selection
    holidayTypeSelect.addEventListener('change', function () {
        const selectedType = this.value;  // Get the selected value (e.g., "Regular Holiday")

        // Clear existing options in #holidayName (keep the default empty option)
        holidayNameSelect.innerHTML = '<option value=""></option>';

        // If a valid type is selected, populate #holidayName with the matching data
        if (selectedType && holidayData[selectedType]) {
            holidayData[selectedType].forEach(function (holiday) {
                const option = document.createElement('option');
                option.value = holiday;  // Set the value to the holiday name
                option.textContent = holiday;  // Set the display text
                holidayNameSelect.appendChild(option);  // Add to the select
            });
        }
        // If no type is selected or invalid, #holidayName stays empty (default behavior)
    });

    // Optional: You can also add logic here for other parts of your form, like showing/hiding the branch field based on type
    // For example, show #branchFieldWrapper only for "Store Closure"
    holidayTypeSelect.addEventListener('change', function () {
        const selectedType = this.value;
        const branchField = document.getElementById('branchFieldWrapper');
        if (selectedType === 'Store Closure') {
            branchField.classList.remove('d-none');  // Show the branch field
        } else {
            branchField.classList.add('d-none');  // Hide it
        }
    });

    // Add event listener to #holidayDate to prevent selecting past dates (additional safeguard)
    holidayDate.addEventListener('change', function() {
        const selectedDate = new Date(this.value);
        const todayCheck = new Date();
        todayCheck.setHours(0, 0, 0, 0);
        if (selectedDate.getTime() < todayCheck.getTime()) {
            showAlertModal('Invalid Date', 'You cannot mark a day in the past.');
            this.value = '';
        }
    });

    // Add submit event listener for #markHolidayForm
    const markHolidayForm = document.getElementById('markHolidayForm');
    if (markHolidayForm) {
        markHolidayForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const formData = new FormData(markHolidayForm);

            try {
                const response = await fetch('holiday.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    showAlertModal('Success', 'Holiday marked successfully.');
                    markHolidayForm.reset();  // Reset the form
                    // Optionally reload or update UI here (e.g., refresh a calendar)
                } else {
                    showAlertModal('Error', result.message || 'An error occurred. Please try again.');
                }
            } catch (error) {
                console.error('Error submitting holiday:', error);
                showAlertModal('Error', 'An error occurred. Please try again.');
            }
        });
    }

    // Calendar real-time
    function updateCalendarDate() {
        const now = new Date();

        const year = now.getFullYear();
        const month = now.toLocaleString('default', { month: 'short' }); 
        const day = now.getDate();

        document.getElementById('cal-year-id').textContent = year;
        document.getElementById('cal-month-id').textContent = month;
        document.getElementById('cal-day-id').textContent = day;
    }

    // Update immediately
    updateCalendarDate();

    // Optional: Update every 1 second (for real-time ticking)
    setInterval(updateCalendarDate, 1000);
});