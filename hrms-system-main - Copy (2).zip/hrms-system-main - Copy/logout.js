document.addEventListener('DOMContentLoaded', function() {
    const logoutButton = document.getElementById('logoutButton');
    const logoutModal = document.getElementById('logoutModal');
    const confirmLogoutYes = document.getElementById('confirmLogoutYes');
    const confirmLogoutNo = document.getElementById('confirmLogoutNo');

    // Show the modal when logout button is clicked
    if (logoutButton) {
        logoutButton.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default link behavior
            logoutModal.classList.remove('d-none'); // Show modal
        });
    }

    // Handle "Yes" button click in the modal
    if (confirmLogoutYes) {
        confirmLogoutYes.addEventListener('click', async function() {
            try {
                const response = await fetch('logout.php', {
                    method: 'POST', // Use POST for logout for better security practices
                    headers: {
                        'Content-Type': 'application/json' // Expect JSON response
                    }
                });
                const result = await response.json();

                if (result.success) {
                    localStorage.clear();
                    window.location.href = 'index.html'; // Redirect to login page
                } else {
                    console.error('Logout failed:', result.message);
                    showAlertModal('Logout Failed', 'Logout failed. Please try again.');
                }
            } catch (error) {
                console.error('Error during logout fetch:', error);
                // For a real app, replace alert with a custom message box
                showAlertModal('Error', 'An error occurred during logout. Please try again.');
            }
        });
    }

    // Handle "No" button click in the modal
    if (confirmLogoutNo) {
        confirmLogoutNo.addEventListener('click', function() {
            logoutModal.classList.add('d-none'); // Hide modal
        });
    }

    // Optional: Hide modal if clicked outside (but not on content)
    if (logoutModal) {
        logoutModal.addEventListener('click', function(event) {
            if (event.target === logoutModal) { // Only if backdrop is clicked, not the content
                logoutModal.classList.add('d-none');
            }
        });
    }
});