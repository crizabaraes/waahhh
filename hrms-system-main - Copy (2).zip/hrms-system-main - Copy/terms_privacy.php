<?php
include 'authentication/db_connect.php'; // your DB connection

$action = $_POST['action'] ?? '';
$response = [];

switch ($action) {

    // 1️⃣ Add new Terms or Privacy version
    case 'add_compliance':
        $type = $_POST['type'];
        $version = $_POST['version'];
        $content = $_POST['content'];
        $date = $_POST['date']; // comes from JS

        // Use the provided date in the insert
        $stmt = $conn->prepare("
            INSERT INTO compliance (type, version, date, content)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                date = VALUES(date),
                content = VALUES(content)
        ");
        $stmt->bind_param("ssss", $type, $version, $date, $content);
        $response['success'] = $stmt->execute();
        $stmt->close();
        break;

    // 2️⃣ Get all versions of Terms or Privacy (for version history)
    case 'get_compliance':
        $type = $_POST['type']; // 'terms' or 'privacy'
        $query = "SELECT id, version, date, content FROM compliance WHERE type=? ORDER BY version DESC";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $type);
        $stmt->execute();
        $result = $stmt->get_result();
        $response = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        break;

    default:
        $response['error'] = 'Invalid action';
        break;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
