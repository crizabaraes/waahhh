<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');
$response = ['success' => false, 'years' => [], 'message' => ''];

try {
    $employee_id = $_GET['employee_id'] ?? null;

    if (!$employee_id) {
        throw new Exception('Employee ID is required.');
    }

    $stmt = $conn->prepare("SELECT DISTINCT SUBSTRING_INDEX(quarter_name, '-', -1) AS quarter_year FROM evaluations WHERE employee_id = ? ORDER BY quarter_year DESC");
    if (!$stmt) {
        throw new Exception('Prepare statement failed: ' . $conn->error);
    }
    
    $stmt->bind_param("s", $employee_id);

    if (!$stmt->execute()) {
        throw new Exception('Execute statement failed: ' . $stmt->error);
    }

    $result = $stmt->get_result();
    $years = [];
    while ($row = $result->fetch_assoc()) {
        $years[] = $row;
    }
    $stmt->close();

    $response['success'] = true;
    $response['years'] = $years;

} catch (Exception $e) {
    $response['message'] = 'Error fetching years: ' . $e->getMessage();
    error_log("get_existing_years.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>