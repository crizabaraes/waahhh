document.addEventListener('DOMContentLoaded', function() {
    const notificationBtn = document.getElementById('notificationBtn');
    if (notificationBtn) {
        notificationBtn.addEventListener('click', function() {
            window.location.href = 'notifications.html';
        });
    }
    
    const email = localStorage.getItem('userEmail');
    if (email) {
        fetch(`get_employee_details.php?work_email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.employees.length > 0) {
                    const emp = data.employees[0];
                    const fullName = emp.full_name.trim();
                    const words = fullName.split(' ');

                    let initials = '';
                    if (emp.position && emp.position.toLowerCase() === 'human resources') {
                        initials = 'HR';
                    } else {
                        if (words.length === 1) {
                            initials = words[0][0];
                        } else {
                            initials = words[0][0] + words[words.length - 1][0];
                        }
                    }

                    // For admin name display (e.g., J. Doe)
                    let formattedName;
                    if (words.length === 1) {
                        formattedName = words[0]; // e.g. "Superman"
                    } else {
                        formattedName = `${words[0][0]}. ${words[words.length - 1]}`; // e.g. "J. Doe"
                    }

                    // Update avatar and name
                    const avatarImg = document.querySelector('#userDropdown img');
                    const userNameSpan = document.querySelector('#userDropdown span');
                    if (emp.picture_file_path) {
                        avatarImg.src = emp.picture_file_path;
                        avatarImg.style.objectFit = 'cover';
                    }
                    else {
                        avatarImg.src = `https://placehold.co/40x40/5C7D8A/ffffff?text=${initials.toUpperCase()}`;
                    }
                    userNameSpan.textContent = formattedName;
                    localStorage.setItem('employeeId', emp.id);
                    localStorage.setItem('status', emp.account_status);
                }
            })
            .catch(err => console.error(err));
    }

    const myProfileLink = document.getElementById('myProfile');
    if (myProfileLink) {
        myProfileLink.addEventListener('click', function(e) {
            e.preventDefault();

            fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.owner.length > 0) {
                    const owner = data.owner[0];
                    const position = owner.position.trim();

                    if (position && position.toLowerCase() === 'owner') {
                        window.location.href = `profile.html?email=${email}`;
                        return;
                    } 
                    if (position && position.toLowerCase() === 'employee') {
                        window.location.href = `profile.html?email=${email}`;
                        return;
                    } 
                }
            })
            .catch(err => console.error(err));

            const empId = localStorage.getItem('employeeId');
            const accountStatus = localStorage.getItem('status');
            if (empId) {
                window.location.href = `profile.html?employeeId=${empId}&status=${accountStatus}`;
            } else {
                showAlertModal('Invalid Employee ID', 'Employee ID not found. Please log in again.');
            }
        });
    }

    
});