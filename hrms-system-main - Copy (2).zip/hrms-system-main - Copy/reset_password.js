document.addEventListener('DOMContentLoaded', function() {
    const sendCodeBtn = document.getElementById('sendCodeBtn');
    const toggleNewPassword = document.getElementById('toggleNewPassword');
    const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmPassword');
    const resetForm = document.getElementById('resetForm');

    // Toggle password visibility
    function toggleVisibility(button, input) {
        button.addEventListener('click', function() {
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    }
    toggleVisibility(toggleNewPassword, newPassword);
    toggleVisibility(toggleConfirmPassword, confirmPassword);

    // Send Code logic
    sendCodeBtn.addEventListener('click', async function() {
        const email = document.getElementById('emailInput').value.trim();
        if (!email) {
            document.getElementById('emailInput').reportValidity();
            return;
        }

        this.disabled = true;

    try {
        const response = await fetch('reset_password.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=get_code&email=${encodeURIComponent(email)}`
        });

        const result = await response.json();

        if (!result.success) {
            // Email not found → re-enable immediately
            console.error(result.message);
            this.disabled = false;
        } else {
            // Success → stay disabled for 30 seconds
            setTimeout(() => { this.disabled = false; }, 30000);
        }
    } catch (error) {
        console.error(error);
        showAlertModal('Sending Unsuccessful', 'Error sending verification code.');
        this.disabled = false;
    }
    });

    function checkPasswordMatch() {
        const newVal = newPassword.value.trim();
        const confirmVal = confirmPassword.value.trim();

        if (newVal === '' || confirmVal === '') {
            // Reset to original
            newPassword.style.borderColor = '';
            confirmPassword.style.borderColor = '';
            newPassword.style.boxShadow = '';
            confirmPassword.style.boxShadow = '';
        } else if (newVal === confirmVal) {
            newPassword.style.borderColor = 'rgb(8, 195, 33)';
            confirmPassword.style.borderColor = 'rgb(8, 195, 33)';
            newPassword.style.boxShadow = '0 0 0 0.25rem rgba(22, 202, 22, 0.57)';
            confirmPassword.style.boxShadow = '0 0 0 0.25rem rgba(22, 202, 22, 0.57)';
        } else {
            newPassword.style.borderColor = 'rgb(231, 10, 10)';
            confirmPassword.style.borderColor = 'rgb(231, 10, 10)';
            newPassword.style.boxShadow = '0 0 0 0.25rem rgba(240, 0, 0, 0.47)';
            confirmPassword.style.boxShadow = '0 0 0 0.25rem rgba(240, 0, 0, 0.47)';
        }
    }

    const strengthFill = document.querySelector('.strength-fill');
    const strengthText = document.querySelector('.strength-text');

    function checkPasswordStrength() {
        const val = newPassword.value.trim();
        let strength = 0;

        if (val.length >= 12) strength++;             // minimum length
        if (/[a-z]/.test(val)) strength++;            // lowercase
        if (/[A-Z]/.test(val)) strength++;            // uppercase
        if (/[0-9]/.test(val)) strength++;            // number
        if (/[\W]/.test(val)) strength++;             // special char

        if (val.length === 0) {
        // Reset to initial state
            strengthFill.style.width = '0%';
            strengthFill.style.backgroundColor = 'red'; // keep red or original
            strengthText.textContent = '';
            strengthText.style.color = 'text-muted'; // or 'inherit'
        } else {
            // Update bar and text
            switch(strength) {
                case 0:
                case 1:
                case 2:
                case 3:
                    strengthFill.style.width = '33%';
                    strengthFill.style.backgroundColor = 'red';
                    strengthText.textContent = 'Weak';
                    strengthText.style.color = 'red';
                    break;
                case 4:
                    strengthFill.style.width = '66%';
                    strengthFill.style.backgroundColor = 'orange';
                    strengthText.textContent = 'Medium';
                    strengthText.style.color = 'orange';
                    break;
                case 5:
                    strengthFill.style.width = '100%';
                    strengthFill.style.backgroundColor = 'green';
                    strengthText.textContent = 'Strong';
                    strengthText.style.color = 'green';
                    break;
            }
        }
        return strength;
    }

    newPassword.addEventListener('input', () => {
        checkPasswordStrength();
        checkPasswordMatch(); // keep your confirm match check working
    });
    confirmPassword.addEventListener('input', checkPasswordMatch);

    resetForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const newPass = newPassword.value.trim();
        const confirmPass = confirmPassword.value.trim();
        const verificationCode = document.getElementById('verificationCode').value.trim();
        const email = document.getElementById('emailInput').value.trim();

        if (newPass !== confirmPass) {
            showAlertModal('Unmatched New Passwords', 'New Password and Confirm New Password does not match.');
            confirmPass.focus();
            return;
        }

        const strength = checkPasswordStrength();
        if (strength < 5) { // less than Strong
            showAlertModal('Insecure New Password', 'New Password must be strong.');
            newPass.focus();
            return;
        }

        try {
            const response = await fetch('reset_password.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'reset_password',
                    email,
                    verification_code: verificationCode,
                    new_password: newPass,
                    confirm_password: confirmPass
                })
            });

            // Check if response is valid JSON
            const result = await response.json();

            // --- Success handler ---
            if (result.success) {
                // Small delay to ensure alert modal doesn’t clash with redirect
                showAlertModal('Success', 'Your password has been reset successfully.');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
                return;
            }

            // --- Failure handler ---
            if (result.message.includes('Email not found')) {
                showAlertModal('Invalid Email', 'The email you entered does not exist.');
            } else if (result.message.includes('Invalid verification code')) {
                showAlertModal('Invalid Code', 'The verification code is incorrect.');
            } else if (result.message.includes('Invalid or missing verification code')) {
                showAlertModal('Missing Code', 'Click "Send code" to receive your verification code.');
            } else if (result.message.includes('Verification code has expired.')) {
                showAlertModal('Expired Code', 'Verification code has expired. Click "Send code" to receive another.');
            } else {
                console.error(result.message);
            }

        } catch (error) {
            console.error('Reset error:', error);
            showAlertModal('Error', 'An unexpected error occurred.');
        }
    });
});