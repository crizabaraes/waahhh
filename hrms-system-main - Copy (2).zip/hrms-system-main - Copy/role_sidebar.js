document.addEventListener('DOMContentLoaded', function() {
    const holidaySide = document.getElementById('holidaySide');
    const recordsSide = document.getElementById('recordsSide');
    const payrollSide = document.getElementById('payrollSide');
    const email = localStorage.getItem('userEmail');
    if (email) {
        fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.owner.length > 0) {
                    const owner = data.owner[0];
                    const position = owner.position.trim();

                    if (position && position.toLowerCase() === 'owner') {
                        holidaySide.style.display = 'none';
                    } 

                    if (position && position.toLowerCase() === 'employee') {
                        holidaySide.style.display = 'none';
                        recordsSide.style.display = 'none';
                        payrollSide.style.display = 'none';
                    } 
                }
            })
            .catch(err => console.error(err));
    }
});
