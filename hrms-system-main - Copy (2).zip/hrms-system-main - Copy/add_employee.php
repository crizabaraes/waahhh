<?php
require_once 'authentication/db_connect.php';
require_once 'send_email.php';

function isValidEmailDomain($email) {
    // 1. Basic email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    // 2. Extract domain
    $domain = substr(strrchr($email, "@"), 1);

    // 3. Check MX records (mail servers)
    if (checkdnsrr($domain, "MX")) {
        return true;
    }

    // 4. Fallback: some domains use A records (rare)
    if (checkdnsrr($domain, "A")) {
        return true;
    }

    return false;
}

function generateEmployeeID() {
    $random = str_pad(mt_rand(0, 9999), 4, '0', STR_PAD_LEFT);
    return "EAM{$random}";
}

function generateQRcode($date_joined) {
    $year = date("Y", strtotime($date_joined));
    $random = str_pad(mt_rand(0, 9999), 4, '0', STR_PAD_LEFT);
    return "EMP{$year}{$random}";
}

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Basic Employee Data (Required fields)
    $id = trim($_POST['id'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $work_email = trim($_POST['work_email'] ?? '');
    $password = $_POST['password'] ?? ''; // Raw password from JS
    $contact_number = trim($_POST['contact_number'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $birthday = $_POST['birthday'] ?? '';
    $age = (int)($_POST['age'] ?? 0); 
    $sex = $_POST['sex'] ?? '';
    $civil_status = $_POST['civil_status'] ?? '';
    $branch = trim($_POST['branch'] ?? '');
    $position = trim($_POST['position'] ?? '');
    $date_joined = $_POST['date_joined'] ?? '';
    $monthly_salary = (float)($_POST['monthly_salary'] ?? 0.0);
    $sss_contribution = (int)($_POST['sss_contribution'] ?? 0); 
    $hdmf_contribution = (int)($_POST['hdmf_contribution'] ?? 0); 
    $phic_contribution = (int)($_POST['phic_contribution'] ?? 0);
    $work_shift_start = $_POST['work_shift_start'] ?? '';
    $work_shift_end = $_POST['work_shift_end'] ?? '';
    $rest_day = $_POST['rest_day'] ?? '';
    $qrcode_id = trim($_POST['qrcode_id'] ?? null);
    $bank_number = trim($_POST['bank_number'] ?? '');
    $sss_number = trim($_POST['sss_number'] ?? '');
    $hdmf_number = trim($_POST['hdmf_number'] ?? '');
    $phic_number = trim($_POST['phic_number'] ?? '');
    $tin_number = trim($_POST['tin_number'] ?? '');

    if (!isValidEmailDomain($work_email)) {
        $response['success'] = false;
        $response['message'] = 'The email "' . htmlspecialchars($work_email) . '" has an invalid domain or cannot receive emails.';
        echo json_encode($response);
        exit;
    }

    if (strtolower($position) === 'branch manager') {
        // Check if any employee already has this position in the same branch
        $stmt_bm = $conn->prepare("SELECT COUNT(*) as bm_count FROM employees WHERE LOWER(position) = 'branch manager' AND branch = ?");
        if (!$stmt_bm) {
            throw new Exception('Prepare statement failed (Branch Manager check): ' . $conn->error);
        }
        $stmt_bm->bind_param("s", $branch); // $branch should come from your form/input
        $stmt_bm->execute();
        $result_bm = $stmt_bm->get_result()->fetch_assoc();
        $stmt_bm->close();

        if ($result_bm['bm_count'] > 0) {
            // Already exists → throw error
            $response['success'] = false;
            $response['message'] = 'There is already a Branch Manager in the selected branch.';
            echo json_encode($response);
            exit; // stop execution
        }
    }

    // Handle profile picture upload
    $picture_file_path = null;
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) { 
        $fileTmpPath = $_FILES['profile_picture']['tmp_name'];
        $fileName = $_FILES['profile_picture']['name']; 
        $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
        $newFileName = uniqid('profilepic_', true) . '.' . $fileExtension; 

        $uploadDir = 'uploads/profile_pictures/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

        $destPath = $uploadDir . $newFileName;

        if (move_uploaded_file($fileTmpPath, $destPath)) { 
            $picture_file_path = $destPath;
        } else { 
            $picture_file_path = null;
        } 
    }

    // Hash the password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $employee_position = 'Employee'; // Set default position for new employees

    // Start transaction
    $conn->begin_transaction();

    try {
        // 1. Insert into employees table
        $retryCount = 0;
        $maxRetries = 20; 
         
        while (true) { 
            try { 
                if (empty($id) || $retryCount > 0) { 
                    $id = generateEmployeeID(); 
                } 
                if (empty($qrcode_id) || $retryCount > 0) { 
                    $qrcode_id = generateQRcode($date_joined); 
                }
                
                $stmt = $conn->prepare("INSERT INTO employees (id, full_name, work_email, password, contact_number, address, birthday, age, sex, civil_status, 
                                                                branch, position, date_joined, monthly_salary, sss_contribution, hdmf_contribution, phic_contribution, work_shift_start, 
                                                                work_shift_end, rest_day, qrcode_id, picture_file_path, bank_number, sss_number, hdmf_number, phic_number, tin_number) 
                                                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); 
                if (!$stmt) { 
                    throw new Exception('Prepare statement failed (employees): ' . $conn->error); 
                } 
                
                $stmt->bind_param( 
                    "sssssssisssssdiiissssssssss", 
                    $id, $full_name, $work_email, $password_hash, $contact_number, $address, $birthday, $age, 
                    $sex, $civil_status, $branch, $position, $date_joined, $monthly_salary, $sss_contribution, $hdmf_contribution, $phic_contribution, 
                    $work_shift_start, $work_shift_end, $rest_day, $qrcode_id, $picture_file_path, $bank_number, $sss_number, $hdmf_number, $phic_number, $tin_number
                ); 
                
                if (!$stmt->execute()) { 
                    throw new Exception('Execute statement failed (employees): ' . $stmt->error); 
                } 
                
                $employee_id = $conn->insert_id; 
                $stmt->close(); 
                break; // ✅ success → exit loop 
            } catch (mysqli_sql_exception $e) {
                if ($e->getCode() == 1062) { 
                    // check if duplicate is qr code or email
                    if (strpos($e->getMessage(), 'qrcode_id') !== false) {
                        $retryCount++;
                        if ($retryCount >= $maxRetries) {
                            throw new Exception("Failed to generate unique QR Code after {$maxRetries} attempts.");
                        }
                        continue; // 🔁 retry
                    } elseif (strpos($e->getMessage(), "for key 'PRIMARY'") !== false || strpos($e->getMessage(), 'id') !== false) {
                        $retryCount++;
                        if ($retryCount >= $maxRetries) {
                            throw new Exception("Failed to generate unique Employee ID after {$maxRetries} attempts.");
                        }
                        continue; // 🔁 retry new Employee ID
                    } elseif (strpos($e->getMessage(), 'work_email') !== false) {
                        throw new Exception('The work email "' . htmlspecialchars($work_email) . '" already exists in the system. Please use a different email.');
                    }
                }
                throw $e; // other errors
                exit;
            }
        }
        // 2. Insert into login_credentials table (using email as PK, no employee_id, no created_at)
        $stmt_login = $conn->prepare("INSERT INTO login_credentials (email, password, position) VALUES (?, ?, ?)");
        if (!$stmt_login) {
            throw new Exception('Prepare statement failed (login_credentials): ' . $conn->error);
        }
        $stmt_login->bind_param("sss", $work_email, $password_hash, $employee_position);
        if (!$stmt_login->execute()) {
            throw new Exception('Execute statement failed (login_credentials): ' . $stmt_login->error);
        }
        $stmt_login->close();

        // 3. Send email to the employee
        $subject = "Welcome to HRMS! Your Login Credentials";
        $body = "Dear " . $full_name . ",\n\n"
              . "Your HRMS account has been created.\n\n"
              . "Here are your login details:\n"
              . "Email: " . $work_email . "\n"
              . "Temporary Password: " . $password . "\n\n"
              . "Please log in using the link below and change your password immediately:\n"
              . "LOGIN LINK: https://eamotohub.site\n\n"
              . "If you have any questions, please contact HR.\n\n"
              . "Best regards,\n"
              . "HR Team";

        // Call the sendToEmail function from send_email.php
        if (!sendToEmail($work_email, $subject, $body)) {
            error_log("Failed to send welcome email to " . $work_email);
        }

        // 4. Insert Educational Background
        if (isset($_POST['education_data']) && !empty($_POST['education_data'])) {
            $education_data = json_decode($_POST['education_data'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON for education_data: ' . json_last_error_msg());
            }

            $stmt_edu = $conn->prepare("INSERT INTO employee_education (employee_id, school, academic_year, course_strand, special_notes) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt_edu) {
                throw new Exception('Prepare statement failed (education): ' . $conn->error);
            }
            foreach ($education_data as $edu) {
                $school = $edu['school'] ?? '';
                $academic_year = $edu['academic_year'] ?? '';
                $course_strand = $edu['course_strand'] ?? '';
                $special_notes = $edu['special_notes'] ?? null;

                // Basic validation for required sub-fields
                if (empty($school) || empty($academic_year) || empty($course_strand)) {
                    throw new Exception('Required education fields are missing.');
                }
                $stmt_edu->bind_param("sssss", $employee_id, $school, $academic_year, $course_strand, $special_notes);
                if (!$stmt_edu->execute()) {
                    throw new Exception('Execute statement failed (education): ' . $stmt_edu->error);
                }
            }
            $stmt_edu->close();
        }

        // 5. Insert Work Experience
        if (isset($_POST['work_experience_data']) && !empty($_POST['work_experience_data'])) {
            $work_experience_data = json_decode($_POST['work_experience_data'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON for work_experience_data: ' . json_last_error_msg());
            }

            $stmt_work = $conn->prepare("INSERT INTO employee_work_experience (employee_id, company, length_of_service, position, duties_achievements) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt_work) {
                throw new Exception('Prepare statement failed (work experience): ' . $conn->error);
            }
            foreach ($work_experience_data as $work) {
                $company = $work['company'] ?? '';
                $length_of_service = $work['length_of_service'] ?? '';
                $position = $work['position'] ?? '';
                $duties_achievements = $work['duties_achievements'] ?? null;

                if (empty($company) || empty($length_of_service) || empty($position)) {
                    throw new Exception('Required work experience fields are missing.');
                }
                $stmt_work->bind_param("sssss", $employee_id, $company, $length_of_service, $position, $duties_achievements);
                if (!$stmt_work->execute()) {
                    throw new Exception('Execute statement failed (work experience): ' . $stmt_work->error);
                }
            }
            $stmt_work->close();
        }

        // 6. Insert Trainings
        if (isset($_POST['training_data']) && !empty($_POST['training_data'])) {
            $training_data = json_decode($_POST['training_data'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON for training_data: ' . json_last_error_msg());
            }

            $stmt_train = $conn->prepare("INSERT INTO employee_trainings (employee_id, training_name, date_attended, notes) VALUES (?, ?, ?, ?)");
            if (!$stmt_train) {
                throw new Exception('Prepare statement failed (training): ' . $conn->error);
            }
            foreach ($training_data as $train) {
                $training_name = $train['training_name'] ?? '';
                $date_attended = $train['date_attended'] ?? null;
                $notes = $train['notes'] ?? null;

                if (empty($training_name)) {
                    throw new Exception('Required training name is missing.');
                }
                $stmt_train->bind_param("ssss", $employee_id, $training_name, $date_attended, $notes);
                if (!$stmt_train->execute()) {
                    throw new Exception('Execute statement failed (training): ' . $stmt_train->error);
                }
            }
            $stmt_train->close();
        }

        // 7. Insert Certificates
        if (isset($_POST['certificates_data']) && !empty($_POST['certificates_data'])) {
            $certificates_data = json_decode($_POST['certificates_data'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON for certificates_data: ' . json_last_error_msg());
            }

            $stmt_cert = $conn->prepare("INSERT INTO employee_certificates (employee_id, certificate_name, issuing_body, date_issued) VALUES (?, ?, ?, ?)");
            if (!$stmt_cert) {
                throw new Exception('Prepare statement failed (certificates): ' . $conn->error);
            }
            foreach ($certificates_data as $cert) {
                $certificate_name = $cert['certificate_name'] ?? '';
                $issuing_body = $cert['issuing_body'] ?? null;
                $date_issued = $cert['date_issued'] ?? null;

                if (empty($certificate_name)) {
                    throw new Exception('Required certificate name is missing.');
                }
                $stmt_cert->bind_param("ssss", $employee_id, $certificate_name, $issuing_body, $date_issued);
                if (!$stmt_cert->execute()) {
                    throw new Exception('Execute statement failed (certificates): ' . $stmt_cert->error);
                }
            }
            $stmt_cert->close();
        }

        // 8. Insert Skills
        if (isset($_POST['skills_data']) && !empty($_POST['skills_data'])) {
            $skills_data = json_decode($_POST['skills_data'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON for skills_data: ' . json_last_error_msg());
            }

            $stmt_skill = $conn->prepare("INSERT INTO employee_skills (employee_id, skill_name) VALUES (?, ?)");
            if (!$stmt_skill) {
                throw new Exception('Prepare statement failed (skills): ' . $conn->error);
            }
            foreach ($skills_data as $skill) {
                $skill_name = $skill['skill_name'] ?? '';

                if (empty($skill_name)) {
                    throw new Exception('Required skill name is missing.');
                }
                $stmt_skill->bind_param("ss", $employee_id, $skill_name);
                if (!$stmt_skill->execute()) {
                    throw new Exception('Execute statement failed (skills): ' . $stmt_skill->error);
                }
            }
            $stmt_skill->close();
        }

        if (isset($_FILES['otherFiles'])) {
    foreach ($_FILES['otherFiles']['name'] as $idx => $fileArray) {
        // $fileArray is an array with key 'file_upload'
        if (!empty($fileArray['file_upload'])) {
            $fileName = $fileArray['file_upload']; // This is now a string
            $tmpName = $_FILES['otherFiles']['tmp_name'][$idx]['file_upload'] ?? '';
            $fileCategory = $_POST['otherFiles'][$idx]['file_name'] ?? '';

            if (!empty($tmpName) && !empty($fileCategory)) {
                $ext = pathinfo($fileName, PATHINFO_EXTENSION);
                $newFileName = uniqid('empfile_') . '.' . $ext;
                $targetPath = 'uploads/employee_files/' . $newFileName;

                if (move_uploaded_file($tmpName, $targetPath)) {
                    $stmt_file = $conn->prepare(
                        "INSERT INTO employee_files (employee_id, file_category, file_path) VALUES (?, ?, ?)"
                    );
                    $stmt_file->bind_param("sss", $employee_id, $fileCategory, $targetPath);
                    $stmt_file->execute();
                    $stmt_file->close();
                }
            }
        }
    }
}



        $conn->commit();
        $response['new_qrcode'] = $qrcode_id;
        $response['success'] = true;
        $response['message'] = 'Employee and related data added successfully.';

    } catch (Exception $e) {
        $conn->rollback();
        // For any other unexpected errors, provide the generic message
        $response['message'] = 'Error: An unexpected error occurred. ' . $e->getMessage();
        // Log the full error for debugging
        error_log("add_employee.php error: " . $e->getMessage() . " (Code: " . $e->getCode() . ")");
    }
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>
