<?php
require_once 'authentication/db_connect.php';
require_once 'send_email.php';
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';
    $email = $_POST['email'] ?? '';

    // --- ACTION 1: Generate & Send Verification Code ---
    if ($action === 'get_code') {
        $stmt = $conn->prepare("SELECT * FROM login_credentials WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $code = mt_rand(100000, 999999);
            $expires_at = date('Y-m-d H:i:s', time() + 30); // expires in 30 seconds

            $update = $conn->prepare("UPDATE login_credentials 
                SET verification_code = ?, verification_expires_at = ? 
                WHERE email = ?");
            $update->bind_param("iss", $code, $expires_at, $email);
            $update->execute();
            $update->close();

            $subject = "HRMS Password Reset Request";
            $body = "
            <html><head><style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f9f9f9; padding: 20px; color: #333; }
            .container { max-width: 600px; margin: auto; background: #fff; border-radius: 8px; padding: 25px; box-shadow: 0 3px 8px rgba(0,0,0,0.1); }
            .header { font-size: 20px; font-weight: 600; color: #444; margin-bottom: 15px; }
            .code-box { font-size: 24px; letter-spacing: 2px; background: #f1f1f1; border: 1px solid #ddd; border-radius: 6px; padding: 10px 15px; text-align: center; margin: 20px 0; color: #222; font-weight: 700; }
            </style></head><body>
            <div class='container'>
                <div class='header'>Password Reset Request</div>
                <p>Use the verification code below to reset your password (expires in 30 seconds):</p>
                <div class='code-box'>$code</div>
                <p>If you didn’t request this, please ignore this message.</p>
                <p>Best regards,<br>HRMS Team</p>
            </div>
            </body></html>";

            if (sendToEmail($email, $subject, $body)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to send email.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Email not found.']);
        }
        $stmt->close();
        exit();
    }

    // --- ACTION 2: Reset Password ---
    if ($action === 'reset_password') {
        $verification_code = $_POST['verification_code'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        $checkEmail = $conn->prepare("SELECT verification_code, verification_expires_at 
                                      FROM login_credentials WHERE email = ?");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        $emailResult = $checkEmail->get_result();

        if ($emailResult->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => 'Email not found.']);
            exit();
        }

        $row = $emailResult->fetch_assoc();
        $stored_code = $row['verification_code'];
        $expires_at = $row['verification_expires_at'];

        // Check for expiration (auto-clear if expired)
        if (!is_null($expires_at) && strtotime($expires_at) < time()) {
            $clear = $conn->prepare("UPDATE login_credentials 
                                     SET verification_code = NULL, verification_expires_at = NULL 
                                     WHERE email = ?");
            $clear->bind_param("s", $email);
            $clear->execute();
            $clear->close();

            echo json_encode(['success' => false, 'message' => 'Verification code has expired.']);
            exit();
        }

        if (is_null($stored_code) || $stored_code === '') {
            echo json_encode(['success' => false, 'message' => 'Invalid or missing verification code.']);
            exit();
        }

        if ($verification_code != $stored_code) {
            echo json_encode(['success' => false, 'message' => 'Invalid verification code.']);
            exit();
        }

        if ($new_password !== $confirm_password) {
            echo json_encode(['success' => false, 'message' => 'Passwords do not match.']);
            exit();
        }

        // All checks passed — update password & clear code
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE login_credentials 
                                  SET password = ?, verification_code = NULL, verification_expires_at = NULL 
                                  WHERE email = ?");
        $update->bind_param("ss", $hashed, $email);
        $update->execute();
        $update->close();

        $updateEmp = $conn->prepare("UPDATE employees SET password = ? WHERE work_email = ?");
        $updateEmp->bind_param("ss", $hashed, $email);
        $updateEmp->execute();
        $updateEmp->close();

        echo json_encode(['success' => true, 'message' => 'Password successfully reset.']);
        exit();
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
    exit();
}

echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
$conn->close();
exit();
