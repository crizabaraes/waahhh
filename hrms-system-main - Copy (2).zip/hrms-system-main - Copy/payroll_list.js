document.addEventListener('DOMContentLoaded', function() {
    // Function to load the payroll month cards
    function loadPayMonths() {
        const payrollContainer = document.getElementById('payrollMonths');
        const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

        if (payrollContainer) {
            payrollContainer.innerHTML = ''; // Clear existing cards

            months.forEach(month => {
                const payrollCard = `
                    <a href="payroll.html" class="list-group-item list-group-item-action payroll-card d-flex align-items-center justify-content-between p-3">
                        <div class="d-flex align-items-start">
                            <div class="content-area">
                                <h5 class="fw-semibold text-text-dark-grey payMonthRes">${month}</h5>
                                <p class="small text-text-dark-grey mb-0 mt-1 payLabelRes">
                                    <i class="fas fa-file-invoice-dollar text-accent-peach me-2"></i> Payslips for ${month}
                                </p>
                            </div>
                        </div>
                        <div class="text-end">
                            <small class="text-primary-soft-blue text-decoration-none fw-medium viewPayRes">View Payslips <i class="fas fa-arrow-right ms-1"></i></small>
                        </div>
                    </a>
                `;
                payrollContainer.innerHTML += payrollCard;
            });
        }
    }

    loadPayMonths();
});