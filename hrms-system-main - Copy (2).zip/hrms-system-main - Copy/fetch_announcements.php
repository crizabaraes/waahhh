<?php
require_once 'authentication/db_connect.php'; // Include your database connection

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'announcements' => []];

// Fetch announcements ordered by post_date descending (newest first)
$sql = "SELECT id, title, details, post_date FROM announcements ORDER BY post_date DESC";
$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $response['announcements'][] = $row;
        }
        $response['success'] = true;
    } else {
        $response['message'] = 'No announcements found.';
        $response['success'] = true; // Still success, just no data
    }
} else {
    $response['message'] = 'Database query failed: ' . $conn->error;
}

$conn->close();
echo json_encode($response);
?>
