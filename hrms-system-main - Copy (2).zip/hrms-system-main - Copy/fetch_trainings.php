<?php
require 'authentication/db_connect.php';

$response = ['success' => false, 'message' => '', 'trainings' => []];

$sql = "SELECT id, filename, filepath FROM training_materials";
$result = $conn->query($sql);

if ($result) {
    $response['success'] = true;
    $response['message'] = 'Trainings fetched successfully.';
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $response['trainings'][] = $row;
        }
    }
} else {
    $response['message'] = 'Database error: ' . $conn->error;
}

$conn->close();
header('Content-Type: application/json');
echo json_encode($response);
?>