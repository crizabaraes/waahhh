<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$action = isset($_GET['action']) ? $_GET['action'] : '';
$query = isset($_GET['q']) ? trim($_GET['q']) : '';

$response = ['success' => false, 'results' => []];

if ($action === '' || $query === '') {
    echo json_encode($response);
    exit;
}

switch ($action) {
    case 'announcement':
        $stmt = $conn->prepare("SELECT * FROM announcements WHERE title LIKE ? OR details LIKE ? ORDER BY post_date DESC");
        $like = "%$query%";
        $stmt->bind_param("ss", $like, $like);
        $stmt->execute();
        $result = $stmt->get_result();
        $response['results'] = $result->fetch_all(MYSQLI_ASSOC);
        $response['success'] = true;
        break;

    case 'notification':
        $stmt = $conn->prepare("SELECT * FROM notifications WHERE title LIKE ? OR content LIKE ? ORDER BY date_sent DESC");
        $like = "%$query%";
        $stmt->bind_param("ss", $like, $like);
        $stmt->execute();
        $result = $stmt->get_result();
        $response['results'] = $result->fetch_all(MYSQLI_ASSOC);
        $response['success'] = true;
        break;

    case 'employee':
        // Search employees table (name, email, etc.)
        $stmt = $conn->prepare("SELECT * FROM employees WHERE full_name LIKE ? OR branch LIKE ? ORDER BY full_name ASC");
        $like = "%$query%";
        $stmt->bind_param("ss", $like, $like);
        $stmt->execute();
        $result = $stmt->get_result();
        $response['results'] = $result->fetch_all(MYSQLI_ASSOC);
        $response['success'] = true;
        break;

    case 'evaluation':
        $ids = isset($_GET['ids']) ? $_GET['ids'] : '';
        $idsArr = array_filter(array_map('intval', explode(',', $ids)));
        if (empty($idsArr)) {
            $response['results'] = [];
            $response['success'] = true;
            break;
        }
        $in = implode(',', array_fill(0, count($idsArr), '?'));
        $types = str_repeat('i', count($idsArr));
        $params = $idsArr;
        $sql = "SELECT * FROM evaluations WHERE evaluation_id IN ($in) AND employee_name LIKE ?";
        $stmt = $conn->prepare($sql);
        $like = "%$query%";
        $params[] = $like;
        $stmt->bind_param($types . 's', ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $response['results'] = $result->fetch_all(MYSQLI_ASSOC);
        $response['success'] = true;
        break;

    case 'training':
        // Only file_name column, match anywhere in the filename
        $stmt = $conn->prepare("SELECT * FROM training_materials WHERE file_name LIKE ?");
        $like = "%$query%";
        $stmt->bind_param("s", $like);
        $stmt->execute();
        $result = $stmt->get_result();
        $response['results'] = $result->fetch_all(MYSQLI_ASSOC);
        $response['success'] = true;
        break;

    default:
        $response['success'] = false;
        $response['results'] = [];
        break;
}

echo json_encode($response);