document.addEventListener('DOMContentLoaded', function() {
    const listCurrent = document.getElementById('evaluationsEmployeeListCurrent');
    const listArchive = document.getElementById('evaluationsEmployeeListArchive');
    const email = localStorage.getItem('userEmail');
    let userPosition = '';

    async function getUserPosition() {
        if (!email) return '';
        try {
            const res = await fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`);
            const data = await res.json();
            if (data.success && data.owner.length > 0) {
                const position = data.owner[0].position.trim();
                return position || '';
            }
        } catch (err) {
            console.error('Error fetching user position:', err);
        }
        return '';
    }

    async function loadEvaluations() {
        if (!userPosition) userPosition = await getUserPosition();

        // Decide which API to call
        const apiUrl = (userPosition.toLowerCase() === 'employee')
            ? `get_peers_evaluation.php?email=${encodeURIComponent(email)}`
            : 'get_current_evaluation.php';

        try {
            const response = await fetch(apiUrl);
            const data = await response.json();

            if (!listCurrent || !listArchive) return;

            listCurrent.innerHTML = '';
            listArchive.innerHTML = '';

            if (!data.success) {
                listCurrent.innerHTML = `<div class="text-center text-danger py-3">Error loading evaluations.</div>`;
                listArchive.innerHTML = `<div class="text-center text-danger py-3">Error loading archive.</div>`;
                console.error('API Error:', data.message);
                return;
            }

            const employees = (userPosition.toLowerCase() === 'employee' && data.pending_peer_evaluations)
                ? data.pending_peer_evaluations
                : data.employees;

            const currentQuarterRaw = data.current_quarter;
            const [quarter, year] = currentQuarterRaw.split('-');
            const formattedQuarter = `${year} ${quarter.toUpperCase()}`;

            if (!employees.length) {
                listCurrent.innerHTML = `<div class="text-center text-text-muted-grey py-3">No evaluations found.</div>`;
                listArchive.innerHTML = `<div class="text-center text-text-muted-grey py-3">No archive found.</div>`;
                return;
            }

            employees.forEach(employee => {
                if (!employee.evaluation_id) return;

                const isHistory = employee.from_latest === true;
                const label = isHistory
                    ? `${employee.full_name} – History`
                    : `${employee.full_name} – ${formattedQuarter}`;

                const responsesCount = parseInt(employee.responses_count || 0);
                const totalPeers = Math.max(parseInt(employee.branch_total_count || 1) - 1, 0);
                const hasAnalysis = employee.analysis_data;
                const hasForm = employee.form_file_path;

                let statusText = '';
                let statusIcon = '';

                // If the logged-in user is an employee, always show "Response Needed"
                if (userPosition.toLowerCase() === 'employee') {
                    statusText = 'Response Needed';
                    statusIcon = 'fas fa-envelope text-primary-soft-blue'; // example icon, can change
                } else {
                    if (!hasForm) {
                        statusText = 'Form Needed';
                        statusIcon = 'fas fa-file-alt text-danger';
                    } else if (responsesCount < totalPeers) {
                        statusText = `${responsesCount}/${totalPeers} Responses`;
                        statusIcon = 'fas fa-users text-primary-soft-blue';
                    } else if (!hasAnalysis) {
                        statusText = 'Analysis Needed';
                        statusIcon = 'fas fa-chart-line text-danger';
                    } else {
                        statusText = 'Completed';
                        statusIcon = 'fas fa-check-circle text-success';
                    }
                }

                const statusLine = isHistory
                    ? ''
                    : `<p class="small text-text-dark-grey mb-0 mt-1"><i class="${statusIcon} me-1"></i> ${statusText}</p>`;

                const quarterForLink = isHistory ? employee.quarter_name : currentQuarterRaw;

                const evaluationCard = `
                    <a href="evaluation.html?evaluationId=${employee.evaluation_id}&employeeId=${employee.id}&employeeName=${encodeURIComponent(employee.full_name)}&quarterName=${encodeURIComponent(quarterForLink)}&position=${encodeURIComponent(userPosition)}" class="list-group-item list-group-item-action evaluation-card d-flex align-items-center justify-content-between p-3">
                        <div class="d-flex align-items-start">
                            <div class="content-area">
                                <h5 class="fw-semibold text-text-dark-grey ${isHistory ? 'experimentbahaha' : ''}">${label}</h5> 
                                ${statusLine}
                            </div>
                        </div>
                        <div class="text-end">
                            <small class="text-primary-soft-blue text-decoration-none fw-medium viewEvalRes">View Evaluation <i class="fas fa-arrow-right ms-1"></i></small>
                        </div>
                    </a>
                `;

                if (isHistory) listArchive.innerHTML += evaluationCard;
                else listCurrent.innerHTML += evaluationCard;
            });

        } catch (err) {
            listCurrent.innerHTML = `<div class="text-center text-danger py-3">Network error.</div>`;
            listArchive.innerHTML = `<div class="text-center text-danger py-3">Network error.</div>`;
            console.error('Fetch Error:', err);
        }
    }
    window.generateQuarter = function() {
        fetch('generate_evaluation_quarter.php')
            .then(response => response.json())
            .then(data => {
                loadEvaluations();
            })
            .catch(error => {
                loadEvaluations();
            });
    }
    generateQuarter();
    setInterval(generateQuarter, 6000);

    if (email) {
        fetch(`get_update_owner.php?email=${encodeURIComponent(email)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.owner.length > 0) {
                    const emp = data.owner[0];
                    const position = emp.position.trim();

                    if (position && position.toLowerCase() === 'employee') {
                        const currentQuarterContainer = document.getElementById('currentQuarterContainer');
                        const archiveEvalContainer = document.getElementById('archiveEvalContainer');

                        if (currentQuarterContainer) {
                            // Remove col-lg-6 and add col-12 (Bootstrap)
                            currentQuarterContainer.classList.remove('col-lg-6');
                            currentQuarterContainer.classList.add('col-12');
                        }

                        if (archiveEvalContainer) {
                            archiveEvalContainer.style.display = 'none';
                        }
                    } 
                }
            })
            .catch(err => console.error(err));
    }
});