<?php
require_once 'authentication/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    $employee_id = $_GET['employee_id'] ?? null;
    $quarter_name = $_GET['quarter_name'] ?? null;

    if (!$employee_id || !$quarter_name) {
        throw new Exception('Employee ID and Quarter Name are required.');
    }

    // 1. Fetch evaluation details for the specific employee and quarter
    $stmt_eval = $conn->prepare("SELECT evaluation_id, form_file_path, analysis_data, status FROM evaluations WHERE employee_id = ? AND quarter_name = ?");
    if (!$stmt_eval) {
        throw new Exception('Prepare statement failed (evaluation details): ' . $conn->error);
    }
    $stmt_eval->bind_param("ss", $employee_id, $quarter_name);
    if (!$stmt_eval->execute()) {
        throw new Exception('Execute statement failed (evaluation details): ' . $stmt_eval->error);
    }
    $result_eval = $stmt_eval->get_result();
    $evaluation = $result_eval->fetch_assoc();
    $stmt_eval->close();

    $response['evaluation'] = $evaluation; // Will be null if no evaluation found

    if ($evaluation) {
        $evaluation_id = $evaluation['evaluation_id'];

        // 2. Fetch all responses for this evaluation
        $stmt_responses = $conn->prepare("
            SELECT 
                er.employee_id,
                er.response_file_path,
                emp.full_name
            FROM evaluation_responses er
            LEFT JOIN employees emp 
                ON emp.id = er.employee_id
            WHERE er.evaluation_id = ?
        ");

        if (!$stmt_responses) {
            throw new Exception('Prepare statement failed (responses): ' . $conn->error);
        }
        $stmt_responses->bind_param("i", $evaluation_id);
        if (!$stmt_responses->execute()) {
            throw new Exception('Execute statement failed (responses): ' . $stmt_responses->error);
        }
        $result_responses = $stmt_responses->get_result();
        $responses = [];
        while ($row = $result_responses->fetch_assoc()) {
            $responses[] = $row;
        }
        $stmt_responses->close();
        $response['responses'] = $responses;

        // 3. Get total employees in this employee's branch (for analysis lock logic)
        $stmt_branch_total = $conn->prepare("SELECT COUNT(e2.id) AS total_in_branch FROM employees e1 JOIN employees e2 ON e1.branch = e2.branch WHERE e1.id = ?");
        if (!$stmt_branch_total) {
            throw new Exception('Prepare statement failed (branch total): ' . $conn->error);
        }
        $stmt_branch_total->bind_param("s", $employee_id);
        if (!$stmt_branch_total->execute()) {
            throw new Exception('Execute statement failed (branch total): ' . $stmt_branch_total->error);
        }
        $result_branch_total = $stmt_branch_total->get_result();
        $branch_total_count = $result_branch_total->fetch_assoc()['total_in_branch'] ?? 0;
        $stmt_branch_total->close();
        $response['branch_total_count'] = $branch_total_count;

        $response['success'] = true;
    } else {
        // If no evaluation record for this quarter, still return success but with empty data
        $response['success'] = true;
        $response['message'] = 'No evaluation record found for this quarter.';
        $response['responses'] = [];
        $response['branch_total_count'] = 0; // Default to 0 if no evaluation record
    }


} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
    error_log("get_evaluation_details.php error: " . $e->getMessage());
} finally {
    if ($conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>
